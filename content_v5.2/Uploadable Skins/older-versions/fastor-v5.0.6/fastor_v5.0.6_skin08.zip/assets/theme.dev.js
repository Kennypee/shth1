document.addEventListener('lazybeforeunveil', function(e){
  var bg = e.target.getAttribute('data-bg');
  if(bg){
    e.target.style.backgroundImage = 'url(' + bg + ')';
  }
});
function debounce(func, wait, immediate) {
  var timeout;
  return function() {
    var context = this,
      args = arguments;
    var later = function() {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
};
/* start roar functions */
var xxx;
var roar = {
  init: function() {
   	  this.handleAccount(),
   	  this.handleCartAgree(),
      this.handleAddress(),
   	  this.initProductQuickShopItem(),
      this.initFilterSidebar(),
      this.initVerticalMenuSidebar(),
      this.initCountdown(), 
      this.addToCart(),  
      this.cartSidebar(), 
      this.removeCart(),
      this.addToWishlist(), 
      this.handleCompare(),
      this.removeToWishlist(), 
      this.handlePopups(), 
      this.handleGMap(), 
      this.handleScrollToTop(), 
      this.handleSmoothScroll(), 
      this.mapFilters(), 
      this.handleQuickshop(), 
      this.handleBlog(), 
      this.handleCookie(), 
      //this.fixedHeaderMenu(), 
      this.handleDropdown(), 
      this.toggleFilter(),
      this.handleCartPage(),
      this.handleUpsellProducts(),
      this.handleTabs()
  },
  handleTab: function(_tab) {
    //let _tabsSelector = '.rt-tabs';
    //let _tabs = document.querySelectorAll(_tabsSelector);
    //for (let _tab of _tabs) {
      $(_tab).removeClass('rt-tab--loaded').css('minHeight', '').find('.rt-tab__content').css('position', 'unset');
      let tab_items = _tab.querySelectorAll('.rt-tab');
      
      tab_items.forEach(tab_item => {
        let tab_radio = tab_item.querySelector('.rt-tab__radio');
        let tab_content = tab_item.querySelector('.rt-tab__content');
        let _tab_height = tab_content.offsetHeight;
        tab_content.style.position = 'absolute';
        tab_radio.addEventListener("click",function(e){
          _tab.style.minHeight = tab_item.querySelector('.rt-tab__content').offsetHeight + 40 + 'px';
        }, false);
        if(tab_radio.checked) {
          _tab.style.minHeight = _tab_height + 40 + 'px';
        }
      });
      _tab.className += ' rt-tab--loaded';
    //}
  },
  handleTabs:function() {
    if(window.IntersectionObserver) {
      let _tabEls = document.querySelectorAll('.rt-tabs');
      const config = {
        root: null,
        rootMargin: '0px',
        threshold: 0
      };
      let isLeaving = false;
      let observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            isLeaving = true;
            roar.handleTab(entry.target);
          } else if (isLeaving) {
            isLeaving = false;
          }
        });
      }, config);
      _tabEls.forEach(_tabEl => {
          observer.observe(_tabEl);
      });
    } else {
      console.log('Your browser is out of date. Please upgrade it first!');
    }
    roar.handleTabResize();
  },
  handleTabResize: function() {
    if(window.ResizeObserver) {
      let _els = document.querySelectorAll('.rt-tab__content');

      var observer = new ResizeObserver(entries => {
        for (let entry of entries) {
          let _tab = entry.target.closest('.rt-tabs');
          roar.handleTab(_tab);
        }
      });
      
      _els.forEach(_el => {
        observer.observe(_el);
      });
    } else {
      console.log('Your browser is out of date. Please upgrade it first!');
    }
  },
  handleSeasonalFrame: function(){
    $(window).resize(function() {
      if($('.rt-seasonal-frames').length > 0) {
        var _cond = false;
        if($('.rt-seasonal-frames').data('mobile') == false && roar.getWidthBrowser() > 768) _cond = true;
        if($('.rt-seasonal-frames').data('mobile') == true) _cond = true;
        if(_cond == true) {
          $('.rt-seasonal-frames').show();
          var _frames = $('.rt-seasonal-frames');
          var _oriWidth = _frames.data('ow'),
              _oriHeight = _frames.data('oh');
          for(var i = 0 ; i < _frames.children().length ; i++) {
            var _currFrame = $(_frames.children()[i]);
            var _pos = _currFrame.data('position');
            var _index = _currFrame.data('idx');
            var _width = _currFrame.data('w');
            var _height = _currFrame.data('h');
            var _x = _currFrame.data('x');
            var _y = _currFrame.data('y');
            var _src = _currFrame.data('src');
            var _zIndex = 1000 + _index;

            var _ratio, _newWidth, newHeight, _newX, _newY;
            if(_pos == 'top' || _pos == 'bottom') {
              _ratio = window.innerWidth / _oriWidth;
              _newWidth = _width * _ratio;
              _newHeight = _height * _ratio;
              _newX = _x * _ratio;
              if(_pos == 'top') {
                _newY = _y * _ratio;
              } else {
                _newY = (_oriHeight - _y - _height) * _ratio;
              }
              _currFrame.html('');
              _currFrame.html('<img class="position-fixed" width="' + _newWidth + '" height="' + _newHeight + '" style="z-index:' + _zIndex + ';left:' + _newX + 'px;' + _pos + ':' + _newY + 'px" src="' + _src + '"/>')
            } else {
              _ratio = window.innerHeight / _oriHeight;
              _newWidth = _width * _ratio;
              _newHeight = _height * _ratio;
              _newY = _y * _ratio;
              if(_pos == 'left') {
                _newX = _x * _ratio;
              } else {
                _newX = (_oriWidth - _x - _width) * _ratio;
              }
              _currFrame.html('');
              _currFrame.html('<img class="position-fixed" width="' + _newWidth + '" height="' + _newHeight + '" style="z-index:' + _zIndex + ';top:' + _newY + 'px;' + _pos + ':' + _newX + 'px" src="' + _src + '"/>')
            }
          }
        } else {
          $('.rt-seasonal-frames').hide();
        }
      }
    }).resize();
  },
  handleCartAgree: function() {
    $('body').on('change', '.product-cart__agree', function(evt) {
      var agree = $(this);
      var checkout_button = $(this).closest(".cart__condition__wrapper").find('.checkout-button');
      if (agree.is(':checked')) {
        checkout_button.removeClass('btn-disabled');
      }
      else {
        checkout_button.addClass('btn-disabled');
      }
    });
  },
  handleAddress: function(){
    var $newAddressForm = $('#AddressNewForm');

    if (!$newAddressForm.length) {
      return;
    }

    // Initialize observers on address selectors, defined in shopify_common.js
    if (Shopify) {
      // eslint-disable-next-line no-new
      new Shopify.CountryProvinceSelector(
        'AddressCountryNew',
        'AddressProvinceNew',
        {
          hideElement: 'AddressProvinceContainerNew'
        }
      );
    }

    // Initialize each edit form's country/province selector
    $('.address-country-option').each(function() {
      var formId = $(this).data('form-id');
      var countrySelector = 'AddressCountry_' + formId;
      var provinceSelector = 'AddressProvince_' + formId;
      var containerSelector = 'AddressProvinceContainer_' + formId;

      // eslint-disable-next-line no-new
      new Shopify.CountryProvinceSelector(countrySelector, provinceSelector, {
        hideElement: containerSelector
      });
    });

    // Toggle new/edit address forms
    $('.address-new-toggle').on('click', function() {
      $newAddressForm.toggleClass('hide');
    });

    $('.address-edit-toggle').on('click', function() {
      var formId = $(this).data('form-id');
      $('#EditAddress_' + formId).toggleClass('hide');
    });

    $('.address-delete').on('click', function() {
      var $el = $(this);
      var formId = $el.data('form-id');
      var confirmMessage = $el.data('confirm-message');

      // eslint-disable-next-line no-alert
      if (
        confirm(
          confirmMessage || 'Are you sure you wish to delete this address?'
        )
      ) {
        Shopify.postLink('/account/addresses/' + formId, {
          parameters: { _method: 'delete' }
        });
      }
    });

  },
  handleAccount: function(){
    function showRecoverPasswordForm(){
        return $("#recover-password").fadeIn(),
        $("#customer-login").hide(),
        window.location.hash="#recover",!1
    }
    
    function showLoginForm(){
        return $("#recover-password").hide(),
        $("#customer-login").fadeIn(),
        window.location.hash="",!1
    }
    $("#forgot_password a").on("click", function(){
        showRecoverPasswordForm()
    }),
    "#recover"==window.location.hash?showRecoverPasswordForm():showLoginForm();
    $("#recover-password .cancel").on("click", function(){
        showLoginForm()
    })
  },
  initProductQuickShopItem: function(_wrapTarget) {
    var _wrapTarget = _wrapTarget || 'body';    
    function _processProductItemImage(src) {
      var a_src = src.replace("https:", "").replace("http:", "").split("?v=")[0].split("/");
      var at_src = a_src[a_src.length - 1].split(".");
      var at_pop = at_src.pop(); 
      var t1_src = at_src.join(".") + "@2x"+"."+at_pop;
      var t2_src = at_src.join(".") + "."+ at_pop;
      var result = {};
      result["srcset"] =  src.replace(a_src[a_src.length - 1], t1_src)+ " 500w,"+ src.replace(a_src[a_src.length - 1], t2_src ) +" 166w";
      result["src"] =  src.replace(a_src[a_src.length - 1], t2_src );
      return result;
    }
    function _updateItemImageActive(element, src){
      var c_src = src.replace("https:", "").replace("http:", "").split("?v=")[0];
      var a_active = "";
      element.find(".item-images-wrapper a").length > 0 &&
        element.find(".item-images-wrapper a").each(function() {
        var c_image = $(this).data("_image").replace("https:", "").replace("http:", "").split("?v=")[0];
        if (c_image == c_src) {
          a_active = $(this);
          return
        }
      });
      element.find(".item-images-wrapper a").removeClass("active");
      a_active != "" && a_active.addClass("active");
    }
    function removeDataAttributes(target) {
      var i,
          $target = target,
          attrName,
          dataAttrsToDelete = [],
          dataAttrs = $target.get(0).attributes,
          dataAttrsLen = dataAttrs.length;
      for (i=0; i<dataAttrsLen; i++) {
        if ( 'data-' === dataAttrs[i].name.substring(0,5) ) {
          dataAttrsToDelete.push(dataAttrs[i].name);
        }
      }
      $.each( dataAttrsToDelete, function( index, attrName ) {
        $target.removeAttr( attrName );
      })
    }
    function updateProductItemVariant(element,variant) {
      // update add to cart text
      if(variant.available) {
        element.find("div.price").data("price", variant.price);
        element.find(".btn-action.addtocart-item-js span").text(theme.strings.addToCart);
        element.find(".btn-action.addtocart-item-js").prop("disabled", false);
      }else{        
        element.find("div.price").data("price", "0");
        element.find(".btn-action.addtocart-item-js span").text(theme.strings.soldOut);
        element.find(".btn-action.addtocart-item-js").prop("disabled", true);
      }
      element.closest(".grouped-product").length > 0 && roar.updateGroupedPrice();
      // update add to cart variant
      element.find("select.variation-select.no-js").val(variant.id);
      // update add price and badge
      element.find("span.price-new.money").html(theme.Currency.formatMoney(variant.price, theme.settings.moneyFormat));
      if (variant.compare_at_price > variant.price) {
        element.find("span.price-old.money").html(theme.Currency.formatMoney(variant.compare_at_price, theme.settings.moneyFormat)).removeClass("hide");
        element.find(".sale").text(theme.strings.sale).removeClass("hide");
        if (element.find(".sale").hasClass("percentage")) {
          var sale_percentages = Math.round(
            (variant.compare_at_price - variant.price) *
            100 /
            variant.compare_at_price
          );
          element.find(".sale").text("-" + sale_percentages + "%");
        }
      }else{
        element.find("span.price-old.money").addClass("hide");
        element.find(".sale").addClass("hide")
      }
      window.builtin_currencies_used && (removeDataAttributes(element.find(".money")),
      theme.CurrencyPicker.convert(".product-item-advanced-wrapper .money"));
      // update image 
      if(variant.featured_image !== null) {
        _updateItemImageActive(element, variant.featured_image.src);
        var v_image = _processProductItemImage(variant.featured_image.src);
        element.find("img.mpt-image").attr("srcset", v_image.srcset).attr("src", v_image.src)
      }
    }
    function swatchItemCallBack(selectItem, e, op, ov) {
      if(e.options.length > 1 ){
        var wrapperSelectItems = selectItem.closest(".product-item-option");
        for (var i = 0; i < e.options.length; i++) {
          if(i != op) {
            wrapperSelectItems.find(".single-option-selector-item-" + i + ' option').each(function(){
              var _flag =  "unavailable";
              var _value = $(this).attr("value");
              for (j = 0; j < e.variants.length; j++) {
                var _variant = e.variants[j];
                if(_variant.options[op] == ov) {
                  // add out of stock or unavailable
                  if(_variant.options[i] == _value) {
                    if(_variant.available  == true) {
                      _flag =  "available";
                    }else{
                      _flag =  "sold_out";
                    }
                    break;
                  }
                }else{
                  continue;
                }
              }
              $(this).closest(".selector-wrapper-item").find(".swatch-element-item."+$(this).data("swatch")).removeClass("available").removeClass("sold_out").removeClass("unavailable").addClass(_flag);
            });
          }
        }
      }else{
        
        for (var i = 0; i < e.variants.length; i++) {
          var _variant =  e.variants[i];
          var _variant_option =  _variant.option1;
        }
        
        for (var i = 0; i < e.options.length; i++) {
          selectItem.find("option").each(function(){
            var _flag =  "unavailable";
            var _value = $(this).attr("value");
            for (j = 0; j < e.variants.length; j++) {
              if(e.variants[j].options[i] == _value) {
                if(e.variants[j].available){
                  _flag =  "available" ;
                }else{
                  _flag =  "sold_out";
                }
                break;
              }
            }
            $(this).closest(".selector-wrapper-item").find(".swatch-element-item."+$(this).data("swatch")).removeClass("available").removeClass("sold_out").removeClass("unavailable").addClass(_flag);
          });
        }
      }
    }

    $(".single-option-selector-item").length > 0 &&
      $(".single-option-selector-item").unbind("change")&&
      $(document).on("change", ".single-option-selector-item", function() {
      var element = $(this).closest(".product-item-advanced-wrapper");
      if (element.find(".ProductItemJson").length > 0) {
        var ep = JSON.parse(element.find(".ProductItemJson").html());
        var _currentOptions = {};
        var _type_variant = "not_found";
        $(this).closest(".variations-content").find(".single-option-selector-item").each(function() {
          _currentOptions[$(this).data("index")] = $(this).val();
        });
        for (k = 0; k < ep.variants.length; k++) {
          var found_variant =  false;        
          for (ol = 1; ol <= ep.options.length; ol++) {
            if(_currentOptions["option"+ol]  == ep.variants[k]["option"+ol]) {
              found_variant = true
            }else{
              found_variant = false;
              break;
            }
          }
          if(found_variant == true) {
            _type_variant  = "found";
            updateProductItemVariant(element, ep.variants[k]);
            break;
          }
        }
        if(_type_variant == "not_found") {
          element.find(".btn-action.addtocart-item-js span").text(theme.strings.unavailable);
          element.closest(".product-item-advanced-wrapper").find(".btn-action.addtocart-item-js").prop("disabled", true);
        }
      }
    });
    
    var inputNamespace = _wrapTarget + " .swatch-item-radio-js";
    if($(inputNamespace).length > 0){
      $(inputNamespace).unbind("click");
      $(document).on("click", inputNamespace, function(){
        var pJson = JSON.parse($(this).closest(".product-item-advanced-wrapper").find(".ProductItemJson").html());
        var selectorWrapper = $(this).closest(".selector-wrapper-item");
        var sId = selectorWrapper.find("select.single-option-selector-item");
        var _poption = $(this).data("poption");
        var _val = $(this).data("value");
        $(this).data("value") != sId.val() &&
          (sId.val($(this).data("value")).trigger("change"),
           selectorWrapper.find("label").removeClass("label-selected"),
           $(this).parent("label").addClass("label-selected"),
          selectorWrapper.find(".swatch-radio").removeClass("selected"),
          $(this).addClass("selected"));
        swatchItemCallBack(sId, pJson, _poption, _val);
      });
      $( document ).ajaxComplete(function() {
        $(inputNamespace+".selected").trigger("click");
      });
      $(inputNamespace+".selected").trigger("click");
    }
    
    $(document).on(
      "mouseenter mouseleave click",
      ".product-item-advanced-wrapper",
      function(t) {
        if ($(this).parent().hasClass("mproducts-list-detail")) {return;}
        /* var e = $(this),
            o = window.innerWidth,
            n = e.find(".product-item-content"),
            i = e.find(".product-item-inside-hover"),
            s = parseInt(i.height()) + parseInt(i.css('marginTop')) + 3,
            a = e.find(".count_holder_item .is-countdown"),
            a_height = e.find(".count_holder_item .is-countdown").innerHeight(), 
            ai = e.find(".item-images-wrapper"),
            ai_height = e.find(".item-images-wrapper").innerHeight();
        a_height = a_height + ai_height;
        t.target;
        "mouseenter" === t.type && o > 1024
        ? (e
           .css({ height: '100%' }), n
           .css('transform', 'translateY(-' + s + 'px)'), i
           .css('opacity', '1'), a
           .css('transform', 'translateY(-' + parseInt(s + 10) + 'px)'), ai
           .css('transform', 'translateY(-' + parseInt(s) + 'px)'))
        : "mouseleave" === t.type &&
          t.relatedTarget &&
          o > 1024 &&
          (e
           .removeAttr("style"), n
           .removeAttr("style"),
           i.removeAttr("style"),
           a.removeAttr("style"),
           ai.removeAttr("style")
          ); */
      }
    );
    
    $(document).on("click", ".item-images-wrapper a", function(){
      if(!$(this).hasClass("active")){
        var _image = $(this).data("_image");
        var v_image = _processProductItemImage(_image);
        $(this).closest(".item-images-wrapper").find("a").removeClass("active"),
          $(this).addClass("active"),
          $(this).closest(".product-content-wrapper").find("img.mpt-image").attr("srcset", v_image.srcset).attr("src", v_image.src)
      }
    });
    $(document).on("click", ".items-image-buttons a", function(e){
    	e.preventDefault();
        if($(this).hasClass("next")) {
          $(this).closest(".product").find(".item-images-wrapper a.active").next().trigger("click")
        }else{
          $(this).closest(".product").find(".item-images-wrapper a.active").prev().trigger("click")
        }
    });
  },
  initFilterSidebar: function () {
    $(".filter_title .arrow").on("click", function(){
      $(this).toggleClass("rotArr");
      $(this).parent().next().slideToggle(300);
    });
  },
  initVerticalMenuSidebar: function () {
    $(".ver-dropdown-parent-submenu a.dropdown-link").on('click', function(e){
      e.preventDefault();
      var _target = $(this).closest('.ver-dropdown-parent-submenu').find("ul.ver-dropdown-menu");
      var _icon = $(this).find('i.fa');
      _icon.hasClass('aDown') ? (_icon.removeClass('aDown') && _target.slideUp()): (_icon.addClass('aDown') && _target.slideDown())
    })
  },
  fixedHeaderMenu: function() {
    if ($(window).width() <= 991) {
      return;
    }
    $('#header-phantom').length > 0 && $('#header-phantom').remove();
    if (
      ($(".section-megamenu-content").length > 0 &&
        $(".section-megamenu-content").each(function() {
          var e = $(this).data("menu_width_class");
          $(this).closest(".shopify-section").length > 0 &&
            ($(this).closest(".shopify-section").hasClass(e) ||
              $(this).closest(".shopify-section").addClass(e));
        }), "menu" == window.fixed_header)
    ) {
      var e = $(
        '<div id="header-phantom" class="fixed-header-1 sticky-header"></div>'
      );
      e.insertAfter(".mega-menu-modules"), $(".mega-menu-modules")
        .clone()
        .appendTo("#header-phantom"), roar.fixedMenu(), $(
        window
      ).resize(function() {
        roar.fixedMenu();
      }), $(window).scroll(function() {
        roar.fixedMenu();
      });
    } else if ("header" == window.fixed_header) {
      var e = $(
        '<div id="header-phantom" class="fixed-header-1 sticky-header"></div>'
      );
      e.insertAfter("#header-parts"), $("#header-parts")
        .clone()
        .appendTo("#header-phantom"), roar.fixedHeader(), $(
        window
      ).resize(function() {
        roar.fixedHeader();
      }), $(window).scroll(function() {
        roar.fixedHeader();
      });
    }
    $("#header-phantom .shopify-section").length > 0 &&
      $("#header-phantom .shopify-section").each(function() {
        $(this).removeClass("shopify-section");
      });
  },
  fixedHeader: function() {
    var e = $("header #header-parts").first().width();
    $("header #header-parts .background").first().width() !=
      $("header").first().width() &&
      $(".sticky-header").css("background", "none"), $(".sticky-header")
      .css("width", e)
      .css("left", "50%")
      .css("right", "auto")
      .css("margin-left", "-" + Math.ceil(e / 2) + "px")
      .css(
        "margin-right",
        "-" + Math.ceil(e / 2) + "px"
      ), roar.getWidthBrowser() >= 1160 && $(window).scrollTop() > 280
      ? $(".sticky-header").addClass("fixed-header")
      : $(".sticky-header").removeClass("fixed-header");
  },
  fixedMenu: function() {
    var e = $("header .mega-menu-modules").first().width();
    $("header #header-parts .background").first().width() !=
      $("header").first().width() &&
      $(".sticky-header").css("background", "none"), $(".sticky-header")
      .css("width", e)
      .css("left", "50%")
      .css("right", "auto")
      .css("margin-left", "-" + Math.ceil(e / 2) + "px")
      .css(
        "margin-right",
        "-" + Math.ceil(e / 2) + "px"
      ), roar.getWidthBrowser() >= 1160 && $(window).scrollTop() > 280
      ? $(".sticky-header").addClass("fixed-header")
      : $(".sticky-header").removeClass("fixed-header");
  },
  toggleFilter: function() {
    $("#filter-sidebar").on("click", function() {
      $("body").toggleClass("open_filter");
    }), $(document).on("click", ".open_filter .spinner", function() {
      $("body").removeClass("open_filter");
    }), $("#filter-addtocart").on("click", function() {
      $("#product .add-to-cart").trigger("click");
    });
  },
  destroyCountdown: function() {
    $.fn.countdown && $(".is-countdown").countdown("destroy");
  },
  initCountdown: function() {
    $.fn.countdown &&
      $(".countdown:not(.is-countdown)").each(function() {
        var e = $(this),
          t = new Date(),
          o = new Date(
            parseInt(e.data("year")),
            parseInt(e.data("month")) - 1,
            e.data("day")
          );
        o > t ? e.countdown({ until: o }) : e.parent().hide();
      });
  },
  handleCookie: function() {
    var t1;
    function e() {
      $("#cookie.cookie").length
        ? $("#cookie").fadeIn("slow")
        : $("#cookie.popup").length &&
          (t1 = loadScriptAsync (theme.libs.mpopup), 
          t1.then (function () {
          
          setTimeout (function () {
            $.magnificPopup.open({
              items: { src: "#cookie", type: "inline" },
              tLoading: "",
              mainClass: "popup-module mfp-with-zoom popup-type-2",
              removalDelay: 200,
              modal: !0
            });
          }, 500);
              
          }));

            
    }
    function t() {
      try {
        var e = "domain=." + document.domain,
          t = "popup-module-cookie",
          o = "true",
          a = new Date();
        a.setTime(a.getTime() + 31536e6);
        var i = "; expires=" + a.toGMTString();
        document.cookie = t + "=" + o + i + "; path=/; " + e;
      } catch (e) {
       // console.log(e.message);
      }
    }
    function o() {
      try {
        var e = "popup-module-cookie";
        if (document.cookie.length > 0) {
          var t = document.cookie.indexOf(e + "=");
          if (-1 != t) {
            t = t + e.length + 1;
            var o = document.cookie.indexOf(";", t);
            return -1 == o && (o = document.cookie.length), unescape(
              document.cookie.substring(t, o)
            );
          }
        }
      } catch (e) {
       // console.log(e.message);
      }
    }
    !o() &&
      $("#cookie").length &&
      (e(), $("#cookie .accept").on("click", function() {
        t(), $("#cookie.cookie").length
          ? $("#cookie").fadeOut("slow")
          : $("#cookie.popup").length && $.magnificPopup.close();
      }));
  },
  handleBlog: function() {
    function e(e) {
      $.ajax({
        url: location.href,
        type: "get",
        dataType: "html",
        data: { page: e },
        success: function(e) {
          "" != $(e).find(".blog-page .empty").html() &&
            $(".pagination-ajax").hide();
        },
        error: function() {
          $(".pagination-ajax").hide();
        }
      });
    }
    function t() {
      (o = $(".posts").masonry({
        itemSelector: ".post"
      })), o.imagesLoaded().progress(function() {
        o.masonry("layout");
      });
    }
    if ($("body").hasClass("templateBlog")) {
      var o = {};
      $(".posts").hasClass("posts-grid") && t(), $(
        "#load-more"
      ).on("click", function() {
        var t = $(this).attr("data-page");
        $.ajax({
          url: location.href,
          type: "get",
          dataType: "html",
          data: { page: t },
          beforeSend: function() {
            $("#load-more").button("loading");
          },
          complete: function() {
            $("#load-more").button("reset");
          },
          success: function(o) {
            return "" == o
              ? void $(".pagination-ajax").fadeOut()
              : ($(".posts").hasClass("posts-grid")
                  ? ($(".posts").append($(o).find(".posts").html()), $(".posts")
                      .masonry("reloadItems")
                      .masonry({
                        sortBy: "original-order"
                      }), setTimeout(function() {
                      $(".posts")
                        .masonry("reloadItems")
                        .masonry({ sortBy: "original-order" });
                    }, 500))
                  : $(".posts").append($(o).find(".posts").html()), $(
                  "#load-more"
                ).attr("data-page", parseInt(++t)), void e(t));
          }
        });
      });
    }
  },
  handleCompare: function(){
  	window.compare == '1' && (roar.handleCompareEvent(), roar.autoloadCompare(), roar.handleCompareScroll())
  },
  handleCompareEvent : function() {
    var body = $("body"),
        button = $("a.add_to_compare"),
    	c_detail = false;
            
    body.on("click", "a.add_to_compare", function() {
      // add loading 
      var $this = $(this), handle = $this.data('pid'),
          holder = '', 
          ls = RoarCookie.cookie.rtread('rt-compare');
      if(ls != null && ls != ''){ 
        ls = ls.split(',');
      }else{
        ls = new Array();
      }
      if(ls.indexOf(handle)< 0 && $(this).hasClass('added') === false ){
        ls.push(handle);
        var ls_ = ls.join(',');
        if (ls_.substring(0, 1) == ',') { 
          ls_ = ls_.substring(1);
        }
        RoarCookie.cookie.rtwrite('rt-compare',ls_);
      }
      if( $(this).hasClass('added') === false || holder === '' ) {
        holder = '';
        $.ajax({
          url: '/search?view=compare&q='+ls,
          dataType: 'html',
          type: 'GET',
          success: function(responsive) {
            holder = responsive;
          },
          error: function(data) {
            console.log('ajax error');
          },
          complete: function() {
            $.magnificPopup.open({
              items: { src: holder, type: "inline" },
              preloader: !0,
              tLoading: "",
              mainClass: "quickview compareview",
              removalDelay: 200,
              gallery: { enabled: !0 },
              callbacks: {
                open: function() {
                  $('[data-pid="'+handle + '"]' ).addClass('added').attr("title", $('[data-pid="'+handle + '"]' ).attr("data-added"));
                  $('[data-pid="'+handle+'"]' ).find('span').html($('[data-pid="'+handle + '"]' ).attr("data-add"));
                  //currency
                  window.builtin_currencies_used && theme.CurrencyPicker.convert(".compare-content .money");
                  roar.handleReviews();
                  roar.handleCompareScroll();
                }
              }
            });
          }
        });
      } else {
        $.ajax({
          url: '/search?view=compare&q='+ls,
          dataType: 'html',
          type: 'GET',
          success: function(responsive) {
            holder = responsive;
          },
          error: function(data) {
            console.log('ajax error');
          },
          complete: function() {
            $.magnificPopup.open({
              items: { src: holder, type: "inline" },
              preloader: !0,
              tLoading: "",
              mainClass: "quickview compareview",
              removalDelay: 200,
              gallery: { enabled: !0 },
              callbacks: {
                open: function() {
                  //currency
                  window.builtin_currencies_used && theme.CurrencyPicker.convert(".compare-content .money");
                  roar.handleReviews();
                  roar.handleCompareScroll();
                }
              }
            });
          }
        });
      }
    });
    //handle remove
    body.on('click', '.remove_from_compare', function(ev) {
      ev.preventDefault();
      var $this = $(this),handle = $this.attr('data-rev'),holder = $(".compare-content");
      $('[data-pid="'+handle + '"]' ).removeClass('added').attr("title",  $('[data-pid="'+handle + '"]' ).attr("data-add"));               
      $('[data-pid="'+handle+'"]' ).find('span').html($('[data-pid="'+handle + '"]' ).attr("data-add"));
      var ls = decodeURI(RoarCookie.cookie.rtread('rt-compare'));
      if(ls != null){ 
        ls = ls.split(',');
      }
      //console.log(ls);
      ls = $.grep(ls, function(value) {
        return value != handle;
      });
      //ls.splice($.inArray(handle ,ls),1);
      ls  = $.trim(ls);
      RoarCookie.cookie.rtwrite('rt-compare',ls);
      $('.fastor_'+handle).remove();
      if(ls.length <= 0 ){ 
        $('.mfp-close').trigger('click');
      }
    });
  },
  autoloadCompare: function() {
    if( parseInt(theme.compare) == 0 ) return;
    var ls = RoarCookie.cookie.rtread('rt-compare');
    if(ls != null){ 
      ls = ls.split(',');
      ls.map(function(elem, index) {
        $('[data-pid="'+elem+'"]' ).addClass('added').attr("title",  $('[data-pid="'+elem + '"]' ).attr("data-added"));               
        $('[data-pid="'+elem+'"]' ).find('span').html($('[data-pid="'+elem + '"]' ).attr("data-added"));
      });
    }else{
      ls = new Array();
    }
  },
  handleCompareScroll: function() {
  /* handle scroll */ 
    $("#be_compare_features_table").on("scroll", function() {
      var parent_div = $(this).parent();

      if (
        $(this).scrollLeft() + $(this).innerWidth() >=
        $(this)[0].scrollWidth
      ) {
        if (parent_div.hasClass("scroll-right")) {
          parent_div.removeClass("scroll-right");
        }
      } else if ($(this).scrollLeft() === 0) {
        if (parent_div.hasClass("scroll-left")) {
          parent_div.removeClass("scroll-left");
        }
      } else {
        if (!parent_div.hasClass("scroll-right")) {
          parent_div.addClass("scroll-right");
        }
        if (!parent_div.hasClass("scroll-left")) {
          parent_div.addClass("scroll-left");
        }
      }
    });
    be_compare_container = document.getElementById("be_compare_features_table");
    if (be_compare_container !== null) {
      if (be_compare_container.offsetWidth < be_compare_container.scrollWidth) {
        if (
          !$("#be_compare_features_table_inner").hasClass("scroll-right")
        ) {
          $("#be_compare_features_table_inner").addClass("scroll-right");
        }
      }
    }
    $(window).on("resize", function() {
      roar.be_compare_products_table_shadows();
    });
    if($("#be_compare_features_table_inner").hasClass("scroll-left") || $("#be_compare_features_table_inner").hasClass("scroll-right")) {
      $('.compareview').addClass('no-flex');
    }else{
      $('.compareview').removeClass('no-flex');
    }
  },
  be_compare_products_table_shadows: function () {
    be_compare_container = document.getElementById("be_compare_features_table");
    if (be_compare_container === null) return;

    if (be_compare_container.offsetWidth < be_compare_container.scrollWidth) {
      if (!$("#be_compare_features_table_inner").hasClass("scroll-right")) {
        $("#be_compare_features_table_inner").addClass("scroll-right");
      }
    } else {
      if ($("#be_compare_features_table_inner").hasClass("scroll-right")) {
        $("#be_compare_features_table_inner").removeClass("scroll-right");
      }
      if ($("#be_compare_features_table_inner").hasClass("scroll-left")) {
        $("#be_compare_features_table_inner").removeClass("scroll-left");
      }
    }
    if($("#be_compare_features_table_inner").hasClass("scroll-left") || $("#be_compare_features_table_inner").hasClass("scroll-right")) {
    	$('.compareview').addClass('no-flex');
    }else{
      $('.compareview').removeClass('no-flex');
    }
  },
  removeToWishlist: function() {
    $(document).on("click", ".remove-wishlist", function(e) {
      e.preventDefault();
      var t = $(this), o = t.closest("form"), a = { action: "remove_wishlist" };
      return (a = o.serialize() + "&" + $.param(a)), $.ajax({
        type: "POST",
        url: "/a/wishlist",
        async: !0,
        cache: !1,
        data: a,
        dataType: "json",
        beforeSend: function() {
          $(".page-wishlist").addClass("is_loading");
        },
        error: function(e) {
			 $(".page-wishlist").removeClass("is_loading");
        },
        success: function(e) {
          1 == e.code
            ? t.closest(".item").slideUp("fast", function() {
                t
                  .closest(".item")
                  .remove(), $(".page-wishlist .infos").removeClass("hide"), $(".wishlist_items_number").text(e.json), 0 == e.json && $(".wishlist-empty").removeClass("hide");
              })
            : (alert(e.json)), $(
            ".page-wishlist"
          ).removeClass("is_loading");
        }
      }), !1;
    });
  },
  addToWishlist: function() {
    $(document).on("click", ".add-to-wishlist:not(.added)", function(e) {
      if ($(this).hasClass("need-login")) {
        var t = $("#wishlist_error").html();
        return $.notify(
          { message: t, target: "_blank" },
          {
            type: "info",
            showProgressbar: !0,
            z_index: 2031,
            mouse_over: "pause",
            placement: { from: "top", align: window.rtl ? "left" : "right" }
          }
        ), !1;
      }
      var o = $(this), a = o.closest("form"), n = { action: "add_wishlist" };
      return (n = a.serialize() + "&" + $.param(n)), $.ajax({
        type: "POST",
        url: "/a/wishlist",
        async: !0,
        cache: !1,
        data: n,
        dataType: "json",
        beforeSend: function() {
          o.hasClass("btooltip")
            ? o.addClass("loading")
            : o
                .attr("title", o.attr("data-loading-text"))
                .find("span")
                .text(o.attr("data-loading-text"));
        },
        complete: function() {
          o.hasClass("btooltip") && o.removeClass("loading"), $(
            ".wishlist" + o.prev().val()
          )
            .attr("title", o.attr("data-added"))
            .addClass("added")
            .find("span")
            .text(o.attr("data-added"));
        },
        error: function(e) {
          var t = (i = $.parseJSON(e.responseText)),
            o = t.message + ": " + t.description;
          $.notify(
            { message: o, target: "_blank" },
            {
              type: "info",
              showProgressbar: !0,
              z_index: 2031,
              mouse_over: "pause",
              placement: { from: "top", align: window.rtl ? "left" : "right" }
            }
          );
        },
        success: function() {
          var e = o.closest(".product"),
            t = [
              {
                product_url: e.find(".name a").attr("href"),
                product_name: e.find(".name a").text()
              }
            ];
          $.notify(
            {
              message: $("<div>")
                .append($("#wishlist_success").tmpl(t).clone())
                .html(),
              target: "_blank"
            },
            {
              type: "success",
              showProgressbar: !0,
              z_index: 2031,
              mouse_over: "pause",
              placement: { from: "top", align: window.rtl ? "left" : "right" }
            }
          );
        }
      }), !1;
    });
  },
  handleUpsellProducts: function() {
    if($("#productUpsells ").length == 0) return;
    let _selector = '#productUpsells .splide';
    if($(_selector).length) {
      let _slider = new Splide( _selector, { updateOnMove: true });
      _slider.on('mounted moved', debounce(function() {
        $(_slider.root).find('.splide__slide').removeClass('is-last-visible');
        $(_slider.root).find('.splide__slide[tabindex=0]').last().addClass('is-last-visible');
      }, 2000));
      _slider.mount();
    } 
    roar.handleQuickshop(_selector);
  },
  handleCartPage: function(){
    if(!$("body").hasClass("templateCart")) {return;}
    
    $(window).on("resize", function() {
      $(window).width() <= 789 ?  changeOnDesktop() : changeOnMobile();
      function changeOnDesktop(){
        $(".cart-info .cart-quantity-desktop").each(function(){
          var objectDesktop = $(this).find('.cart-quantity-wrapper').detach().get(0);
          $(this).closest('tr').find('.cart-quantity-mobile').append(objectDesktop);
        })
      };
      function changeOnMobile(){
        $(".cart-info .cart-quantity-mobile").each(function(){
          var objectMobile = $(this).find('.cart-quantity-wrapper').detach().get(0);
          $(this).closest('tr').find('.cart-quantity-desktop').append(objectMobile);
        })
      };
    }).trigger("resize");
    
    $(document).on("click", ".cart-quantity-wrapper span", function(e){
      e.preventDefault();
      var $input = $(this).parent().find('input');
      var input_val = parseInt($input.val()); 
      if($(this).hasClass('cart-plus')){
        input_val = input_val + 1;
        $input.val(input_val).trigger("change");
      }else{
        if (input_val > 1){
          input_val = input_val -1;
          $input.val(input_val).trigger("change");
        }
      }
    });
    
    $ (document).on ('click', '[href$="quantity=0"]', function (e) {
      $ ('[href$="quantity=0"]').length &&
        $ ('[href$="quantity=0"]').css ('pointer-events', 'none');

      e.preventDefault ();

      var lineItem = $ (this).closest ('tr');
      var index = lineItem.index () + 1;

      var params = {
        type: 'get',
        dataType: 'json',
        url: '/cart/change?line=' + index + '&quantity=0',
        success: function (data) {
          lineItem.fadeOut (400, function () {
            $ (this).remove ();
            var ele = $ ('[href$="quantity=0"]');

            if (!ele.length) {
              $ ('.cart-page-content').remove ();
              $ ('.cart-page-empty').removeClass ('hide');
            }

            $ ('[href$="quantity=0"]').length &&
              $ ('[href$="quantity=0"]').css ('pointer-events', 'unset');

            updatePrices (data);
          });
        },
        error: function (XMLHttpRequest, textStatus) {
          console.log ('some ajax error with delete');
          $ ('[href$="quantity=0"]').length &&
            $ ('[href$="quantity=0"]').css ('pointer-events', 'unset');
        },
      };
      $.ajax (params);
    });
    var timercount = [];
    $ ('.cart-quantity-wrapper input').on("change", function () {
      // console.log("xxx");
      var self = $ (this), index = self.closest ('tr').index ();
      if (timercount[index]) {
        clearTimeout (timercount[index]); //cancel the previous timer.
        timercount[index] = null;
      }
      timercount[index] = setTimeout (updateInputValue.bind (null, self), 500);
    });
                                          
    function updateInputValue (e) {
      var index = e.closest ('tr').index (), indexget = index + 1;
      var params = {
        type: 'get',
        dataType: 'json',
        url: '/cart/change?line=' + indexget + '&quantity=' + e.val (),
        success: function (data) {
          var m = '<span class="money">' + theme.Currency.formatMoney(data.items[index].line_price, theme.settings.moneyFormat) + '</span>',
              o = e.closest ('tr').find ('.subtotal');
          o.length && o.empty ().append (m);
          updatePrices (data);
          
        },
        error: function (XMLHttpRequest, textStatus) {
          console.log ('some ajax error with count');
        },
      };
      $.ajax (params);
    }

    function updatePrices (data) {
      var m = '<span class="money">' + theme.Currency.formatMoney(data.total_price, theme.settings.moneyFormat) + '</span>';
      $ ('#subtotal .subtotal-price').length && $ ('#subtotal .subtotal-price').html (m);      
      window.builtin_currencies_used && theme.CurrencyPicker.convert(".cart-info .money");
    }
    
  },
  
  addToCart: function() {
    window.shopping_cart_type != "direct" &&
      $(document).on("click", ".add-to-cart:not(.disabled)", function() {
      var e = $(this),_success = false, t = e.closest("form");
      return $.ajax({
        type: "POST",
        url: "/cart/add.js",
        async: !0,
        cache: !1,
        data: t.serialize(),
        dataType: "json",
        beforeSend: function() {
          e.hasClass("btooltip")
          ? e.addClass("loading")
          : e.button("loading") &&
            $("#filter-addtocart span").text(
            e.attr("data-loading-text")
          ) &&
            $("#filter-addtocart").addClass("active");
        },
        complete: function() {
          e.hasClass("btooltip")
          ? e.removeClass("loading")
          : e.button("reset") &&
            $("#filter-addtocart").removeClass("active");
          //complete update cart

        },
        error: function(e) {
          roar.updateCart(e, false);
        },
        success: function(e) {
          if( window.shopping_cart_type == "sidebar") {
            roar.updateCartSidebar(e, true);
          }else{ 
            roar.updateCart(e, true);
          }
        }

      }).done(function() {
        //roar.popupCart(e, _success);
      }), !1;
    });
  },
  cartSidebar: function() {
    if( window.shopping_cart_type != "sidebar" ) return;

    $('body').on('click', ".cart-item a.remove-cart",function(event){
      event.preventDefault();

      var self = $(this);
      var id = self.attr("data-id");

      var params = {
        type: "POST",
        url: "/cart/change.js",
        data: "quantity=0&id=" + id,
        dataType: "json",
        beforeSend: function() {
          $(".cart-window-body").addClass("loading") ;
        },
        success: function() {
          $.ajax({
            url: "/search",
            beforeSend: function() {
            },
            success: function(result) {
              roar.updateCart(self, true);
            },
            error: function(errorThrown) {
              console.log(errorThrown);
            }
          }).done(function() {
            $(".cart-window-body").removeClass("loading") ;
          });
        },
        error: function(XMLHttpRequest, textStatus) {
          Shopify.onError(XMLHttpRequest, textStatus);
          $(".cart-window-body").removeClass("loading") ;
        }
      };
      $.ajax(params);
    });
    $(document)
    .on("focus", "#cart_info .update", function() {
      $(this).select();
    })
    .on("blur", "#cart_info .update", function() {
      var self = $(this);
      var quantity = self.val();
      var id = self.attr("data-id");

      var params = {
        type: "POST",
        url: "/cart/change.js",
        data: "quantity=" + quantity + "&id=" + id,
        dataType: "json",
        beforeSend: function() {
          $(".cart-window-body").addClass("loading");
        },
        success: function() {
          roar.updateCart(self, true);
        },
        error: function(XMLHttpRequest, textStatus) {
          Shopify.onError(XMLHttpRequest, textStatus);
        }
      };
      $.ajax(params).done(function() {
        $(".cart-window-body").removeClass("loading");
      });
    });
    $('body').on('click', ".cart-sidebar-trigger",function(e){
      if (e.target === this)  {
        e.preventDefault();
        $(".cart-window-bg").toggleClass( "window-hide" );
      }
    });
      $("body").on("click", ".cart-sidebar-trigger a.button", function(e) {
        e.preventDefault();
        var _href= $(this).attr("href");
        window.location.href = window.location.origin + _href;
        return;
      });
      $('body').on('click', ".close-cart", function(e){
        e.preventDefault();
        $(".cart-window-bg").addClass( "window-hide" );
      });
      $('body').on('click','.qty-btn.cart-plus', function(e){
        var p_id = $(this).data("id");
        var q_value =  parseInt($(p_id).val()) + 1 ;
        $(p_id).val(q_value);
        var self = $(p_id);
          var quantity = self.val();
          var id = self.attr("data-id");

          var params = {
            type: "POST",
            url: "/cart/change.js",
            data: "quantity=" + quantity + "&id=" + id,
            dataType: "json",
            beforeSend: function() {
              $(".cart-window-body").addClass("loading");
            },
            success: function() {
              roar.updateCart(self, true);
            },
            error: function(XMLHttpRequest, textStatus) {
              Shopify.onError(XMLHttpRequest, textStatus);
            }
          };
          $.ajax(params).done(function() {
            $(".cart-window-body").removeClass("loading");
          });
      });
      $('body').on('click','.qty-btn.cart-minus', function(e){
        var p_id = $(this).data("id");
        var q_value =  parseInt($(p_id).val());
        if(q_value > 1) {
          $(p_id).val(q_value -1);
          var self = $(p_id);
          var quantity = self.val();
          var id = self.attr("data-id");

          var params = {
            type: "POST",
            url: "/cart/change.js",
            data: "quantity=" + quantity + "&id=" + id,
            dataType: "json",
            beforeSend: function() {
              $(".cart-window-body").addClass("loading");
            },
            success: function() {
              roar.updateCart(self, true);
            },
            error: function(XMLHttpRequest, textStatus) {
              Shopify.onError(XMLHttpRequest, textStatus);
            }
          };
          $.ajax(params).done(function() {
            $(".cart-window-body").removeClass("loading");
          });
        }
      });
  },
  updateCartSidebar: function(_e, _success) {
    $.ajax({
      url: "/search",
      beforeSend: function() {
        $(".cart-window-body").addClass("loading") ;
      },
      success: function(result) {
        var cart_block = "div#cart_block",
            cart_popup = "div#cart_popup",
            cart_mobile = ".mobile-nav-cart",
            cart_footer = "#filter-cart", 
            cart_panel = "div#cart-sidebar";
        if($(cart_panel).length > 0){
          $(cart_panel).html($(result).find(cart_panel).html());
          setTimeout(function(){ $(".cart-sidebar-trigger").trigger("click")},100);
        }
        $(cart_block).html($(result).find(cart_block).html());
        $(cart_popup).html($(result).find(cart_popup).html());
        $(cart_mobile).html($(result).find(cart_mobile).html());
        $(cart_footer).html($(result).find(cart_footer).html());
        window.builtin_currencies_used && 
          (theme.CurrencyPicker.convert("#cart_block .money"),
           theme.CurrencyPicker.convert("#cart_popup .money"),
           theme.CurrencyPicker.convert("#cart-sidebar .money"));
        roar.handleReviews();

      },
      error: function(errorThrown) {
        console.log(errorThrown);
      }
    }).done(function() {
      $(".cart-window-body").removeClass("loading") ;
    });
  },
  updateCart: function(_e, _success) {
    if(_success == true) {
      if(window.shopping_cart_type == "sidebar"){
        $.ajax({
          url: "/search",
          beforeSend: function() {
            $(".cart-window-body").addClass("loading") ;
          },
          success: function(result) {
            var cart_block = "div#cart_block",
                cart_popup = "div#cart_popup",
                cart_mobile = ".mobile-nav-cart",
                cart_footer = "#filter-cart", 
                cart_panel = "#cart-sidebar";
            if($(cart_panel).length > 0){
              $(cart_panel).html($(result).find(cart_panel).html());
            }
            $(cart_block).html($(result).find(cart_block).html());
            $(cart_popup).html($(result).find(cart_popup).html());
            $(cart_mobile).html($(result).find(cart_mobile).html());
            $(cart_footer).html($(result).find(cart_footer).html());
            window.builtin_currencies_used && 
              (theme.CurrencyPicker.convert("#cart_block .money"),
               theme.CurrencyPicker.convert("#cart_popup .money"),
               theme.CurrencyPicker.convert("#cart-sidebar .money"));
            roar.handleReviews();
            
          },
          error: function(errorThrown) {
            console.log(errorThrown);
          }
        }).done(function() {
          $(".cart-window-body").removeClass("loading") ;
        });
      }else{
        $.ajax({
          url: "/search?view=cart&q="+ _e.handle + "_sp_" +_e.variant_id + "_sp_" + _e.quantity + "_sp_" + _e.price,
          beforeSend: function() {
            // $("#cart-panel").addClass("loading");
          },
          success: function(result) {
            var cart_block = "div#cart_block",
                cart_popup = "div#cart_popup",
                cart_mobile = ".mobile-nav-cart",
                cart_footer = "#filter-cart";
            $(cart_block).html($(result).find(cart_block).html());
            $(cart_popup).html($(result).find(cart_popup).html());
            $(cart_mobile).html($(result).find(cart_mobile).html());
            $(cart_footer).html($(result).find(cart_footer).html());
            window.builtin_currencies_used && (theme.CurrencyPicker.convert("#cart_popup .money"), theme.CurrencyPicker.convert("#cart_block .money"));
          },
          error: function(errorThrown) {
            console.log(errorThrown);
          }
        }).done(function() {
          if( window.shopping_cart_type == "ajax_notify" ){
            var t = [{ product_url: _e.url, product_name: _e.title }];
            $.notify(
              {
                message: $("<div>")
                .append($("#cart_success").tmpl(t).clone())
                .html(),
                target: "_blank"
              },
              {
                type: "success",
                showProgressbar: !0,
                z_index: 2031,
                mouse_over: "pause",
                placement: { from: "top", align: window.rtl ? "left" : "right" }
              }
            )
          }else{
            roar.popupCart(_success);
          }
        });
      }
    }else{
      var _error = $.parseJSON(_e.responseText);
      $.ajax({
        url: "/search?view=cart_error&q="+ _error.description,
        beforeSend: function() {
        },
        success: function(result) {
          var cart_error_block = "div#cart_error_popup";
          $(cart_error_block).html($(result).filter(cart_error_block).html());
        },
        error: function(errorThrown) {
          console.log(errorThrown);
        }
      }).done(function() {
        if( window.shopping_cart_type == "ajax_notify" ){
          var t = (i = $.parseJSON(_e.responseText)),
              o = t.message + ": " + t.description;
          $.notify(
            { message: o, target: "_blank" },
            {
              type: "info",
              showProgressbar: !0,
              z_index: 2031,
              mouse_over: "pause",
              placement: { from: "top", align: window.rtl ? "left" : "right" }
            }
          );
        }else{
          roar.popupCart(_success);
        }
      });
    }
    
  },
  removeCart: function(){
    $(document).on("click", ".mini-cart-info .remove a", function(event) {
      event.preventDefault();

      var self = $(this);
      var id = self.attr("data-id");

      var params = {
        type: "POST",
        url: "/cart/change.js",
        data: "quantity=0&id=" + id,
        dataType: "json",
        beforeSend: function() {
          $("#cart_content").addClass("loading") ;
        },
        success: function() {
          $.ajax({
            url: "/search",
            beforeSend: function() {
            },
            success: function(result) {
              var cart_block = "div#cart_block",
                  cart_popup = "div#cart_popup",
                  cart_mobile = ".mobile-nav-cart",
                  cart_footer = "#filter-cart";
              $(cart_block).html($(result).find(cart_block).html());
              $(cart_popup).html($(result).find(cart_popup).html());
              $(cart_mobile).html($(result).find(cart_mobile).html());
              $(cart_footer).html($(result).find(cart_footer).html());
              window.builtin_currencies_used && (theme.CurrencyPicker.convert("#cart_popup .money"), theme.CurrencyPicker.convert("#cart_block .money"));
              // roar.updateCart(self, true);   
              
            },
            error: function(errorThrown) {
              console.log(errorThrown);
            }
          }).done(function() {
            $("#cart_content").removeClass("loading") ;
          });
        },
        error: function(XMLHttpRequest, textStatus) {
          Shopify.onError(XMLHttpRequest, textStatus);
          $("#cart_content").removeClass("loading") ;
        }
      };
      $.ajax(params);
    });
  },
  popupCart: function(_success) {
    if(_success == true) {
      $.magnificPopup.open({
        items: { src: "#cart_popup", type: "inline" },
        tLoading: "",
        mainClass: "popup-module mfp-with-zoom popup-type-1",
        removalDelay: 200,
        callbacks: {
          open: function() {
            $("#cart_popup .continue-shopping").unbind("click"), 
              $("body").on("click", "#cart_popup .continue-shopping", function(C) { 
              C.preventDefault(), $.magnificPopup.close();
            })
          }
        }
      })
    }else{
      $.magnificPopup.open({
        items: { src: "#cart_error_popup", type: "inline" },
        tLoading: "",
        mainClass: "popup-module mfp-with-zoom popup-type-1",
        removalDelay: 200
      })
    }
  },
  handlePopups: function() {
    $(".newsletter-terms").on("change", function(e){
      if ($(this).prop( "checked" ) == true) {
        $(this).closest("form").find("button").prop("disabled", false);
      } else {
        $(this).closest("form").find("button").prop("disabled", true);
      }
    })
    
    function e() {
      if (
        (0 == window.popup_mailchimp_expire
          ? $("#popup-mailchimp .dont-show-me").change(function() {
              $(this).is(":checked") ? t() : o();
            })
          : 1 == window.popup_mailchimp_expire && o(), !a())
      ) {
        var e = parseInt(window.popup_mailchimp_delay, 20),
          i = parseInt(window.popup_mailchimp_close, 20);
        setTimeout(function() {
          $.magnificPopup.open({
            items: { src: "#popup-mailchimp", type: "inline" },
            tLoading: "",
            mainClass: "popup-module mfp-with-zoom popup-type-1",
            removalDelay: 200
          }), i > 0 &&
            setTimeout(function() {
              $.magnificPopup.close();
            }, i);
        }, e), 2 == window.popup_mailchimp_expire && t();
      }
      var n = $("#mc-form"), r = n.attr("action");
      n.ajaxChimp({ url: r, callback: function(e) {} });
    }
    function t() {
      try {
        var e = parseInt(window.popup_mailchimp_period);
        0 >= e && (e = 1);
        var t = "domain=." + document.domain,
          o = "popup-module-mailchimp",
          a = "true",
          i = new Date();
        i.setTime(i.getTime() + 24 * e * 60 * 60 * 1e3);
        var n = "; expires=" + i.toGMTString();
        document.cookie = o + "=" + a + n + "; path=/; " + t;
      } catch (t) {
      //  console.log(t.message);
      }
    }
    function o() {
      try {
        var e = "domain=." + document.domain;
        document.cookie =
          "popup-module-mailchimp=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; " +
          e;
      } catch (e) {
      //  console.log(e.message);
      }
    }
    function a() {
      try {
        var e = "popup-module-mailchimp";
        if (document.cookie.length > 0) {
          var t = document.cookie.indexOf(e + "=");
          if (-1 != t) {
            t = t + e.length + 1;
            var o = document.cookie.indexOf(";", t);
            return -1 == o && (o = document.cookie.length), unescape(
              document.cookie.substring(t, o)
            );
          }
        }
      } catch (e) {
        console.log(e.message);
      }
    }
    $("#popup-mailchimp").length &&
      ($("#popup-mailchimp").hasClass("d-none d-sm-block")
        ? roar.getWidthBrowser() >= 768 && e()
        : e());
  },
  handleVerticalMenu: function() {
    $(".category_trigger").on("click", function() {
      (roar.getWidthBrowser() < 768 || $("html").hasClass("touch")) &&
        ($(".shop_category").hasClass("is_open")
          ? ($(".shop_category").removeClass("is_open"), $(
              ".shop_category .submenu-group"
            ).slideUp())
          : ($(".shop_category").addClass("is_open"), $(
              ".shop_category .submenu-group"
            ).slideDown()));
    }), $(".shop_category .has-children>span>.fa").on("click", function() {
      var e = $(this).closest(".menu-item"), t = e.find(".submenu");
      (roar.getWidthBrowser() < 768 || $("html").hasClass("touch")) &&
        (e.hasClass("is_open")
          ? (e.removeClass("is_open"), t.slideUp())
          : (e.addClass("is_open"), t.slideDown()));
    });
  },
  updateGroupedPrice: function(){
    if($("#grouped-price").length == 0) return;
    var _price = 0;
    $(".grouped-product-item .grouped-checkbox").each(function() {
      if ($(this).is(':checked')) {
        _price = _price + parseFloat($($(this).data("id")).find("div.price").data("price"));
        $("#grouped-price").html('<span class="money">' + theme.Currency.formatMoney(_price, theme.settings.moneyFormat) + '</span>');
        window.builtin_currencies_used && theme.CurrencyPicker.convert("#grouped-price .money");
      }
    });
  },
  handleQuickshop: function(_wrapTarget) {
    var _wrapTarget = _wrapTarget || 'body';
    var _qid = "";
    let scriptMPLoaded = loadScriptAsync(theme.libs.mpopup);
    scriptMPLoaded.then(function(){
      return $(_wrapTarget).find('.quickview .quick_view').magnificPopup({
        type: 'ajax',
        preloader: !0,
        tLoading: "",
        mainClass: "quickview",
        removalDelay: 200,
        gallery: { enabled: false },
        callbacks: {
          ajaxContentAdded  : function() {
            roar.handleReviews();
            var sections = new theme.Sections();
            sections.register('product-quickview-template', theme.Product);
            //roar.initCountdown();
            window.builtin_currencies_used && theme.CurrencyPicker.convert("#ProductSection-product-quickview-template .money");
        Shopify.PaymentButton.init();
            var e = $(".quickview").find(".add-to-wishlist");
            e
            .attr("title", e.attr("data-added"))
            .addClass("added")
            .find("span")
            .text(e.attr("data-added"));
            setTimeout(function(){ $(window).trigger('resize'); }, 1000);
          }
        }
      }), !1;
    });
  },
  
  //#region - collection page functions
  mapClearFilter: function() {
    $(".mfilter-box .column").each(function() {
      var e = $(this);
      e.find("input:checked").length > 0 &&
        e.find(".clear").on("click", function(t) {
          var o = [];
          Shopify.queryParams.constraint &&
            (o = Shopify.queryParams.constraint.split(
              "+"
            )), e.find("input:checked").each(function() {
            var e = $(this), t = e.val();
            if (t) {
              var a = o.indexOf(t);
              a >= 0 && o.splice(a, 1);
            }
          }), o.length
            ? (Shopify.queryParams.constraint = o.join("+"))
            : delete Shopify.queryParams
                .constraint, roar.filterAjaxClick(), t.preventDefault();
        });
    });
  },
  mapSingleFilter: function() {
    $(
      "body"
    ).on("change", ".advanced-filter .field:not(.disable) input", function() {
      var e = $(this).parent(), t = $(this).val(), o = [];
      if (
        (Shopify.queryParams.constraint &&
          (o = Shopify.queryParams.constraint.split(
            "+"
          )), !window.enable_filter_multiple_choice && !e.hasClass("active"))
      ) {
        var a = e.parents(".advanced-filter").find(".active");
        a.length > 0 &&
          a.each(function() {
            var e = $(this).data("handle");
            if (($(this).removeClass("active"), e)) {
              var t = o.indexOf(e);
              t >= 0 && o.splice(t, 1);
            }
          });
      }
      if (t) {
        var i = o.indexOf(t);
        0 > i
          ? (o.push(t), e.addClass("active"))
          : (o.splice(i, 1), e.removeClass("active"));
      }
      o.length
        ? (Shopify.queryParams.constraint = o.join("+"))
        : delete Shopify.queryParams.constraint, roar.filterAjaxClick();
    });
  },
  mapSingleCollection: function() {
    $("body").on("click", ".advanced-collection .field", function(e) {
      var t = $(this), o = t.attr("href");
      t.hasClass("active") ||
        (roar.filterAjaxClick(o), $(".advanced-collection .field").removeClass(
          "active"
        ), t.addClass("active"), e.preventDefault());
    });
  },
  mapSingleSort: function() {
    $("body").on("change", ".advanced-sortby .field", function(e) {
      var t = $(this), o = t.val();
      (Shopify.queryParams.sort_by = o), roar.filterAjaxClick(), e.preventDefault();
    });
  },
  mapSingleLimit: function() {
    $("body").on("change", ".advanced-limit .field", function(e) {
      var t = $(this), o = t.val();
      (Shopify.queryParams.view = o), roar.filterAjaxClick(), e.preventDefault();
    });
  },
  mapSinglePagination: function() {
    $(
      "body"
    ).on("click", "#mfilter-content-container .advanced-pagination a", function(
      e
    ) {
      var t = $(this);
      delete Shopify.queryParams.page, delete Shopify.queryParams
        .constraint, delete Shopify.queryParams.q, delete Shopify.queryParams
        .sort_by, roar.filterAjaxClickPaging(t.attr("href")), e.preventDefault();
    });
  },
  mapFilters: function() {
    roar.handleGridList(),
   // roar.handleShopView(),
    roar.mapPagination()
  },
  mapPaginationCallback: function(){
    roar.handleGridList(),
   // roar.handleShopView(),
    roar.handleQuickshop(), 
    roar.handleReviews(), 
    roar.initCountdown(), 
   // roar.initProductQuickShopItem("#mfilter-content-container"), 
    window.builtin_currencies_used && theme.CurrencyPicker.convert("#sandbox .money");
  },
  mapPagination: function () {
    $( document.body ).on('click', '.fastor_ajax_load_button a', function(e) {
      e.preventDefault();

      if ($('.pagination a.next').length) {
        $('.fastor_ajax_load_button a').attr('data-processing', 1);
        var href = $('.pagination a.next').attr('href'),
            loading_items = $('.fastor_ajax_load_button a').attr('data-loading-items'),
            no_more = $('.fastor_ajax_load_button a').attr('data-no-more');

        $('.fastor_ajax_load_button').hide();
        $('.pagination').before('<div class="fastor_ajax_load_more_loader animated fadeIn"><a href="#"><i class="icon-px-outline-load"></i>&nbsp;&nbsp;<span>'+ loading_items +'</span></a></div>');

        $.get(href, function(response) {
          $('.advanced-pagination').html($(response).find('.advanced-pagination').html());

          $(response).find('.product-list .product').each(function() {
            $('.product-list .product:last').after($(this));
          });
          $(response).find('.product-grid .product-item').each(function() {
            $('.product-grid .product-item:last').after($(this));
          });
          roar.mapPaginationCallback();
          $('.fastor_ajax_load_more_loader').fadeOut("slow");
          $('.fastor_ajax_load_button').fadeIn("slow");

          $('.fastor_ajax_load_button a').attr('data-processing', 0);

          if ($('.pagination a.next').length == 0) {
            $('.fastor_ajax_load_button').addClass('finished').removeClass('fastor_ajax_load_more_hidden');
            $('.fastor_ajax_load_button a').show().html( no_more ).addClass('disabled');
          }
        });
      }
      else {
        var no_more = $('.fastor_ajax_load_button a').attr('data-no-more');
        $('.fastor_ajax_load_button').addClass('finished').removeClass('fastor_ajax_load_more_hidden');		                
        $('.fastor_ajax_load_button a').show().html( no_more ).addClass('disabled');
      }
    });

    if ( $('.fastor_ajax_load_button').hasClass('fastor_ajax_load_more_hidden') ) {

      var buffer_pixels = Math.abs(0);
       $(window).scroll(function(){
        var $elem = $('.fastor_ajax_load_button a');
        if($elem.length > 0){
          var $window = $(window);

          var docViewTop = $window.scrollTop();
          var docViewBottom = docViewTop + $window.height();

          var elemTop = $elem.offset().top;
          var elemBottom = elemTop + $elem.height();
         // console.log(elemBottom  + " -- " + docViewBottom  + " -- " + elemTop  + " -- " + docViewTop );    
          if(( elemBottom <= docViewBottom) && (elemTop >= docViewTop) && 0 == $ ('.fastor_ajax_load_button a').attr ('data-processing'))
          {
			 $elem.trigger ('click');     
          }
        }
      });
    }
  },
  filterCreateUrl: function(e) {
    var t = $.param(Shopify.queryParams).replace(/%2B/g, "+");
    return e ? "" != t ? e + "?" + t : e : location.pathname + "?" + t;
  },
  updateQueryStringParameter: function(uri, key, value) {
    var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
    var separator = uri.indexOf('?') !== -1 ? "&" : "?";
    if (uri.match(re)) {
      return uri.replace(re, '$1' + key + "=" + value + '$2');
    }
    else {
      return uri + separator + key + "=" + value;
    }
  },
  filterCreateUrlPaging: function(e) {
    var p = 1;
    var a_p = e.split("page=");
    if(a_p.length > 1) {
    	p = parseInt(a_p[1]);
    }
    return roar.updateQueryStringParameter(window.location.href, 'page', p) ;
  },
  filterAjaxClick: function(e) {
    delete Shopify.queryParams.page;
    var t = roar.filterCreateUrl(e);
    roar.filterGetContent(t);
  },
  filterAjaxClickPaging: function(e) {
    delete Shopify.queryParams.page;
    var t = roar.filterCreateUrlPaging(e);
    roar.filterGetContent(t);
  },
  filterGetContent: function(e) {
    $.ajax({
      type: "get",
      url: e,
      beforeSend: function() {
        roar.destroyCountdown(), $("body")
          .addClass("is_loading")
          .removeClass("open_filter");
      },
      success: function(t) {
        var o = t.match("<title>(.*?)</title>")[1];
        $(t).find(".breadcrumb-content").length &&
          $(".breadcrumb-content").html(
          $(t).find(".breadcrumb-content").html()
        ),$(".category-info").remove(), $(t).find(".category-info").length &&
          $("#mfilter-content-container").prepend(
            $(t).find(".category-info")
          ), $("#sandbox")
          .empty()
          .html($(t).find("#sandbox").html()), $(
          ".mfilter-box .mfilter-content"
        )
          .empty()
          .html($(t).find(".mfilter-box .mfilter-content").html()), $(
          "#mfilter-content-container .advanced-pagination"
        )
          .empty()
          .html(
            $(t).find("#mfilter-content-container .advanced-pagination").html()
          ), $(".page-top").empty().html($(t).find(".page-top").html()), History.pushState(
          { param: Shopify.queryParams },
          o,
          e
        ), setTimeout(function() {
          $("html,body").animate(
            { scrollTop: $("body #sandbox").offset().top },
            500,
            "swing"
          );
        }, 100), $("body").removeClass(
          "is_loading"
        ), roar.mapClearFilter(),
          roar.handleQuickshop(), 
          roar.handleReviews(), 
          roar.initCountdown(), 
        //  roar.initProductQuickShopItem("#mfilter-content-container"), 
          roar.initFilterSidebar(), 
          window.builtin_currencies_used && theme.CurrencyPicker.convert("#sandbox .money");
      },
      error: function() {
        $("body").removeClass("is_loading");
      }
    });
  },
  //#endregion

  handleReviews: function() {
    if (window.reviews_enable == "1"){
      "undefined" != typeof SPR && (SPR.registerCallbacks(), SPR.initRatingHandler(), SPR.initDomEls(), SPR.loadProducts(), SPR.loadBadges()); 
    }else if(window.reviews_enable == "2"){
      $.aliReviewsAddRatingCollection();
    }
  },
  convertToSlug: function(e) {
    return e.toLowerCase().replace(/[^\w\u00C0-\u024f]+/g, "-").replace(/^-+|-+$/g, "");
  },
  getWidthBrowser: function() {
    var e;
    return "number" == typeof window.innerWidth
      ? (e = window.innerWidth)
      : document.documentElement &&
          (document.documentElement.clientWidth ||
            document.documentElement.clientHeight)
          ? (e = document.documentElement.clientWidth)
          : document.body &&
              (document.body.clientWidth || document.body.clientHeight) &&
              (e = document.body.clientWidth), e;
  },
  handleScrollToTop: function() {
    $(window).scroll(function() {
      if ($(window).width() > 767) {
        var scrollTop = $(this).scrollTop();
        var height = $(this).height();
        
        var offsetTop = 1;
        if (scrollTop > 0) {
          offsetTop = scrollTop + (height / 2);
        }
        
        var btnTop = $('#scroll-top');
        if (1e3 > offsetTop) {
          btnTop.removeClass('on');
        }
        else {
          btnTop.addClass('on');
        }
      }
      else {
        var scrollTop = $(this).scrollTop();
        if ($('#shopify-section-mobile-nav').length >0 ) {
          var height = $('#shopify-section-mobile-nav').offset().top + $('#shopify-section-mobile-nav').height();
        }else{
        	var height = $('header').offset().top + $('header').height();
        }
        
        var btnTop = $('#widgets');
        if (height > scrollTop) {
          btnTop.removeClass('on');
        }
        else {
          btnTop.addClass('on');
        }
      }
    }), $("#scroll-top").on("click", function(e) {
      e.preventDefault(), $("html,body").animate({ scrollTop: 0 }, 800, "swing");
    });
  },
  handleGMap: function() {
    $("#contact_map").length &&
      $().gMap &&
      $("#contact_map").gMap({
        zoom: 17,
        scrollwheel: !1,
        maptype: "ROADMAP",
        markers: [
          {
            address: window.contact_map_address,
            html: "_address",
            icon: { iconsize: [188, 68], iconanchor: [0, 68] }
          }
        ]
      });
  },
  handleGridList: function() {
    $(document).on("click", "#grid", function() {
      $("#mfilter-content-container").removeClass("list").addClass("grid");
    }), $(document).on("click", "#list", function() {
      $("#mfilter-content-container").removeClass("grid").addClass("list"),
      $("body").removeClass("flex-view-2 flex-view-3 flex-view-4 flex-view-6").addClass("flex-view-1");
    });
  },
  handleSmoothScroll: function() {
    $(document).on("click", ".smoothscroll", function(e) {
      e.preventDefault();
      var t = $(this).attr("href");
      $(t).trigger("click"), setTimeout(function() {
        $("html,body").animate(
          { scrollTop: $(t).offset().top - 100 },
          800,
          "swing"
        );
      }, 300);
    });
  },
  handleDropdown: function() {
    $("[data-toggle='dropdown']").on("click", function() {
      $(this).parent().toggleClass("open");
    });
  }
};
/* end roar functions */

theme.ThePilot = (function() {
  var selectors = {
    sourceWrapper: '.rt-pilot',
    destination: '.rt-destination',
    arrivedClass: 'rt-arrived'
  }

  function _doPilot() {
    var dests = $(selectors.destination + ':not(.' + selectors.arrivedClass + ')');
    if(!dests.length) return false;
    for(var i = 0 ; i < dests.length ; i++) {
      var _el = $(dests[i]), _id = _el.attr('id'), _template = $(selectors.sourceWrapper + '[data-destination-id=' + _id + '] template').html();
      _el.html(_template);
      //_el.addClass(selectors.arrivedClass);
    }
    return true;
  }

  return {
    doPilot: _doPilot
  };
})();
/* currency picker */
theme.CurrencyPicker = (function() {
  var selectors = {
    selector: '.money',
    container: '.currency__picker',
    currenciesList: '.currency__picker .currencies__list',
    currencyPicker: '.currency__picker .currency',
    currencyActive: '.currency__picker .currency.active',
    currencyCurrent: '.currency__picker .currency__current',
    currencyNotification: '.currency__notification'
  };

  var settings = {
    currency_format: '',
    shop_currency: '',
    default_currency: '',
    money_with_currency_format: '',
    money_format: '',
    auto_switch: 'true',
    original_price: 'true'
  };

  function _detectCurrency() {
    if (settings.auto_switch == 'false') {
      return false;
    }

    var cookieCurrency = Currency.cookie.read();

    if (cookieCurrency == null) {
      $.getJSON('//ipinfo.io/json', function(data) {
        var location = JSON.parse(JSON.stringify(data, null, 2));

        if (typeof location.country != 'undefined') {
          $.getJSON('//restcountries.eu/rest/v1/alpha/' + location.country, function (data) {
            var currencies = data.currencies;
            var currency = currencies[0];

            $(selectors.currencyPicker + '[data-code="' + currency + '"]').trigger('click');
          });
        }
      });
    }
  }

  function _defaultCurrency() {
    if (settings.original_price == 'false') {
      return false;
    }

    var currency = Currency.currentCurrency;
    var cookieCurrency = Currency.cookie.read();
    var shopCurrency = settings.shop_currency;
    if (cookieCurrency) {
      currency = cookieCurrency;
    }

    $(selectors.selector).each(function() {
      var that = $(this);
      that.removeAttr('data-currency-default');

      if (shopCurrency != currency) {
        var money = that.attr('data-currency-' + shopCurrency);
        if (shopCurrency == 'USD') {
          money += ' USD';
        }
        that.attr('data-currency-default', money);
      }
    });
  }

  function _notifyCurrency() {
    if (!$(selectors.currencyNotification).length) {
      return;
    }

    if (Currency.currentCurrency == settings.shop_currency) {
      $(selectors.currencyNotification).removeClass('loaded').slideUp();
      return;
    }

    $(selectors.currencyNotification).each(function() {
      var that = $(this);
      var html = that.data('html');

      var replace = '<strong>' + Currency.currentCurrency + '</strong>';
      html = html.replace(new RegExp('{{ current_currency }}', 'g'), replace);
      that.html(html);

      if (!that.hasClass('loaded')) {
        that.addClass('loaded').slideDown();
      }
    });
  }
  function _currencyJs(){
    var container = $(selectors.container);
    settings.currency_format = container.find('.currency_format').val();
    settings.shop_currency = container.find('.shop_currency').val();
    settings.default_currency = container.find('.default_currency').val();
    settings.money_with_currency_format = container.find('.money_with_currency_format').val();
    settings.money_format = container.find('.money_format').val();
    settings.auto_switch = container.find('.auto_switch').val();
    settings.original_price = container.find('.original_price').val();

    Currency.format = settings.currency_format;
    var shopCurrency = settings.shop_currency;
    Currency.moneyFormats[shopCurrency].money_with_currency_format = settings.money_with_currency_format;
    Currency.moneyFormats[shopCurrency].money_format = settings.money_format;
    var defaultCurrency = settings.default_currency;

    var cookieCurrency = Currency.cookie.read();

    $('.money .money').each(function() {
      $(this).parents('.money').removeClass('money');
    });

    $(selectors.selector).each(function() {
      var that = $(this);
      if (typeof that.attr('data-currency-' + settings.shop_currency) == 'undefined') {
        var money = that.text();
        that.attr('data-currency-' + settings.shop_currency, money);
      }
    });

    if (cookieCurrency == null) {
      if (shopCurrency !== defaultCurrency) {
        Currency.convertAll(shopCurrency, defaultCurrency, selectors.selector);
      }
      else {
        Currency.currentCurrency = defaultCurrency;
      }
    }
    else if ($(selectors.currenciesList).length && $(selectors.currenciesList + ' .currency[data-code=' + cookieCurrency + ']').length === 0) {
      Currency.currentCurrency = shopCurrency;
      Currency.cookie.write(shopCurrency);
    }
    else if (cookieCurrency === shopCurrency) {
      Currency.currentCurrency = shopCurrency;
    }
    else {
      Currency.convertAll(shopCurrency, cookieCurrency, selectors.selector);
    }

    // change currencies
    $(selectors.currenciesList).on('click', '.currency:not(.active)', function() {
      var newCurrency = $(this).data('code');
      Currency.convertAll(Currency.currentCurrency, newCurrency, selectors.selector);

      $(selectors.currencyPicker).removeClass('active');
      $(this).addClass('active');
      $(selectors.currencyCurrent).text(Currency.currentCurrency).attr('data-code', Currency.currentCurrency);
      _defaultCurrency();
      _notifyCurrency();
    });

    // change product variants
    var original_selectCallback = window.selectCallback;
    var selectCallback = function(variant, selector) {
      original_selectCallback(variant, selector);
      Currency.convertAll(shopCurrency, $(selectors.currencyActive).attr('data-code'), selectors.selector);

      $(selectors.currencyPicker).removeClass('active');
      $(selectors.currenciesList + ' .currency[data-code=' + Currency.currentCurrency + ']').addClass('active');
      $(selectors.currencyCurrent).text(shopCurrency).attr('data-code', shopCurrency);
      _defaultCurrency();
    };

    $(selectors.currencyPicker).removeClass('active');
    $(selectors.currenciesList + ' .currency[data-code=' + Currency.currentCurrency + ']').addClass('active');
    $(selectors.currencyCurrent).text(Currency.currentCurrency).attr('data-code', Currency.currentCurrency);

    _defaultCurrency();
    _detectCurrency();
    _notifyCurrency();
  }
  function _currencyLiquid() {
    // change currencies
    $(selectors.currenciesList).off('click', '.currency:not(.active)');
    $(selectors.currenciesList).on('click', '.currency:not(.active)', function() {
      var new_currency = $(this).data('code');
      var location = window.location;
      var new_url = location.pathname + location.search + location.hash;
      
      
      var form = document.createElement('form');
      form.setAttribute('action', '/cart/update');
      form.setAttribute('method', 'POST');
      form.setAttribute('style', 'display:none');

      var input_form_type = document.createElement('input');
      input_form_type.setAttribute('type', 'hidden');
      input_form_type.setAttribute('name', 'form_type');
      input_form_type.setAttribute('value', 'currency');

      var input_currency = document.createElement('input');
      input_currency.setAttribute('type', 'hidden');
      input_currency.setAttribute('name', 'currency');
      input_currency.setAttribute('value', new_currency);

      var input_return_to = document.createElement('input');
      input_return_to.setAttribute('type', 'hidden');
      input_return_to.setAttribute('name', 'return_to');
      input_return_to.setAttribute('value', new_url);

      form.appendChild(input_form_type);
      form.appendChild(input_currency);
      form.appendChild(input_return_to);

      $(form).appendTo('body').submit();
    });
  }

  function _init() {
    if (!$(selectors.currenciesList).length) {
      return;
    }
    if ($(selectors.currenciesList).hasClass('ml__js')) {
      _currencyJs();
    }
    else {
      _currencyLiquid();
    }
    
  }

  function _convert(target) {
    if (!$(selectors.currenciesList).length) {
      return;
    }

    $(target).each(function() {
      var that = $(this);
      if (typeof that.attr('data-currency-' + settings.shop_currency) == 'undefined') {
        var money = that.text();
        that.attr('data-currency-' + settings.shop_currency, money);
      }
    });

    Currency.convertAll(settings.shop_currency, $(selectors.currencyActive).attr('data-code'), target, settings.currency_format);
    _defaultCurrency();
  }

  function _convertAll() {
    if (!$(selectors.currenciesList).length) {
      return;
    }

    $(selectors.selector).each(function() {
      var that = $(this);
      if (typeof that.attr('data-currency-' + settings.shop_currency) == 'undefined') {
        var money = that.text();
        that.attr('data-currency-' + settings.shop_currency, money);
      }
    });

    Currency.convertAll(settings.shop_currency, $(selectors.currencyActive).attr('data-code'), selectors.selector);
    _defaultCurrency();
  }

  return {
    init: _init,
    convert: _convert,
    convertAll: _convertAll
  };
})();

theme.LanguagePicker = (function() {
  var selectors = {
    language: '.language__picker .language__switcher',
    languagePicker: '.language__picker .language',
    languageCurrent: '.language__picker .language__current',
    selector: '#weketing_google_translate_element'
  };
  
  function _convert(code) {
    $(selectors.selector + ' .goog-te-combo').val(code);
    var element = document.getElementsByClassName('goog-te-combo')[0];
    event = new Event('change');
    element.dispatchEvent(event);
  }

  function _init() {
    $(selectors.language).empty();
    $(selectors.languageCurrent).empty();
    /*
    if (!$(selectors.selector).length) {
      return;
    }
    */
    
    /*$(selectors.selector).bind('google_translate', function() {
      setTimeout(function() {
        
        $(selectors.selector + ' .goog-te-combo option').each(function(index) {
          var that = $(this);
          var langCode = that.val();
          var langText = that.text();
          
          if (index == 0) {
            $(selectors.languageCurrent).text(langText);
          }
          if (langCode != '') {
            var langage = '<li class="language notranslate" data-code="' + langCode + '">' + langText + '</li>';
            if (index == 0) {
              langage = '<li class="language active notranslate" data-code="' + langCode + '">' + langText + '</li>';
            }
            $(selectors.language).append(langage);
          }
        });
      }, 1000);
    });*/
    //$(selectors.selector).bind('google_translate', function() {

      var observer = new MutationObserver(function (mutations, me) {
        var canvas = document.getElementsByClassName('goog-te-combo')[0]
        if (canvas) {
          var settings = JSON.parse(JSON.stringify(weketingJS.settingsJS[8]));
          var default_language = settings.default_language ;
          var custom_languages = settings.custom_languages;
          var languages = weketingSGT.languages();
          var langCode = localStorage.getItem('roarStorage_language');
          for (var i = 0; i < custom_languages.length - 1; i++) {
            if (custom_languages[i] == default_language) {
              custom_languages.pop();
              break;
            }
          }
          for (var i = 0; i < custom_languages.length; i++) {
            if (custom_languages[i] == langCode) {
              default_language = langCode;
              break;
            }
          }
          for(var i = 0 ; i < $(selectors.language).length ; i++) {
            var _display_code = !1;
            var _curr_selector_language = $(selectors.language)[i];
            if($(_curr_selector_language).hasClass('lang-code-mode')) {
              _display_code = !0;
            }
            var _curr_selector_language_active = $(selectors.languageCurrent)[i];
            if (settings.enable == 'yes' && !$(_curr_selector_language).children().length) {
              var _custom_item_class = $(_curr_selector_language).attr('data-item-class');
              for (var j = 0; j < custom_languages.length; j++) {
                var langage = '<li class="language active notranslate ' + _custom_item_class + '" data-code="' + default_language + '">' + (_display_code == !0 ? default_language : languages[default_language]) + '</li>';
                if (custom_languages[j] != default_language) {
                  langage = '<li class="language notranslate ' + _custom_item_class + '" data-code="' + custom_languages[j] + '">' + (_display_code == !0 ? custom_languages[j] : languages[custom_languages[j]]) + '</li>';
                }
                $(_curr_selector_language).append(langage);
              }
              $(_curr_selector_language_active).text(languages[default_language]);
            }
          }
          _convert(default_language);

          me.disconnect(); // stop observing
          return;
        }
      });
      
      // start observing
      observer.observe(document, {
        childList: true,
        subtree: true
      });
    //});
    
    
    $('body').on('click', selectors.languagePicker + ':not(.active)', function() {
      var langCode = $(this).data('code');
      
      if (langCode != '') {
        var langText = $(this).text();

        $(selectors.languagePicker).removeClass('active');
        $(selectors.languagePicker + '[data-code="' + langCode + '"]').addClass('active');
        $(selectors.languageCurrent).text(langText);

        localStorage.setItem('roarStorage_language', langCode);

        _convert(langCode);
      }
    });
  }

  return {
    init: _init
  };
})();

/* section abstract */
window.theme = window.theme || {};
theme.Sections = function Sections() {
  this.constructors = {};
  this.instances = [];

  $(document)
  .on('shopify:section:load', this._onSectionLoad.bind(this))
  .on('shopify:section:unload', this._onSectionUnload.bind(this))
  .on('shopify:section:select', this._onSelect.bind(this))
  .on('shopify:section:deselect', this._onDeselect.bind(this))
  .on('shopify:block:select', this._onBlockSelect.bind(this))
  .on('shopify:block:deselect', this._onBlockDeselect.bind(this));
};
theme.Sections.prototype = _.assignIn({}, theme.Sections.prototype, {
  _createInstance: function(container, constructor) {
    var $container = $(container);
    var id = $container.attr('data-section-id');
    var type = $container.attr('data-section-type');

    constructor = constructor || this.constructors[type];

    if (_.isUndefined(constructor)) {
      return;
    }

    var instance = _.assignIn(new constructor(container), {
      id: id,
      type: type,
      container: container
    });

    this.instances.push(instance);
  },

  _onSectionLoad: function(evt) {
    if($('.rt-pilot', evt.target).length) {
      var _id = '#' + $($('.rt-pilot', evt.target)[0]).attr('data-container-id');
      var container = $(_id);
      if (container) {
        this._createInstance(container);
      }
    } else {
      var container = $('[data-section-id]', evt.target)[0];
      if (container) {
        this._createInstance(container);
      }
    }
  },

  _onSectionUnload: function(evt) {
    this.instances = _.filter(this.instances, function(instance) {
      var isEventInstance = (instance.id === evt.originalEvent.detail.sectionId);

      if (isEventInstance) {
        if (_.isFunction(instance.onUnload)) {
          instance.onUnload(evt);
        }
      }

      return !isEventInstance;
    });
  },

  _onSelect: function(evt) {
    theme.ThePilot.doPilot();
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.originalEvent.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onSelect)) {
      instance.onSelect(evt);
    }
    if(typeof theme !== 'undefined') {theme.roarAdminJs.init();}
  },

  _onDeselect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.originalEvent.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onDeselect)) {
      instance.onDeselect(evt);
    }
  },

  _onBlockSelect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.originalEvent.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onBlockSelect)) {
      instance.onBlockSelect(evt);
    }
  },

  _onBlockDeselect: function(evt) {
    // eslint-disable-next-line no-shadow
    var instance = _.find(this.instances, function(instance) {
      return instance.id === evt.originalEvent.detail.sectionId;
    });

    if (!_.isUndefined(instance) && _.isFunction(instance.onBlockDeselect)) {
      instance.onBlockDeselect(evt);
    }
  },

  register: function(type, constructor) {
    this.constructors[type] = constructor;

    $('[data-section-type=' + type + ']').each(function(index, container) {
      this._createInstance(container, constructor);
    }.bind(this));
  }
});
window.slate = window.slate || {};
theme.Images = (function() {
  /**
   * Preloads an image in memory and uses the browsers cache to store it until needed.
   *
   * @param {Array} images - A list of image urls
   * @param {String} size - A shopify image size attribute
   */

  function preload(images, size) {
    if (typeof images === "string") {
      images = [images];
    }

    for (var i = 0; i < images.length; i++) {
      var image = images[i];
      this.loadImage(this.getSizedImageUrl(image, size));
    }
  }

  /**
   * Loads and caches an image in the browsers cache.
   * @param {string} path - An image url
   */
  function loadImage(path) {
    new Image().src = path;
  }

  /**
   * Swaps the src of an image for another OR returns the imageURL to the callback function
   * @param image
   * @param element
   * @param callback
   */
  function switchImage(image, element, callback) {
    var size = this.imageSize(element.src);
    var imageUrl = this.getSizedImageUrl(image.src, size);

    if (callback) {
      callback(imageUrl, image, element); // eslint-disable-line callback-return
    } else {
      element.src = imageUrl;
    }
  }

  /**
   * +++ Useful
   * Find the Shopify image attribute size
   *
   * @param {string} src
   * @returns {null}
   */
  function imageSize(src) {
    var match = src.match(
      /.+_((?:pico|icon|thumb|small|compact|medium|large|grande)|\d{1,4}x\d{0,4}|x\d{1,4})[_\.@]/
    );

    if (match !== null) {
      return match[1];
    } else {
      return null;
    }
  }

  /**
   * +++ Useful
   * Adds a Shopify size attribute to a URL
   *
   * @param src
   * @param size
   * @returns {*}
   */
  function getSizedImageUrl(src, size) {
    if (size == null) {
      return src;
    }

    if (size === "master") {
      return this.removeProtocol(src);
    }

    var match = src.match(
      /\.(jpg|jpeg|gif|png|bmp|bitmap|tiff|tif)(\?v=\d+)?$/i
    );

    if (match != null) {
      var prefix = src.split(match[0]);
      var suffix = match[0];

      return this.removeProtocol(prefix[0] + "_" + size + suffix);
    }

    return null;
  }

  function removeProtocol(path) {
    return path.replace(/http(s)?:/, "");
  }

  return {
    preload: preload,
    loadImage: loadImage,
    switchImage: switchImage,
    imageSize: imageSize,
    getSizedImageUrl: getSizedImageUrl,
    removeProtocol: removeProtocol
  };
})();
/**
 * Currency Helpers
 * -----------------------------------------------------------------------------
 * A collection of useful functions that help with currency formatting
 *
 * Current contents
 * - formatMoney - Takes an amount in cents and returns it as a formatted dollar value.
 *
 * Alternatives
 * - Accounting.js - http://openexchangerates.github.io/accounting.js/
 *
 */

theme.Currency = (function() {
  var moneyFormat = '${{amount}}'; // eslint-disable-line camelcase

  function formatMoney(cents, format) {
    if (typeof cents === 'string') {
      cents = cents.replace('.', '');
    }
    var value = '';
    var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
    var formatString = format || moneyFormat;

    function formatWithDelimiters(number, precision, thousands, decimal) {
      thousands = thousands || ',';
      decimal = decimal || '.';

      if (isNaN(number) || number === null) {
        return 0;
      }

      number = (number / 100.0).toFixed(precision);

      var parts = number.split('.');
      var dollarsAmount = parts[0].replace(
        /(\d)(?=(\d\d\d)+(?!\d))/g,
        '$1' + thousands
      );
      var centsAmount = parts[1] ? decimal + parts[1] : '';

      return dollarsAmount + centsAmount;
    }

    switch (formatString.match(placeholderRegex)[1]) {
      case 'amount':
        value = formatWithDelimiters(cents, 2);
        break;
      case 'amount_no_decimals':
        value = formatWithDelimiters(cents, 0);
        break;
      case 'amount_with_comma_separator':
        value = formatWithDelimiters(cents, 2, '.', ',');
        break;
      case 'amount_no_decimals_with_comma_separator':
        value = formatWithDelimiters(cents, 0, '.', ',');
        break;
      case 'amount_no_decimals_with_space_separator':
        value = formatWithDelimiters(cents, 0, ' ');
        break;
      case 'amount_with_apostrophe_separator':
        value = formatWithDelimiters(cents, 2, "'");
        break;
    }

    return formatString.replace(placeholderRegex, value);
  }

  return {
    formatMoney: formatMoney
  };
})();

theme.Helpers = (function() {
  var touchDevice = false;

  var classes = {
    preventScrolling: 'prevent-scrolling'
  };

  var scrollPosition = window.pageYOffset;
  
  function setTouch() {
    touchDevice = true;
  }

  function isTouch() {
    return touchDevice;
  }
  
  function enableScrollLock() {
    scrollPosition = window.pageYOffset;
    document.body.style.top = '-' + scrollPosition + 'px';
    document.body.classList.add(classes.preventScrolling);
  }

  function disableScrollLock() {
    document.body.classList.remove(classes.preventScrolling);
    document.body.style.removeProperty('top');
    window.scrollTo(0, scrollPosition);
  }
  
  function prepareTransition(element) {
    element.addEventListener(
      'transitionend',
      function(event) {
        event.currentTarget.classList.remove('is-transitioning');
      },
      { once: true }
    );

    var properties = [
      'transition-duration',
      '-moz-transition-duration',
      '-webkit-transition-duration',
      '-o-transition-duration'
    ];

    var duration = 0;

    properties.forEach(function(property) {
      var computedValue = getComputedStyle(element)[property];

      if (computedValue) {
        computedValue.replace(/\D/g, '');
        duration || (duration = parseFloat(computedValue));
      }
    });

    if (duration !== 0) {
      element.classList.add('is-transitioning');
      element.offsetWidth;
    }
  }
  
  return {
    setTouch: setTouch,
    isTouch: isTouch,
    enableScrollLock: enableScrollLock,
    disableScrollLock: disableScrollLock,
    prepareTransition: prepareTransition
  };
})();
theme.LibraryLoader = (function() {
  var types = {
    link: 'link',
    script: 'script',
    randomString: Math.random().toString(36).substr(2, 5)
  };

  var status = {
    requested: 'requested',
    loaded: 'loaded'
  };

  var cloudCdn = 'https://cdn.shopify.com/shopifycloud/';

  var libraries = {
    youtubeSdk: {
      tagId: 'youtube-sdk',
      src: 'https://www.youtube.com/iframe_api',
      type: types.script
    },
    plyrShopifyStyles: {
      tagId: 'plyr-shopify-styles',
      src: cloudCdn + 'shopify-plyr/v1.0/shopify-plyr.css',
      type: types.link
    },
    modelViewerUiStyles: {
      tagId: 'shopify-model-viewer-ui-styles',
      src: cloudCdn + 'model-viewer-ui/assets/v1.0/model-viewer-ui.css',
      type: types.link
    },
    bannerStyles: {
      tagId: 'banner-css',
      src: 'https:' + theme.asset_url.substring(0, theme.asset_url.lastIndexOf("?")) + 'rt.cbuilder.scss.css',
      type: types.link
    },
    CssHelper: {
      tagId: 'css-helper',
      src: 'https:' + theme.asset_url.substring(0, theme.asset_url.lastIndexOf("?")) + 'rt.helper.scss.css',
      type: types.link
    }
  };

  function load(libraryName, callback) {
    var library = libraries[libraryName];

    if (!library) return;
    if (library.status === status.requested) return;

    callback = callback || function() {};
    if (library.status === status.loaded) {
      callback();
      return;
    }

    library.status = status.requested;

    var tag;

    switch (library.type) {
      case types.script:
        tag = createScriptTag(library, callback);
        break;
      case types.link:
        tag = createLinkTag(library, callback);
        break;
    }

    tag.id = library.tagId;
    library.element = tag;

    var firstScriptTag = document.getElementsByTagName(library.type)[0];
    firstScriptTag.parentNode.appendChild(tag, firstScriptTag);
  }

  function createScriptTag(library, callback) {
    var tag = document.createElement('script');
    tag.src = library.src + '?' + types.randomString;
    tag.addEventListener('load', function() {
      library.status = status.loaded;
      callback();
    });
    return tag;
  }

  function createLinkTag(library, callback) {
    var tag = document.createElement('link');
    tag.href = library.src + '?' + types.randomString;
    tag.rel = 'stylesheet';
    tag.type = 'text/css';
    tag.addEventListener('load', function() {
      library.status = status.loaded;
      callback();
    });
    return tag;
  }

  return {
    load: load
  };
})();

/**
 * Variant Selection scripts
 * ------------------------------------------------------------------------------
 *
 * Handles change events from the variant inputs in any `cart/add` forms that may
 * exist.  Also updates the master select and triggers updates when the variants
 * price or image changes.
 *
 * @namespace variants
 */

slate.Variants = (function() {
  /**
   * Variant constructor
   *
   * @param {object} options - Settings from `product.js`
   */
  function Variants(options) {
    this.$container = options.$container;
    this.product = options.product;
    this.singleOptionSelector = options.singleOptionSelector;
    this.originalSelectorId = options.originalSelectorId;
    this.enableHistoryState = options.enableHistoryState;
    this.currentVariant = this._getVariantFromOptions();

    $(this.singleOptionSelector, this.$container).on(
      'change',
      this._onSelectChange.bind(this)
    );
  }

  Variants.prototype = _.assignIn({}, Variants.prototype, {
    /**
     * Get the currently selected options from add-to-cart form. Works with all
     * form input elements.
     *
     * @return {array} options - Values of currently selected variants
     */
    _getCurrentOptions: function() {
      var currentOptions = _.map(
        $(this.singleOptionSelector, this.$container),
        function(element) {
          var $element = $(element);
          var type = $element.attr('type');
          var currentOption = {};

          if (type === 'radio' || type === 'checkbox') {
            if ($element[0].checked) {
              currentOption.value = $element.val();
              currentOption.index = $element.data('index');

              return currentOption;
            } else {
              return false;
            }
          } else {
            currentOption.value = $element.val();
            currentOption.index = $element.data('index');

            return currentOption;
          }
        }
      );

      // remove any unchecked input values if using radio buttons or checkboxes
      currentOptions = _.compact(currentOptions);

      return currentOptions;
    },

    /**
     * Find variant based on selected values.
     *
     * @param  {array} selectedValues - Values of variant inputs
     * @return {object || undefined} found - Variant object from product.variants
     */
    _getVariantFromOptions: function() {
      var selectedValues = this._getCurrentOptions();
      var variants = this.product.variants;

      var found = _.find(variants, function(variant) {
        return selectedValues.every(function(values) {
          return _.isEqual(variant[values.index], values.value);
        });
      });

      return found;
    },

    /**
     * Event handler for when a variant input changes.
     */
    _onSelectChange: function() {
      var variant = this._getVariantFromOptions();

      this.$container.trigger({
        type: 'variantChange',
        variant: variant
      });

      if (!variant) {
        return;
      }

      this._updateMasterSelect(variant);
      this._updateImages(variant);
      this._updatePrice(variant);
      this._updateSKU(variant);
      this.currentVariant = variant;

      if (this.enableHistoryState) {
        this._updateHistoryState(variant);
      }
    },

    /**
     * Trigger event when variant image changes
     *
     * @param  {object} variant - Currently selected variant
     * @return {event}  variantImageChange
     */
    _updateImages: function(variant) {
      var variantImage = variant.featured_image || {};
      var currentVariantImage = this.currentVariant.featured_image || {};

      if (
        !variant.featured_image ||
        variantImage.src === currentVariantImage.src
      ) {
        return;
      }

      this.$container.trigger({
        type: 'variantImageChange',
        variant: variant
      });
    },

    /**
     * Trigger event when variant price changes.
     *
     * @param  {object} variant - Currently selected variant
     * @return {event} variantPriceChange
     */
    _updatePrice: function(variant) {
      if (
        variant.price === this.currentVariant.price &&
        variant.compare_at_price === this.currentVariant.compare_at_price
      ) {
        return;
      }

      this.$container.trigger({
        type: 'variantPriceChange',
        variant: variant
      });
    },

    /**
     * Trigger event when variant sku changes.
     *
     * @param  {object} variant - Currently selected variant
     * @return {event} variantSKUChange
     */
    _updateSKU: function(variant) {
      if (variant.sku === this.currentVariant.sku) {
        return;
      }

      this.$container.trigger({
        type: 'variantSKUChange',
        variant: variant
      });
    },

    /**
     * Update history state for product deeplinking
     *
     * @param  {variant} variant - Currently selected variant
     * @return {k}         [description]
     */
    _updateHistoryState: function(variant) {
      if (!history.replaceState || !variant) {
        return;
      }

      var newurl =
        window.location.protocol +
        '//' +
        window.location.host +
        window.location.pathname +
        '?variant=' +
        variant.id;
      window.history.replaceState({ path: newurl }, '', newurl);
    },

    /**
     * Update hidden master select of variant change
     *
     * @param  {variant} variant - Currently selected variant
     */
    _updateMasterSelect: function(variant) {
      $(this.originalSelectorId, this.$container).val(variant.id);
    }
  });

  return Variants;
})();
window.theme = window.theme || {};

/* product page */
/* eslint-disable no-new */

//#region - product elements
theme.Product = (function() {
  function Product(container) {
    var $container = (this.$container = $(container));
    var sectionId = this.sectionId = $container.attr("data-section-id");
    var sectionType = $container.attr("data-section-type");
    this.settings = {
     // enableHistoryState: $container.data("enable-history-state") || false,
      mediaQueryMediumUp: 'screen and (min-width: 750px)',
      mediaQuerySmall: 'screen and (max-width: 749px)',
      bpSmall: false,
      enableHistoryState: $container.data('enable-history-state') || false,
      imageSize: null,
      namespace: ".product-page-section",
      sectionId: sectionId,
      sliderActive: false,
      variant_image_grouped: $container.attr("data-variant_image_grouped"),
      product_design: $container.attr("data-product_design"),
      product_image_count: $container.data("product_image_count")
    };

    this.selectors = {
      product: "#ProductSection-" + sectionId,
      addToCart: "#AddToCart-" + sectionId,
      addToCartText: "#AddToCartText-" + sectionId,
      stockText: ".stock-" + sectionId,
      SKU: ".variant-sku",
      originalSelectorId: "#ProductSelect-" + sectionId,
      productFeaturedImage: ".FeaturedImage-" + sectionId,
      productImageWrap: "#FeaturedImageZoom-" + sectionId,
      productMainImages: "#product-images-" + sectionId,
      productPreviewMainImages: ".product-preview-images-" + sectionId,
      singleOptionSelector: ".single-option-selector-" + sectionId,
      singleOptionSelectorId: "#single-option-selector-" + sectionId,
      singleOptionSwatches: "wrapper-swatches-" + sectionId,
      variationsSelector: "#variations-" + sectionId,
      variationSelector: ".variation-select-" + sectionId,
      qtyVariant: ".qty-variant-" + sectionId,
      threedId: ".threed-id-" + sectionId, 
      countDownId: ".countdown-"+ sectionId, 
      couponCode: "#coupon-code-"+ sectionId, 
      couponBtn: "#coupon-btn-"+ sectionId,
      sidebarSlide: ".sidebar-slick-vertical-"+sectionId,
      optionsSelect: "#single-option-selector-"+sectionId,
      stickCart: '#sticky-info-' + sectionId,
      cartAgree: '#product-cart__agree-' + sectionId,
      cartCheckout: '#product-buy__1click-' + sectionId,
      groupedProduct: '#products-grouped-' + sectionId,
      moreProducts: '#product-more-products-' + sectionId,
      groupedButton: '#grouped-add-button-' + sectionId,
      groupedCheckbox: '#products-grouped-' + sectionId + " .grouped-checkbox",
      imageZoomWrapper: '[data-image-zoom-wrapper]',
      productThumbImages: '.product-single__thumbnail--' + sectionId,
      productThumbImagesWrapper: '.product-single__thumbnails-' + sectionId,
      productThumbListItem: '.product-single__thumbnails-item',
      priceContainer: '[data-price]',
      regularPrice: '[data-regular-price]',
      salePrice: '[data-sale-price]',
      saleLabel:  '[data-sale-label]',
      unitPrice: '[data-unit-price]',
      unitPriceBaseUnit: '[data-unit-price-base-unit]',
      productPolicies: '[data-product-policies]',
      productMediaWrapper: '[data-product-single-media-wrapper]',
      productMediaTypeVideo: ':not(.slick-cloned)[data-product-media-type-video]',
      productMediaTypeModel: '[data-product-media-type-model]',
      stockCountdown: '#product-single__stock-' + sectionId,
      visitorCounter: '#product-single__visitor-' + sectionId,
      totalSold: '#product-single__sold-' + sectionId
    };
    this.classes = {
      hidden: 'hide',
      visibilityHidden: 'visibility-hidden',
      productOnSale: 'price--on-sale',
      productUnitAvailable: 'price--unit-available',
      productUnavailable: 'price--unavailable',
      productSoldOut: 'price--sold-out',
      activeClass: 'active-thumb',
      jsZoomEnabled: 'js-zoom-enabled',
    };
    this.$productPolicies = $(this.selectors.productPolicies, $container);
    // Stop parsing if we don't have the product json script tag when loading
    // section in the Theme Editor
    if (!$("#ProductJson-" + sectionId).html()) {
      return;
    }
    this.productSingleObject = JSON.parse(
      document.getElementById("ProductJson-" + sectionId).innerHTML
    );
    this.settings.zoomEnabled = $(this.selectors.imageZoomWrapper).hasClass(
      this.classes.jsZoomEnabled
    );
    this._initBreakpoints();
    this._stringOverrides();

    let _self = this;  
    let scriptLoaded = loadScriptAsync(theme.libs.slick);
    scriptLoaded.then(function(){
      _self._initVariants();
      _self._initSwatches();
      _self._initFeature();
      _self._initCompact();
      _self._initStickyImages();
      _self._initThumbnailsGallery();
      _self._initImages();
      _self._initSidebar();
      _self._initGallery();
      // add from handleProduct
      _self._initQuantity();
      _self._initHandleProduct();
      _self._checkoutCart();
      
      _self._initStockCountdown();
      _self._visitorCounter();
      _self._totalSold();
      
      sectionType == "product-template" && _self._initRelatedProducts();
      sectionType == "product-template" &&  _self._initViewedProducts();
      sectionType == "product-template" &&  _self._initStickyInfo();
      sectionType == "product-template" &&  _self._initGroupedProduct();
      sectionType == "product-template" &&  _self._initMoreProducts();

      /* custom events */
      _self._initMediaSwitch();
      _self._initProductVideo();
      _self._initModelViewerLibraries();
      _self._initShopifyXrLaunch();
    });
  }
  function _enableZoom(el) {
    var zoomUrl = $(el).data('zoom');
    $(el).zoom({
      url: zoomUrl
    });
  }

  function _destroyZoom(el) {
    $(el).trigger('zoom.destroy');
  }
  Product.prototype = _.assignIn({}, Product.prototype, {
    _stringOverrides: function() {
      theme.productStrings = theme.productStrings || {};
      $.extend(theme.strings, theme.productStrings);
    },
    _totalSold: function() {
    
      if (!$(this.selectors.totalSold).length) {
        return;
      }

      var that = $(this.selectors.totalSold);
      var min_qty = that.data('qty_min');
      var max_qty = that.data('qty_max');
      var min_time = that.data('time_min');
      var max_time = that.data('time_max');

      min_qty = Math.ceil(min_qty);
      max_qty = Math.floor(max_qty);
      min_time = Math.ceil(min_time);
      max_time = Math.floor(max_time);

      var qty = Math.floor(Math.random() * (max_qty - min_qty + 1)) + min_qty;
      qty = parseInt(qty);
      if (qty <= min_qty) {
        qty = min_qty;
      }
      if (qty > max_qty) {
        qty = max_qty;
      }
      that.html(that.html().replace('/count/', qty));

      var time = Math.floor(Math.random() * (max_time - min_time + 1)) + min_time;
      time = parseInt(time);
      if (time <= min_time) {
        time = min_time;
      }
      if (time > max_time) {
        time = max_time;
      }
      that.html(that.html().replace('/time/', time));

      that.addClass('active');

      if (that.find('img').first().length) {
        setInterval(function() {
          that.find('img').first().fadeIn(function() {
            $(this).css('visibility', 'visible');
          }).delay(1600).fadeIn(function() {
            $(this).css('visibility', 'hidden');
          }).delay(400);
        }, 2000);
      }
    },
  
  _visitorCounter: function() {
    
    if (!$(this.selectors.visitorCounter).length) {
      return;
    }
    
    var that = $(this.selectors.visitorCounter);
    var min = 1;
    var max = that.data('max');
    var interval = that.data('interval');

    var t = min;
    var r = max;
    t = Math.ceil(t);
    r = Math.floor(r);

    var o = Math.floor(Math.random() * (r - t + 1)) + t,
        n = ["1", "2", "4", "3", "6", "10", "-1", "-3", "-2", "-4", "-6"],
        h = "",
        e = "",
        l = ["10", "20", "15"],
        h = "",
        e = "",
        M = "";
    setInterval(function() {
      if (h = Math.floor(Math.random() * n.length), e = n[h], o = parseInt(o) + parseInt(e), min >= o) {
        M = Math.floor(Math.random() * l.length);
        var a = l[M];
        o += a;
      }
      if (o < 1 || o > max) {
        o = Math.floor(Math.random() * (r - t + 1)) + t;
      }

      that.find('strong').first().text(parseInt(o));
      that.addClass('active');
    }, interval * 1000);
  },
  
  _initStockCountdown: function() {
    
    if (!$(this.selectors.stockCountdown).length) {
      return;
    }
    var self = this;
    var that = $(self.selectors.stockCountdown);

    if (that.hasClass('is-fake')) {
      var total_items = 60;
      var min_items = that.data('min');
      var max_items = that.data('max');
      var remaining_items = randomNumber(min_items, max_items);
      var check_stock = false;
      var timer = null, timerinterval = null;
      var min_remaining_items = 1;
      var decrease_after = 1.7; 
      var decrease_after_first_time = 3; 

      progressBar();
      if (that.hasClass('is-visible')) {
        that.removeClass('hide');
      }

      function randomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
      }

      function progressBar() {
        that.find('.stock-countdown-message').first().html(theme.strings.onlyLeft.replace('{{ count }}', remaining_items));

        timer = setTimeout(function() {
          remaining_items--;
          if (remaining_items < min_remaining_items) {
            remaining_items = randomNumber(min_items, max_items);
          }

          that.find('.stock-countdown-message strong').text(remaining_items);
          updateMeter();

          if (remaining_items < min_items) {
            clearTimeout(timer);
          }
        }, 1000 * decrease_after_first_time);

        timerinterval = setInterval(function() {
          remaining_items--;
          if (remaining_items < min_remaining_items) {
            remaining_items = randomNumber(min_items, max_items);
          }

          that.find('.stock-countdown-message strong').text(remaining_items);
          updateMeter();

          if (remaining_items < min_items) {
            clearInterval(timerinterval);
          }
        }, 1000 * 60 * decrease_after);
      }

      function updateMeter() {
        var percent = 100 * remaining_items / total_items;
        that.find('.progress-bar span').css('width', percent + '%');
      }
    }
  },
  
  _updateStockCountdown: function(inventory_quantity) {
    var that = $(this.selectors.stockCountdown);

    if (that.hasClass('is-fake')) {
      that.removeClass('hide');
    }
    else {
      that.find('.stock-countdown-message').first().html(theme.strings.onlyLeft.replace('{{ count }}', inventory_quantity));
      that.find('.progress-bar span').first().css('width', '100%');
      that.removeClass('hide');
      setTimeout(function() {
        that.find('.progress-bar span').first().css('width', '28%');
      }, 500);
    }
  },
    _initBreakpoints: function() {
      var self = this;

      enquire.register(this.settings.mediaQuerySmall, {
        match: function() {
          /*
          // initialize thumbnail slider on mobile if more than four thumbnails
          if ($(self.selectors.productThumbImages).length > 4) {
            self._initThumbnailSlider();
          }
             */
          // destroy image zooming if enabled
          if (self.settings.zoomEnabled) {
            $(self.selectors.imageZoomWrapper).each(function() {
              _destroyZoom(this);
            });
          }

          self.settings.bpSmall = true;
        },
        unmatch: function() {
          /*
          if (self.settings.sliderActive) {
            self._destroyThumbnailSlider();
          }
          */
          self.settings.bpSmall = false;
          
        }
      });

      enquire.register(this.settings.mediaQueryMediumUp, {
        match: function() {
          if (self.settings.zoomEnabled) {
            $(self.selectors.imageZoomWrapper).each(function() {
              _enableZoom(this);
            });
          }
        }
      });
    },

    _initMediaSwitch: function() {
      
      var self = this;
      
      
      $(self.selectors.productMainImages).length > 0 && $(self.selectors.productMainImages).on('afterChange', function(event,slick, currentSlide) {

        var $activeMedia = $(
          self.selectors.productMediaWrapper +
          ":not(.slick-cloned)[data-slick-index='" +
          currentSlide +
          "']",
          self.$container
        );
        var $otherMedia = $(
          self.selectors.productMediaWrapper +
          ":not([data-slick-index='" +
          currentSlide +
          "'])",
          self.$container
        );
        $activeMedia.removeClass(self.classes.hidden).trigger('mediaVisible');
        $otherMedia.addClass(self.classes.hidden).trigger('mediaHidden');
       
      });
      
      if (!$(this.selectors.productThumbImages).length) {
        return;
      }


      $(this.selectors.productThumbImages)
        .on('click', function(evt) {
          evt.preventDefault();
          var $el = $(this);

          var mediaId = $el.data('thumbnail-id');

          self._switchMedia(mediaId);
          self._setActiveThumbnail(mediaId);
        })
        .on('keyup', self._handleMediaFocus.bind(self));
    },
    
    _switchMedia: function(mediaId) {
      
      var $currentMedia = $(
        this.selectors.productMediaWrapper +
        ':not(.' +
        this.classes.hidden +
        ')',
        this.$container
      );
      var $newMedia = $(
        this.selectors.productMediaWrapper +
        "[data-media-id='" +
        mediaId +
        "']",
        this.$container
      );

      var $otherMedia = $(
        this.selectors.productMediaWrapper +
        ":not([data-media-id='" +
        mediaId +
        "'])",
        this.$container
      );

      if(this.settings.product_design == 'carousel' && this.sectionId != "product-quickview-template" ) {
        var $newMedia = $(
          this.selectors.productMediaWrapper +
          ":not(.slick-cloned)[data-media-id='" +
          mediaId +
          "']",
          this.$container
        );
      }


      $currentMedia.trigger('mediaHidden');
      $newMedia.removeClass(this.classes.hidden).trigger('mediaVisible');
      $otherMedia.addClass(this.classes.hidden);
    },
    _setActiveThumbnail: function(mediaId) {
      if(this.settings.product_design == 'scroll') {
        var $activeMedia = $(
          this.selectors.productMediaWrapper +
          "[data-media-id='" +
          mediaId +
          "']",
          this.$container
        );
        var s_top = parseInt($activeMedia.offset().top) - 50;
        $("html,body").animate({ scrollTop: s_top}, "slow");
        
        var $otherMedia = $(
          this.selectors.productMediaWrapper +
          ":not([data-media-id='" +
          mediaId +
          "'])",
          this.$container
        );
        $activeMedia.trigger('mediaVisible');
        $otherMedia.trigger('mediaHidden');
        
        
        return;
      }
      
      if(this.settings.product_design == 'carousel' && this.sectionId != "product-quickview-template" ) {
        var _slickImages = $(this.selectors.productMainImages);
        var $nextMedia = $(
          this.selectors.productMediaWrapper +
          ":not(.slick-cloned)[data-media-id='" +
          mediaId +
          "']",
          this.$container
        );

        var pos =  $nextMedia.attr("data-slick-index");
        _slickImages.slick("slickGoTo", pos);

      }
      
      // If there is no element passed, find it by the current product image
      if (typeof mediaId === 'undefined') {
        mediaId = $(
          this.selectors.productMediaWrapper + ':not(.hide)',
          this.$container
        ).data('media-id');
      }

      var $thumbnailWrappers = $(
        this.selectors.productThumbListItem + ':not(.slick-cloned)',
        this.$container
      );

      var $activeThumbnail = $thumbnailWrappers.find(
        this.selectors.productThumbImages +
        "[data-thumbnail-id='" +
        mediaId +
        "']"
      );

      $(this.selectors.productThumbImages)
      .removeClass(this.classes.activeClass)
      .removeAttr('aria-current');

      $activeThumbnail.addClass(this.classes.activeClass);
      $activeThumbnail.attr('aria-current', true);

      if (!$thumbnailWrappers.hasClass('slick-slide')) {
        return;
      }

      var slideIndex = $activeThumbnail.parent().data('slick-index');

      $(this.selectors.productThumbImagesWrapper).slick('slickGoTo', slideIndex, true);
    },
    _initProductVideo: function() {
      var sectionId = this.settings.sectionId;

      $(this.selectors.productMediaTypeVideo, this.$container).each(function() {
        var $el = $(this);
        theme.ProductVideo.init($el, sectionId);
      });
    },

    _initModelViewerLibraries: function() {
      var $modelViewerElements = $(
        this.selectors.productMediaTypeModel,
        this.$container
      );
      if ($modelViewerElements.length < 1) return;
      theme.ProductModel.init($modelViewerElements, this.settings.sectionId);
    },

    _initShopifyXrLaunch: function() {
      var self = this;
      $(document).on('shopify_xr_launch', function() {
        var $currentMedia = $(
          self.selectors.productMediaWrapper +
            ':not(.' +
            self.classes.hidden +
            ')',
          self.$container
        );
        $currentMedia.trigger('xrLaunch');
      });
    },
    _updateMedia: function(evt) {
      var variant = evt.variant;
      var mediaId = variant.featured_media.id;
      var sectionMediaId = this.settings.sectionId + '-' + mediaId;

      this._switchMedia(sectionMediaId);
      this._setActiveThumbnail(sectionMediaId);
    },
    _handleMediaFocus: function(evt) {
      if (evt.keyCode !== slate.utils.keyboardKeys.ENTER) return;

      var mediaId = $(evt.currentTarget).data('thumbnail-id');

      $(
        this.selectors.productMediaWrapper +
        "[data-media-id='" +
        mediaId +
        "']",
        this.$container
      ).focus();
    },
    
    
    _initMoreProducts: function() {
      var moreProductElements =this.selectors.moreProducts;
      var moreProducts =  $(moreProductElements).find("a.mproduct-item");
      moreProducts.length > 0 && moreProducts.on("click", function(e) {
        e.preventDefault();
        moreProducts.removeClass("active");
        $(this).addClass("active");
          var _url = $(this).data("url");
        return $.ajax({
          url:  _url,
          dataType: 'html',
          type: 'GET',
          beforeSend: function() {
            $(moreProductElements).find(".mproducts-list-detail").addClass("loading");
          },
          success: function(responsive) {
            $(moreProductElements).find(".mproducts-list-detail").html(responsive);
           // roar.initProductQuickShopItem(moreProductElements);
          },
          error: function(data) {
            console.log('ajax error');
          },
          complete: function() {
            roar.handleQuickshop(moreProductElements);
            $(moreProductElements).find(".mproducts-list-detail").removeClass("loading");
          }
        });
      }) 
    },
    _initGroupedProduct: function(){
      var groupedProduct = $(this.selectors.groupedProduct);
      if(groupedProduct.length == 0) return;
      $(document).on('change', this.selectors.groupedCheckbox, function(evt) {
        if ($(this).is(':checked')) {
          $($(this).data("id")).removeClass("hide");
        }
        else {
          $($(this).data("id")).addClass("hide");
        }
        roar.updateGroupedPrice();
      });
      
      
      $(this.selectors.groupedButton).length > 0 &&
        $(this.selectors.groupedButton).unbind("click"), $(
        document
      ).on("click", this.selectors.groupedButton, function() {
        var self = $(this);
        Shopify.queue = [];
        groupedProduct.find(".grouped-checkbox").each(function() {
          if ($(this).is(':checked')) {
            var _variant_id = $($(this).data("id")).find("form .variation-select").val();
            if(_variant_id !== null){
              Shopify.queue.push({
                variantId: _variant_id,
                quantity: 1
              });
            }
          }
        });
        
          Shopify.moveAlong = function() {
            // If we still have requests in the queue, let's process the next one.
            //console.log(Shopify.queue);
            if (Shopify.queue.length) {
              var request = Shopify.queue.shift();
              var ajax = $.ajax({
                type: "POST",
                url: "/cart/add.js",
                async: !0,
                cache: !1,
                data: {quantity: request.quantity, id:request.variantId},
                dataType: "json",
                beforeSend: function() {
                  self.addClass("loading");
                },
                complete: function() {
                  roar.updateCart(self, false);
                },
                error: function(result) {
                  var response = $.parseJSON(result.responseText),
                      message = response.message + ": " + response.description;
                  alert(message);
                },
                success: function(result) {
                  Shopify.moveAlong();
                }
              });
            }
            // If the queue is empty, we will redirect to the cart page.
            else {
              window.location.href = "/cart";
            }
          };
          Shopify.moveAlong();
        return false;
      });
    },
    _initStickyInfo: function() {
      if ($(this.selectors.stickCart).length) {
        var self = this;
        $(window).scroll(function(){
          var scrollTop = $(this).scrollTop();
          if ($(self.selectors.addToCart).length) {
            var addToCart = $(self.selectors.addToCart);
            if ($(addToCart).length) {
              var addToCartOffset = $(addToCart).offset();
              if (scrollTop >= addToCartOffset.top) {
                if (!$('body').hasClass('show-sticky-info-product')) {
                  $('body').addClass('show-sticky-info-product')
                }
              } else {
                $('body').removeClass('show-sticky-info-product')
              }
            }
          }
        }),
          $("body").on("click", ".sticky-button.button-cart", function(evt) {
          $(self.selectors.addToCart).length > 0 && $(self.selectors.addToCart).trigger("click");
        });
      }
    },
    _checkoutCart: function() {
      var self = this;var agree = $(self.selectors.cartAgree);
      if(agree.length == 0) return;
      $(document).on('DOMNodeInserted', self.selectors.cartCheckout, function() {
        var that = $(this);
        setTimeout(function() {
          var shopify_payment_button = that.find('.shopify-payment-button__button');
          if (shopify_payment_button.length) {
            that.hide();

            setTimeout(function() {
              if (agree.is(':checked')) {
                shopify_payment_button.removeClass('btn-disabled');
              }
              else {
                shopify_payment_button.addClass('btn-disabled');
              }

              that.fadeIn();
            }, 300);
          }
        }, 0);
      });

      $(document).on('change', self.selectors.cartAgree, function(evt) {
        var agree = $(this);
        var shopify_payment_button = $(self.selectors.cartCheckout).find('.shopify-payment-button__button');

        if (agree.is(':checked')) {
          shopify_payment_button.removeClass('btn-disabled');
        }
        else {
          shopify_payment_button.addClass('btn-disabled');
        }
      });
    },
    _initHandleProduct: function() {
      if($("#main").next('#popup-product-sizechart').length == 0){
        $("#main").after($('#popup-product-sizechart'));
      }
      if($("#main").next('#popup-product-delivery').length == 0){
        $("#main").after($('#popup-product-delivery'));
      }
      if($("#main").next('#popup-product-question').length == 0){
        $("#main").after($('#popup-product-question'));
      }
      $(".button-product-delivery").on("click", function(e) {
        
        var _src = $(this).data('question'),
            _qid = $(this).data("_qid");
        $.magnificPopup.open({
          items: { src: "#popup-product-delivery", type: "inline" },
          tLoading: "",
          mainClass: "popup-module mfp-with-zoom",
          removalDelay: 200
        }), !1;
        
        if($('.quickview .mfp-content').find('#popup-product-question').length > 0 
           ||$('.quickview .mfp-content').find('#popup-product-delivery').length > 0 
          ||$('.quickview .mfp-content').find('#popup-product-sizechart').length > 0 
          ){
          $(".quickview.mfp-wrap").addClass('_reopen');$(".quickview.mfp-wrap").data('_qid', _qid);
        }
        return;
      }),
      $(".button-product-question").on("click", function(e) {
        
        var _src = $(this).data('question'),
            _qid = $(this).data("_qid");
        $.magnificPopup.open({
          items: { src: "#popup-product-question", type: "inline" },
          tLoading: "",
          mainClass: "popup-module mfp-with-zoom",
          removalDelay: 200
        }), !1;
        
        if($('.quickview .mfp-content').find('#popup-product-question').length > 0 
          ||$('.quickview .mfp-content').find('#popup-product-sizechart').length > 0 
          ){
          $(".quickview.mfp-wrap").addClass('_reopen');$(".quickview.mfp-wrap").data('_qid', _qid);
        }
        return;
      }), $(".button-product-sizechart").on("click", function(e) {
        
        var _src = $(this).data('sizechart'),
            _qid = $(this).data("_qid");
         $.magnificPopup.open({
          items: { src: _src, type: "inline" },
          tLoading: "",
          mainClass: "popup-module mfp-with-zoom",
          removalDelay: 200
        }),  !1;
        if($('.quickview .mfp-content').find('#popup-product-sizechart').length > 0 
           || $('.quickview .mfp-content').find('#popup-product-question').length > 0
          ){
          $(".quickview.mfp-wrap").addClass('_reopen');$(".quickview.mfp-wrap").data('_qid', _qid);
        }
        return;
      }),$(document).on("click", "#tabProduct a", function(e) {
        e.preventDefault(), $(this).tab("show");
      })
    },
    _initRelatedProducts: function() {
      if($("#productsRelated ").length == 0) return;
      let _selector = '#productsRelated .splide';
      if($(_selector).length) {
        let _slider = new Splide( _selector, { updateOnMove: true });
        _slider.on('mounted moved', debounce(function() {
            $(_slider.root).find('.splide__slide').removeClass('is-last-visible');
            $(_slider.root).find('.splide__slide[tabindex=0]').last().addClass('is-last-visible');
        }, 2000));
        _slider.mount();
      } 
      roar.handleQuickshop(_selector);
      
    },
    _initViewedProducts: function() {
      var ls = RoarCookie.cookie.rtread('rt-recent');
      var product_handle = $(".templateProduct #recently-viewed-products").data("handle");
      var product_id = $(".templateProduct #recently-viewed-products").data("id");
      var product_limit = $(".templateProduct #recently-viewed-products").data("limit");
      if(ls != null){ 
        ls = ls.split(',');
        var ls = ls.reverse();
        if(ls.length > 1){
          $("#recently-viewed-products").show()
        } else if (ls != product_handle) {
         $("#recently-viewed-products").show()
        }
        $.ajax({
          url:  '/search?view=viewed&q='+ls+'_sp_'+product_id,
          dataType: 'html',
          type: 'GET',
          success: function(responsive) {
            $('#recently-viewed-products').html(responsive);
            //  roar.initProductQuickShopItem('#recently-viewed-products');
          },
          error: function(data) {
            console.log('ajax error');
          },
          complete: function() {
            if($("#productsViewed ").length == 0) return;
            let _selector = '#productsViewed .splide';
            if($(_selector).length) {
              let _slider = new Splide( _selector, { updateOnMove: true });
              _slider.on('mounted moved', debounce(function() {
                $(_slider.root).find('.splide__slide').removeClass('is-last-visible');
                $(_slider.root).find('.splide__slide[tabindex=0]').last().addClass('is-last-visible');
              }, 2000));
              _slider.mount();
            } 
            roar.handleQuickshop(_selector);
          }
        }); 
        if(ls.indexOf(product_handle)< 0 ){
          if(ls.length >= product_limit){
            ls.pop();
          }
          ls.push(product_handle)
          try{ ls = ls.join(',');}catch(ex){}
        }
      }else{
        ls = product_handle;
      }
      RoarCookie.cookie.rtwrite('rt-recent',ls);
      },
    _initImages: function() {
      var self = this;
      var $images = $(self.selectors.productMainImages);
      var slide_rtl = false;
      if(parseInt(window.rtl) == 1) {
        slide_rtl = true;
      }
      // thumbnails
      if (this.settings.product_design == 'left' 
          ||this.settings.product_design == 'upsell' 
          || this.settings.product_design == 'bottom'
          || this.settings.product_design == 'compact2'
          || this.settings.product_design == 'split'
          || this.settings.product_design == 'sidebar'
          || this.settings.product_design == 'simple'
          || this.settings.product_design == 'full-screen') {
        if ($(self.selectors.productThumbImages).length > 0) {
          var $thumbnails = $(self.selectors.productThumbImagesWrapper);
       // var $thumbnails = $(self.selectors.productThumbImages).closest(".thumbnails");
          var vertical =  ($thumbnails.data('vertical') == '0') ? false : true;
          var _slideToShow = 4;
          var _slideThumbnailEnable = false;
          var media_count = $thumbnails.find(".product-single__thumbnails-item").length;
       //   console.log(media_count);
          (media_count > 4) ? (_slideToShow = 4 , _slideThumbnailEnable = true) : _slideToShow = media_count - 1;
          if($(".product-page-section").hasClass("product-has-sidebar")){
            (media_count > 3) ? (_slideToShow = 3, _slideThumbnailEnable = true) : _slideToShow = media_count - 1;
          }
        //   console.log(_slideThumbnailEnable);
          // Product thumnails and featured image slider
          if(_slideThumbnailEnable == true) {
            $images.length > 0 && 
            $images.not(".slick-initialized").slick({
              rtl: slide_rtl,
              slidesToShow: 1,
              slidesToScroll: 1,
              infinite: false,
              adaptiveHeight: true,
              asNavFor: $thumbnails,
              prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
              nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>'
            });
            $thumbnails.not(".slick-initialized").slick({
              slidesToShow: _slideToShow,
              slidesToScroll: 1,
            //   asNavFor: $images,
              focusOnSelect: true,
              vertical: vertical,
              infinite: false,
              prevArrow: '<span class="fa fa-angle-up slick-prev-arrow"></span>',
              nextArrow: '<span class="fa fa-angle-down slick-next-arrow"></span>',
              responsive: [
                {
                  breakpoint: 1024,
                  settings: {
                    slidesToShow: 3
                  }
                },
                {
                  breakpoint: 992,
                  settings: {
                    slidesToShow: 3
                  }
                },
                {
                  breakpoint: 768,
                  settings: {
                    slidesToShow: 3
                  }
                }
              ]
            });
          }else{
            $images.not(".slick-initialized").slick({
              rtl: slide_rtl,
              slidesToShow: 1,
              slidesToScroll: 1,
              infinite: false,
              adaptiveHeight: true,
              prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
              nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>'
            });

          }
        }
      }else{
        if(this.settings.product_design == 'carousel'){
        // Product thumnails and featured image slider
        var center_padding =  $images.width()/ 4;
          $images.not(".slick-initialized").slick({

//          infinite: false,
          rtl: slide_rtl,
          centerMode: true,
          centerPadding: center_padding + 'px',
          slidesToShow: 1,
          slidesToScroll: 1, 
          adaptiveHeight: true,
          prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
          nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>',
          responsive: [
            {
              breakpoint: 1680,
              settings: {
                centerMode: true,
                centerPadding: '400px',
                slidesToShow: 1
              }
            },
            {
              breakpoint: 1440,
              settings: {
                centerMode: true,
                centerPadding: '350px',
                slidesToShow: 1
              }
            },
            {
              breakpoint: 1200,
              settings: {
                centerMode: true,
                centerPadding: '300px',
                slidesToShow: 1
              }
            },
            {
              breakpoint: 1024,
              settings: {
                arrows: false,
                centerMode: true,
                centerPadding: '250px',
                slidesToShow: 1
              }
            },
            {
              breakpoint: 992,
              settings: {
                centerMode: true,
                centerPadding: '200px',
                slidesToShow: 1
              }
            },
            {
              breakpoint: 768,
              settings: {
                arrows: false,
                centerMode: true,
                centerPadding: '125px',
                slidesToShow: 1
              }
            },
            {
              breakpoint: 480,
              settings: {
                arrows: false,
                centerMode: true,
                centerPadding: '50px',
                slidesToShow: 1
              }
            }
          ]
        });
        }else{
          // Product thumnails and featured image slider
          $images.not(".slick-initialized").slick({
            rtl: slide_rtl,
            slidesToShow: 1,
            slidesToScroll: 1,
            infinite: false,
            adaptiveHeight: true,
            asNavFor: $thumbnails,
            prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
            nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>'
          });
        }
      }
      
    },
    _initThumbnailsGallery:function(){
      var slickImages = $(this.selectors.productMainImages);
      this.settings.product_design == "gallery" && $('.thumbnail-gallery-item').on('click', function(){
        var _self = $(this);
        if(!_self.hasClass('active')){ 
          $('.thumbnail-gallery-item').removeClass("active");
          _self.addClass("active");
          $('.thumbnail-gallery-item').each(function(index){
            if($(this).attr('id') == _self.attr('id')){ slickImages.slick("slickGoTo", index, true);return };
          });
        }
      })
    },
    _initQuantity: function() {
      $('.q_up').unbind('click');
      $('.q_up').on( "click", function() {
        var p_id = $(this).data("product_id");
        var q_value =  parseInt($('.quantity-cart-'+p_id).val()) + 1 ;
        $('.quantity-cart-'+p_id).val(q_value);
      });
      $('.q_down').unbind('click');
      $('.q_down').on( "click", function() {
        var p_id = $(this).data("product_id");
        var q_value =  parseInt($('.quantity-cart-'+p_id).val());
        if(q_value > 1) {
          $('.quantity-cart-'+p_id).val(q_value -1);
        }
      });
    },
    _initPopup: function(){
      $('.sizechart-btn').magnificPopup({
        type:'image',
        midClick: true 
      });
      $(".return-btn").on("click", function(e) {
        return $.magnificPopup.open({
          items: { src: "#delivery-return", type: "inline" },
          tLoading: "",
          mainClass: "popup-wrapper mfp-with-zoom",
          removalDelay: 200
        }), !1;
      })
    },
    _initFeature: function(e){
      $(this.selectors.product + ' .product-video-button a').length >0 
      && $(this.selectors.product + ' .product-video-button a').unbind('click') 
      && $(this.selectors.product + ' .product-video-button a').on("click", function(e){
        e.stopPropagation();
        var video = $(this).data("video"),
            _qid = $(this).data("_qid");
        $.magnificPopup.open({
          items: {src: video, type: "iframe" },
          type: "iframe",
          mainClass: 'mfp-fade',
          removalDelay: 160,
          preloader: false,
          disableOn: false,
          fixedContentPos: false,
          callbacks: {
            beforeClose: function() {
              console.log('Popup close has been initiated');
            }
          }
        });
      });
    },
    _initCompact: function(){
      $(".product-accordions").length >0 && $( '.product-accordions .tab-heading' ).unbind("click") && $( '.product-accordions .tab-heading' ).on("click",  function( e ) {
        e.preventDefault();
        var _this = $( this );
        var parent = _this.closest( '.product-accordion' );
        var parent_top = _this.closest( '.product-accordions' );
        if ( parent.hasClass( 'active' ) ) {
          parent.removeClass( 'active' );
          parent.find( '.product-accordion-content' ).stop( true, true ).slideUp();
        } else {
          parent_top.find( '.product-accordion' ).removeClass( 'active' );
          parent.addClass( 'active' );
          parent_top.find( '.product-accordion-content' ).stop( true, true ).slideUp();
          parent.find( '.product-accordion-content' ).stop( true, true ).slideDown();
        }
      });
    },
    _initStickyImages: function() {
      if( ! $('body').hasClass('fastor-product-design-sticky') ) return;
      $(".product-design-sticky .product-summary").stick_in_parent();
    },
    _initGallery: function() {
      var initPhotoSwipeFromDOM = function(gallerySelector) {
        var parseThumbnailElements = function(el) {
          var thumbElements = $(el).find(".photoswipe-item").get(),
            numNodes = thumbElements.length,
            items = [],
            figureEl,
            linkEl,
            size,
            item;

          for (var i = 0; i < numNodes; i++) {
            figureEl = thumbElements[i];

            if (figureEl.nodeType !== 1) {
              continue;
            }

            linkEl = figureEl.children[0];
            size = linkEl.getAttribute("data-size").split("x");

            if ($(linkEl).data("type") == "video") {
              var video_html = $($(linkEl).data("id")).html();
              items.push({
                html: video_html
              });
            } else {
              item = {
                src: linkEl.getAttribute("href"),
                w: parseInt(size[0], 10),
                h: parseInt(size[1], 10)
              };
              if (figureEl.children.length > 1) {
                item.title = $(figureEl).find(".caption").html();
              }

              if (linkEl.children.length > 0) {
                item.msrc = linkEl.children[0].getAttribute("src");
              }

              item.el = figureEl;
              items.push(item);
            }
          }

          return items;
        };

        var closest = function closest(el, fn) {
          return el && (fn(el) ? el : closest(el.parentNode, fn));
        };

        function hasClass(element, cls) {
          return (" " + element.className + " ").indexOf(" " + cls + " ") > -1;
        }

        var onThumbnailsClick = function(e) {
          e = e || window.event;
          e.preventDefault ? e.preventDefault() : (e.returnValue = false);

          var eTarget = e.target || e.srcElement;

          var clickedListItem = closest(eTarget, function(el) {
            return hasClass(el, "photoswipe-item");
          });

          if (!clickedListItem) {
            return;
          }

          var clickedGallery = clickedListItem.closest(".photoswipe-wrapper"),
            childNodes = $(clickedListItem.closest(".photoswipe-wrapper"))
              .find(".photoswipe-item")
              .get(),
            numChildNodes = childNodes.length,
            nodeIndex = 0,
            index;

          for (var i = 0; i < numChildNodes; i++) {
            if (childNodes[i].nodeType !== 1) {
              continue;
            }

            if (childNodes[i] === clickedListItem) {
              index = nodeIndex;
              break;
            }
            nodeIndex++;
          }

          if (index >= 0) {
            openPhotoSwipe(index, clickedGallery);
          }
          return false;
        };

        var photoswipeParseHash = function() {
          var hash = window.location.hash.substring(1), params = {};

          if (hash.length < 5) {
            return params;
          }

          var vars = hash.split("&");
          for (var i = 0; i < vars.length; i++) {
            if (!vars[i]) {
              continue;
            }
            var pair = vars[i].split("=");
            if (pair.length < 2) {
              continue;
            }
            params[pair[0]] = pair[1];
          }

          if (params.gid) {
            params.gid = parseInt(params.gid, 10);
          }

          return params;
        };

        var openPhotoSwipe = function(
          index,
          galleryElement,
          disableAnimation,
          fromURL
        ) {
          var pswpElement = document.querySelectorAll(".pswp")[0],
            gallery,
            options,
            items;

          items = parseThumbnailElements(galleryElement);

          options = {
            closeOnScroll: false,

            galleryUID: galleryElement.getAttribute("data-pswp-uid")
          };

          if (fromURL) {
            if (options.galleryPIDs) {
              for (var j = 0; j < items.length; j++) {
                if (items[j].pid == index) {
                  options.index = j;
                  break;
                }
              }
            } else {
              options.index = parseInt(index, 10) - 1;
            }
          } else {
            options.index = parseInt(index, 10);
          }

          if (isNaN(options.index)) {
            return;
          }

          if (disableAnimation) {
            options.showAnimationDuration = 0;
          }

          let scriptLoaded = loadScriptAsync(theme.libs.photoswipe);
          scriptLoaded.then(function(){
            gallery = new PhotoSwipe(
              pswpElement,
              PhotoSwipeUI_Default,
              items,
              options
            );
            gallery.init();
  
            gallery.listen("beforeChange", function() {
              var currItem = $(gallery.currItem.container);
              $(".pswp__video").removeClass("active");
              var currItemIframe = currItem
                .find(".pswp__video")
                .addClass("active");
              $(".pswp__video").each(function() {
                if (!$(this).hasClass("active")) {
                  $(this).attr("src", $(this).attr("src"));
                }
              });
            });
  
            gallery.listen("close", function() {
              $(".pswp__video").each(function() {
                $(this).attr("src", $(this).attr("src"));
              });
              $('.pswp__container .video-wrapper').empty();
            });
          });
          
        };

        var galleryElements = document.querySelectorAll(gallerySelector);

        for (var i = 0, l = galleryElements.length; i < l; i++) {
          galleryElements[i].setAttribute("data-pswp-uid", i + 1);
          galleryElements[i].onclick = onThumbnailsClick;
        }

        var hashData = photoswipeParseHash();
        if (hashData.pid && hashData.gid) {
          openPhotoSwipe(
            hashData.pid,
            galleryElements[hashData.gid - 1],
            true,
            true
          );
        }
      };

      initPhotoSwipeFromDOM(this.selectors.product + " .photoswipe-wrapper");
    },
    _initZoom: function() {
      if ($(".easyzoom").length) {
        if ($(window).width() > 1024) {
          var $easyzoom = $(".easyzoom:not(.feature-video)").easyZoom({
            loadingNotice: "",
            errorNotice: "",
            preventClicks: false
          });
          var easyzoom_api = $easyzoom.data("easyZoom");
        } else {
          $(".easyzoom a").on("click", function(event) {
            event.preventDefault();
          });
        }
      }
    },
    _initSidebar: function() {
      var self = this; $sidebarSlide = $(self.selectors.sidebarSlide);
      $sidebarSlide.length > 0 && $sidebarSlide.each(function() {
        var _self = $(this);
           var per_view = $(this).data('per_view');
        $(this).not(".slick-initialized").slick({
          slidesToShow: per_view,
          slidesToScroll: 1,
          vertical: true,
          focusOnSelect: true,
          infinite: false,
          prevArrow: '<span class="fa fa-angle-up slick-prev-arrow"></span>',
          nextArrow: '<span class="fa fa-angle-down slick-next-arrow"></span>'
        });
        _self.imagesLoaded(function() {
          _self.addClass("loaded");
        });
      });
    },
    _initForceHeight: function() {
      //Force height for images
      $(this.selectors.productPreviewMainImages).length > 0 &&
        $(this.selectors.productPreviewMainImages)
          .not(".slick-initialized")
          .slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            infinite: false,
            prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
            nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>'
          });
    },
    _initSwatches: function() {
      var _z = this.selectors.optionsSelect;
      function swatchCallBack(e, op, ov, dataSwatch, thisProdObject) {
        if(e.options.length > 1){
          for (var i = 0; i < e.options.length; i++) {
            if(i != op) {
              $(_z+"-"+i+" option").each(function(){
                var _flag =  "unavailable";
                var _value = $(this).attr("value");

                for (j = 0; j < e.variants.length; j++) {
                  var _variant = e.variants[j];
                  if(_variant.options[op] == ov) {
                    // add out of stock or unavailable
                    if(_variant.options[i] == _value) {
                      if(_variant.available  == true) {
                        _flag =  "available";
                      }else{
                        _flag =  "sold_out";
                      }
                      break;
                    }
                  }else{
                    continue;
                  }
                }
                
                $(this).closest(".selector-wrapper").find(".swatch-element."+$(this).data("swatch")).removeClass("available").removeClass("sold_out").removeClass("unavailable").addClass(_flag);
              });
            }
          }
        }else{
          for (var i = 0; i < e.options.length; i++){
            $(_z+"-"+i+" option").each(function() {
              var _flag =  "unavailable";
              var _value = $(this).attr("value");
              for (j = 0; j < e.variants.length; j++) {
                if(e.variants[j].options[i] == _value) {
                  if(e.variants[j].available){
                    _flag =  "available" ;
                  }else{
                    _flag =  "sold_out";
                  }
                  break;
                }
              }
               $(this).closest(".selector-wrapper").find(".swatch-element."+$(this).data("swatch")).removeClass("available").removeClass("sold_out").removeClass("unavailable").addClass(_flag);
            });
          }
        }
        //------ Start - Images Filtering ------
        var _variant_image_grouped = thisProdObject.settings.variant_image_grouped;
        var _thisMainImage = thisProdObject.selectors.productMainImages + ".slick-slider";
        var _thisThumbImage = thisProdObject.selectors.productThumbImages + " .slick-slider";
        var _val = ov;
        var _prodSingleObject = thisProdObject.productSingleObject;
        var _oriSelectorId = thisProdObject.selectors.originalSelectorId;
        if ( _variant_image_grouped == "1" && (dataSwatch == "color"  || dataSwatch == "colour")) {
          // thumbnail
          $(_thisThumbImage).slick('slickUnfilter').slick('slickFilter',"[data-color='"+ _val +"']");
          //  $(_thisThumbImage).slick("asNavFor", $(_thisMainImage));
          var $_slides = $(_thisThumbImage).find('.slick-slide'), _new_index = 0, _new_found = false;
          $_slides.each(function(index, _sl) {
            $(_sl).attr('data-slick-index', index);
            $.each(_prodSingleObject.variants, function(_idx, _el){
              if(_el.id == $(_oriSelectorId).val() && _new_found == false) {
                var _t = _el.featured_image.src.replace(/^https?\:/i, "").split('?')[0].replace(".png","").replace(".jpg","");
                var _j = $(_sl).find('img').first().attr('src');
                if(_j.indexOf(_t) >= 0) {
                  _new_index = index;
                  _new_found = true;
                }
              }
            });
          });
          $(_thisThumbImage).slick('slickGoTo',_new_index,true);
          // main image
          $(_thisMainImage).slick('slickUnfilter').slick('slickFilter',"[data-color='"+ _val +"']");
          //    $(_thisMainImage).slick("asNavFor", $(_thisThumbImage));
          var $_slides = $(_thisMainImage).find('.slick-slide'), _new_index = 0, _new_found = false;
          $_slides.each(function(index, _sl) {
            $(_sl).attr('data-slick-index', index);
            $.each(_prodSingleObject.variants, function(_idx, _el){
              if(_el.id == $(_oriSelectorId).val() && _new_found == false) {
                var _t = _el.featured_image.src.replace(/^https?\:/i, "").split('?')[0].replace(".png","").replace(".jpg","");
                var _j = $(_sl).find('img').first().attr('src');
                if(_j.indexOf(_t) >= 0) {
                  _new_index = index;
                  _new_found = true;
                }
              }
            });
          });
          $(_thisMainImage).slick('slickGoTo',_new_index,true);
          
          if($('.templateProduct .thumbnails .slick-list').width() >= $('.templateProduct .thumbnails .slick-track').width()) {
            $('body').append('<style id="product-images-filtering-style" type="text/css">.templateProduct .thumbnails .slick-track{transform:none!important;}</style>');
          } else {
            if($('style#product-images-filtering-style').length > 0) $('style#product-images-filtering-style').remove();
          }
        }
        //------ End - Images Filtering ------
      };
      var e = this.productSingleObject;
      var thisSelector = "";
      var _thisSelector= "." + this.selectors.singleOptionSwatches + " .swatch-radio";
      var _self = this;
      $("." + this.selectors.singleOptionSwatches).length > 0 &&
        ((thisSelector = $(_thisSelector)),
         thisSelector.unbind("click"), 
         thisSelector.on("click", function() {
        var sId = $(this).data("id");
        var _poption = $(this).data("poption");
        var _val = $(this).data("value");
        var _data_swatch = $(this).data("swatch");

        $(this).data("value") != $(sId).val() &&
          ($(sId).val($(this).data("value")).trigger("change"),
           
           $(sId)
           .closest(".selector-wrapper")
           .find(".swatch-radio")
           .removeClass("selected"),
           $(this).addClass("selected"),
           
            $(sId)
           .closest(".selector-wrapper")
           .find("label")
           .removeClass("label-selected"),
           
            $(this).parent("label").addClass("label-selected"),
           
           $(sId)
           .closest(".selector-wrapper"),
           $(sId)
           .closest(".selector-wrapper")
           .find('.option-select-value')
           .html($(this).data("value")));
        
        swatchCallBack(e, _poption, _val, _data_swatch, _self);

      }));
      $(".swatch-radio.selected").trigger("click")
    },
    _initVariants: function() {
      var options = {
        $container: this.$container,
        enableHistoryState: this.$container.data("enable-history-state") ||
        false,
        singleOptionSelector: this.selectors.singleOptionSelector,
        originalSelectorId: this.selectors.originalSelectorId,
        product: this.productSingleObject
      };

      this.variants = new slate.Variants(options);

      this.$container.on(
        "variantChange" + this.settings.namespace,
        this._updateAddToCart.bind(this)
      );
      this.$container.on(
        "variantImageChange" + this.settings.namespace,
        this._updateMedia.bind(this)
        
        /* this._updateImages.bind(this) */
        
      );
      this.$container.on(
        "variantPriceChange" + this.settings.namespace,
        this._updatePrice.bind(this)
      );
      this.$container.on(
        "variantSKUChange" + this.settings.namespace,
        this._updateSKU.bind(this)
      );
    },
    _updateAddToCart: function(evt) {
      var variant = evt.variant;
      if (variant) {
        $(this.selectors.productPrices)
        .removeClass("invisible")
        .attr("aria-hidden", "true");
        if (variant.available) { 
          $(".variations_button .product-cart__condition").removeClass("hide");
          $(".variations_button .dynamic-payment-button").removeClass("hide");
          $(this.selectors.addToCart)
          .prop("disabled", false)
          .toggleClass("hide", false);
          $(this.selectors.addToCart).val(theme.strings.addToCart);
          $(this.selectors.stockText)
          .html(theme.strings.inStock)
          .removeClass("out-of-stock unavailable")
          .addClass("in-stock");
          if (
            variant.inventory_management == "shopify" &&
            variant.inventory_policy != "continue"
          ) {
            if (variant.inventory_quantity > 0 && (parseInt(theme.inventory) == 1)) {
              $(this.selectors.stockText).html(variant.inventory_quantity+" "+theme.strings.inStock);
            }else{
              $(this.selectors.stockText).html(theme.strings.inStock);
            }
          }
        } else {
          // The variant doesn't exist, disable submit button and change the text.
          // This may be an error or notice that a specific variant is not available.
          $(this.selectors.addToCart)
          .prop("disabled", true)
          .toggleClass("hide", false);
          $(this.selectors.addToCart).val(theme.strings.soldOut);
          $(this.selectors.stockText)
          .html(theme.strings.outStock)
          .removeClass("in-stock unavailable")
          .addClass("out-of-stock");
        }
      } else {
        $(".variations_button .product-cart__condition").addClass("hide");
        $(".variations_button .dynamic-payment-button").addClass("hide");
        $(this.selectors.addToCart).prop("disabled", true);
        $(this.selectors.addToCart).val(theme.strings.unavailable);
        
        $(this.selectors.stockText).html(theme.strings.unavailable).removeClass("in-stock").addClass("out-of-stock unavailable");
        $(this.selectors.productPrices).addClass("invisible").attr("aria-hidden", "false");
      }
    },
    _updateImages: function(evt) {
      var variant = evt.variant,
          self = this,
          product_design = this.settings.product_design,
          variant_image = variant.featured_image.src
      .replace("https:", "")
      .replace("http:", "")
      .split("?v=")[0];

      $(this.selectors.productFeaturedImage).each(function(index) {
        var _self = $(this),
            s_href = _self.attr("href");
        if (s_href.indexOf(variant_image) >= 0 && !_self.closest('.slick-slide').hasClass('slick-cloned')) {
        
          var slickImages = $(self.selectors.productMainImages);
          var pos =  _self.closest('.slick-slide').attr("data-slick-index");
          if(product_design == 'carousel') {
            slickImages.slick("slickGoTo", pos);
          }else{
            slickImages.slick("slickGoTo", pos, true);
          }
          if(product_design == 'scroll') {
            var s_top = parseInt(_self.closest(".shopify-product-gallery__image").offset().top) - 50;
            $("html,body").animate({ scrollTop: s_top}, "slow");
          }
          if(product_design == 'gallery') {
            $(".thumbnails .thumbnail-gallery-item").length > 0 && $(".thumbnails .thumbnail-gallery-item").each(function(){
              var img_src = $(this).data('href');
              if (img_src.indexOf(variant_image) >= 0) {
                $(this).trigger('click');
              }
            });
          }
          return;
        }
      });
    },
    
    _updatePrice: function(evt) {
      var variant = evt.variant;
      var $priceContainer = $(this.selectors.priceContainer, this.$container);
      var $regularPrice = $(this.selectors.regularPrice, $priceContainer);
      var $salePrice = $(this.selectors.salePrice, $priceContainer);
      var $saleLabel = $(this.selectors.saleLabel, this.$container);
      var $unitPrice = $(this.selectors.unitPrice, $priceContainer);
      var $unitPriceBaseUnit = $(
        this.selectors.unitPriceBaseUnit,
        $priceContainer
      );

      // Reset product price state
      $priceContainer
      .removeClass(this.classes.productUnavailable)
      .removeClass(this.classes.productOnSale)
      .removeClass(this.classes.productUnitAvailable)
      .removeClass(this.classes.productSoldOut)
      .removeAttr('aria-hidden');

      this.$productPolicies.removeClass(this.classes.visibilityHidden);

      // Unavailable
      if (!variant) {
        $priceContainer
        .addClass(this.classes.productUnavailable)
        .attr('aria-hidden', true);

        this.$productPolicies.addClass(this.classes.visibilityHidden);
        return;
      }

      // Sold out
      if (!variant.available) {
        $priceContainer.addClass(this.classes.productSoldOut);
      }

      // On sale
      if (variant.compare_at_price > variant.price) {
        $regularPrice.removeClass("hide");
        $regularPrice.html(
          '<span class="money">' + theme.Currency.formatMoney(variant.compare_at_price, theme.settings.moneyFormat) + '</span>'
        );
        $salePrice.html(
          '<span class="money">' + theme.Currency.formatMoney(variant.price, theme.settings.moneyFormat) + '</span>'
        );
        $priceContainer.addClass(this.classes.productOnSale);

        $saleLabel.text(theme.strings.sale);
        if (theme.sale_percentages != "") {
          var sale_percentages = Math.round(
            (variant.compare_at_price - variant.price) *
            100 /
            variant.compare_at_price
          );
          $saleLabel.text("-" + sale_percentages + "%");
        }
        $saleLabel.removeClass("hide");

      } else {

        $saleLabel.addClass("hide");
        $regularPrice.addClass("hide");
        // Regular price
        $salePrice.html(
          '<span class="money">' + theme.Currency.formatMoney(variant.price, theme.settings.moneyFormat) + '</span>'
        );
      }

      // Unit price
      if (variant.unit_price) {
        $unitPrice.html(
          '<span class="money">' + theme.Currency.formatMoney(variant.unit_price, theme.settings.moneyFormat) + '</span>'
        );
        $unitPriceBaseUnit.html(this._getBaseUnit(variant));
        $priceContainer.addClass(this.classes.productUnitAvailable);
      }
      window.builtin_currencies_used && theme.CurrencyPicker.convert(this.selectors.product + " .money");
    },

    _getBaseUnit: function(variant) {
      return variant.unit_price_measurement.reference_value === 1
      ? variant.unit_price_measurement.reference_unit
      : variant.unit_price_measurement.reference_value +
        variant.unit_price_measurement.reference_unit;
    },
    _updateSKU: function(evt) {
      var variant = evt.variant;
      // Update the sku
      if (variant.sku != "") {
        $(this.selectors.SKU)
        .removeClass("hide")
        .find(".sku")
        .text(variant.sku);
      } else {
        $(this.selectors.SKU).addClass("hide");
      }
    },
    onUnload: function() {
      this.$container.off(this.settings.namespace);
      theme.ProductVideo.removeSectionVideos(this.settings.sectionId);
      theme.ProductModel.removeSectionModels(this.settings.sectionId);
    }
  });
    
  return Product;
  
})();
theme.ProductModel = (function() {
  var modelJsonSections = {};
  var models = {};
  var xrButtons = {};

  var selectors = {
    mediaGroup: '[data-product-single-media-group]',
    xrButton: '[data-shopify-xr]'
  };

  function init(modelViewerContainers, sectionId) {
    modelJsonSections[sectionId] = {
      loaded: false
    };

    modelViewerContainers.each(function(index) {
      var $modelViewerContainer = $(this);
      var mediaId = $modelViewerContainer.data('media-id');
      var $modelViewerElement = $(
        $modelViewerContainer.find('model-viewer')[0]
      );
      var modelId = $modelViewerElement.data('model-id');

      if (index === 0) {
        var $xrButton = $modelViewerContainer
          .closest(selectors.mediaGroup)
          .find(selectors.xrButton);
        xrButtons[sectionId] = {
          $element: $xrButton,
          defaultId: modelId
        };
      }

      models[mediaId] = {
        modelId: modelId,
        sectionId: sectionId,
        $container: $modelViewerContainer,
        $element: $modelViewerElement
      };
    });

    window.Shopify.loadFeatures([
      {
        name: 'shopify-xr',
        version: '1.0',
        onLoad: setupShopifyXr
      },
      {
        name: 'model-viewer-ui',
        version: '1.0',
        onLoad: setupModelViewerUi
      }
    ]);
    theme.LibraryLoader.load('modelViewerUiStyles');
  }

  function setupShopifyXr(errors) {
    if (errors) return;

    if (!window.ShopifyXR) {
      document.addEventListener('shopify_xr_initialized', function() {
        setupShopifyXr();
      });
      return;
    }

    for (var sectionId in modelJsonSections) {
      if (modelJsonSections.hasOwnProperty(sectionId)) {
        var modelSection = modelJsonSections[sectionId];

        if (modelSection.loaded) continue;
        var $modelJson = $('#ModelJson-' + sectionId);

        window.ShopifyXR.addModels(JSON.parse($modelJson.html()));
        modelSection.loaded = true;
      }
    }
    window.ShopifyXR.setupXRElements();
  }

  function setupModelViewerUi(errors) {
    if (errors) return;

    for (var key in models) {
      if (models.hasOwnProperty(key)) {
        var model = models[key];
        if (!model.modelViewerUi) {
          model.modelViewerUi = new Shopify.ModelViewerUI(model.$element);
        }
        setupModelViewerListeners(model);
      }
    }
  }

  function setupModelViewerListeners(model) {
    var xrButton = xrButtons[model.sectionId];

    model.$container.on('mediaVisible', function() {
      xrButton.$element.attr('data-shopify-model3d-id', model.modelId);
      if (theme.Helpers.isTouch()) return;
      model.modelViewerUi.play();
    });

    model.$container
      .on('mediaHidden', function() {
        xrButton.$element.attr('data-shopify-model3d-id', xrButton.defaultId);
        model.modelViewerUi.pause();
      })
      .on('xrLaunch', function() {
        model.modelViewerUi.pause();
      });
  }

  function removeSectionModels(sectionId) {
    for (var key in models) {
      if (models.hasOwnProperty(key)) {
        var model = models[key];
        if (model.sectionId === sectionId) {
          models[key].modelViewerUi.destroy();
          delete models[key];
        }
      }
    }
    delete modelJsonSections[sectionId];
  }

  return {
    init: init,
    removeSectionModels: removeSectionModels
  };
})();
theme.ProductVideo = (function() {
  var videos = {};

  var hosts = {
    html5: 'html5',
    youtube: 'youtube'
  };

  var selectors = {
    productMediaWrapper: '[data-product-single-media-wrapper]'
  };

  var attributes = {
    enableVideoLooping: 'enable-video-looping',
    videoId: 'video-id'
  };

  function init(videoContainer, sectionId) {
    if (!videoContainer.length) {
      return;
    }

    var videoElement = videoContainer.find('iframe, video')[0];
    var mediaId = videoContainer.data('mediaId');

    if (!videoElement) {
      return;
    }

    videos[mediaId] = {
      mediaId: mediaId,
      sectionId: sectionId,
      host: hostFromVideoElement(videoElement),
      container: videoContainer,
      element: videoElement,
      ready: function() {
        createPlayer(this);
      }
    };

    var video = videos[mediaId];

    switch (video.host) {
      case hosts.html5:
        window.Shopify.loadFeatures([
          {
            name: 'video-ui',
            version: '1.0',
            onLoad: setupPlyrVideos
          }
        ]);
        theme.LibraryLoader.load('plyrShopifyStyles');
        break;
      case hosts.youtube:
        theme.LibraryLoader.load('youtubeSdk', setupYouTubeVideos);
        break;
    }
  }

  function setupPlyrVideos(errors) {
    if (errors) {
      fallbackToNativeVideo();
      return;
    }

    loadVideos(hosts.html5);
  }

  function setupYouTubeVideos() {
    if (!window.YT.Player) return;

    loadVideos(hosts.youtube);
  }

  function createPlayer(video) {
    if (video.player) {
      return;
    }

    var productMediaWrapper = video.container.closest(
      selectors.productMediaWrapper
    );
    var enableLooping = productMediaWrapper.data(attributes.enableVideoLooping);

    switch (video.host) {
      case hosts.html5:
        // eslint-disable-next-line no-undef
        video.player = new Shopify.Plyr(video.element, {
          loop: { active: enableLooping }
        });
        break;
      case hosts.youtube:
        var videoId = productMediaWrapper.data(attributes.videoId);

        video.player = new YT.Player(video.element, {
          videoId: videoId,
          events: {
            onStateChange: function(event) {
              if (event.data === 0 && enableLooping) event.target.seekTo(0);
            }
          }
        });

        
        video.container.on('click', '.yt-video--cover', function() {
          video.player.playVideo();
          $(this).css('z-index', '-1');
        });
        
        break;
    }

    productMediaWrapper.on('mediaHidden xrLaunch', function() {
      if (!video.player) return;

      if (video.host === hosts.html5) {
        video.player.pause();
      }

      if (video.host === hosts.youtube && video.player.pauseVideo) {
        video.player.pauseVideo();
      }
    });

    productMediaWrapper.on('mediaVisible', function() {
      if (theme.Helpers.isTouch()) return;
      if (!video.player) return;

      if (video.host === hosts.html5) {
        video.player.play();
      }

      if (video.host === hosts.youtube && video.player.playVideo) {
        video.player.playVideo();
      }
    });
  }

  function hostFromVideoElement(video) {
    if (video.tagName === 'VIDEO') {
      return hosts.html5;
    }

    if (video.tagName === 'IFRAME') {
      if (
        /^(https?:\/\/)?(www\.)?(youtube\.com|youtube-nocookie\.com|youtu\.?be)\/.+$/.test(
          video.src
        )
      ) {
        return hosts.youtube;
      }
    }
    return null;
  }

  function loadVideos(host) {
    for (var key in videos) {
      if (videos.hasOwnProperty(key)) {
        var video = videos[key];
        if (video.host === host) {
          video.ready();
        }
      }
    }
  }

  function fallbackToNativeVideo() {
    for (var key in videos) {
      if (videos.hasOwnProperty(key)) {
        var video = videos[key];

        if (video.nativeVideo) continue;

        if (video.host === hosts.html5) {
          video.element.setAttribute('controls', 'controls');
          video.nativeVideo = true;
        }
      }
    }
  }

  function removeSectionVideos(sectionId) {
    for (var key in videos) {
      if (videos.hasOwnProperty(key)) {
        var video = videos[key];

        if (video.sectionId === sectionId) {
          if (video.player) video.player.destroy();
          delete videos[key];
        }
      }
    }
  }

  return {
    init: init,
    hosts: hosts,
    loadVideos: loadVideos,
    removeSectionVideos: removeSectionVideos
  };
})();
theme.productRecommendationsSection = (function() {
  function productRecommendationsSection(container) {
    var $container = (this.$container = $(container));
    var sectionId = this.sectionId = $container.attr("data-section-id");
    var sectionType = $container.attr("data-section-type");
    this.settings = {
      namespace: ".product-recommendations",
      sectionId: sectionId
    };

	this.init();
    
  }

  productRecommendationsSection.prototype = _.assignIn({}, productRecommendationsSection.prototype, {
    init: function() {
      var loadProductRecommendationsIntoSection = function() {
        // Look for an element with class 'product-recommendations'
        var productRecommendationsSection = document.querySelector(".product-recommendations");
        if (productRecommendationsSection === null) { return; }
        // Read product id from data attribute
        var productId = productRecommendationsSection.dataset.productId;
        // Read limit from data attribute
        var limit = productRecommendationsSection.dataset.limit;
        // Build request URL
        var requestUrl = "/recommendations/products?section_id=product-recommendations&limit="+limit+"&product_id="+productId;
        // Create request and submit it using Ajax
        var request = new XMLHttpRequest();
        request.open("GET", requestUrl);
        request.onload = function() {
          if (request.status >= 200 && request.status < 300) {
            var container = document.createElement("div");
            container.innerHTML = request.response;
            productRecommendationsSection.parentElement.innerHTML = container.querySelector(".product-recommendations").innerHTML;
            
            // callback recommendations
            
            let _selector = '#productRecommendations .splide';
            if($(_selector).length) {
              let _slider = new Splide( _selector, { updateOnMove: true });
              _slider.on('mounted moved', debounce(function() {
                $(_slider.root).find('.splide__slide').removeClass('is-last-visible');
                $(_slider.root).find('.splide__slide[tabindex=0]').last().addClass('is-last-visible');
              }, 2000));
              _slider.mount();
            } 
            roar.handleQuickshop(_selector);
            
          }
        };
        request.send();
      };
      // If your section has theme settings, the theme editor
      // reloads the section as you edit those settings. When that happens, the
      // recommendations need to be fetched again.
      // See https://help.shopify.com/en/themes/development/sections/integration-with-theme-editor
      document.addEventListener("shopify:section:load", function(event) {
        if (event.detail.sectionId === "product-recommendations") {
          loadProductRecommendationsIntoSection();
        }
      });
      // Fetching the recommendations on page load
      loadProductRecommendationsIntoSection();
    },
    
    onUnload: function() {
      this.$container.off(this.settings.namespace);
    }
  });

  return productRecommendationsSection;
})(); 
//#endregion
window.theme = window.theme || {};

theme.Filters = (function() {
  var selectors = {
    filterForm: '#CollectionFiltersForm',
    filterChoice: '[data-filter-choice]',
    tagChoice: '[data-tag-choice]',
    tagClear: '[data-filter-clear]',

    sortSelection: '#SortBy',

    limitSelection: '#limit',

    layoutChoice: '[data-layout]'
  }, 
  attributes = {
      filterChoices: 'data-filter-choice',
      tagChoices: 'data-tag-choice'
  };
  
  function beforeInit() {
    if (!$(selectors.filter).length) {
      return;
    }
  }

  function Filters(container) {

    console.log('filter is here');
    
   // var $container = this.$container = $(container);

    this.$container = container;
    
    this._refresh();
  
    beforeInit();

    $(document).on('change', selectors.sortSelection, this._onSortChangeAjax.bind(this));
    $(document).on('change', selectors.limitSelection, this._onLimitChangeAjax.bind(this));
    $(document).on('input', selectors.filterForm , this._onFilterFormChangeAjax.bind(this));
    $(document).on('click', selectors.tagChoice , this._onTagChoiceChangeAjax.bind(this));
    $(document).on('click', selectors.layoutChoice , this._onLayoutChangeAjax.bind(this));
    $(document).on('click', selectors.tagClear , this._onTagClearChangeAjax.bind(this));
    
    
    this._initParams();
  }

  Filters.prototype = _.assignIn({}, Filters.prototype, {
    _initParams: function() {
      console.log('init-param');
      this.queryParams = new FormData();
      if (location.search.length) {
          var aKeyValue;
          var aCouples = location.search.substr(1).split('&');
          for (var i = 0; i < aCouples.length; i++) {
              aKeyValue = aCouples[i].split('=');
              if (aKeyValue.length > 1) {
                  this.queryParams.append(decodeURIComponent(aKeyValue[0]), decodeURIComponent(aKeyValue[1]));
              }
          }
      }
    },
    _refresh: function() {

        this.collectionHandle = this.$container.dataset.collectionHandle;
        this.currentTags = this.$container.dataset.currentTags;
        
        this.containerSelect = '#' + this.$container.id;
        this.filterChoices = this.$container.querySelectorAll(selectors.filterChoice);
        this.tagChoices = this.$container.querySelectorAll(selectors.tagChoice);
        this.sortSelect = this.$container.querySelector(selectors.sortSelection);
        this.sortClick = this.$container.querySelector(selectors.sortClick);
        this.limitSelect = this.$container.querySelector(selectors.limitSelection);

        this.filterChoicesAttr = attributes.filterChoices;
        this.tagChoicesAttr = attributes.tagChoices;

        if (this.sortSelect) {
            this.defaultSort = this._getDefaultSortValue();
        }

        if (this.limitSelect) {
            this.defaultLimit = this._getDefaultLimitValue();
        }
       
        this._priceSlider('.filter-price-slider');
    },
    _getSortValue: function() {
      return this.sortSelect.value || this.defaultSort;
    },
    _getDefaultSortValue: function() {
      return this.sortSelect.dataset.defaultSortby;
    },
    _getLimitValue: function() {
        return this.limitSelect.value || this.defaultLimit;
    },
    _getDefaultLimitValue: function() {
        return this.limitSelect.dataset.defaultLimit;
    },

    _priceSlider: function ( selector, option ) {
      if(document.querySelector('.filter-price-slider') == undefined ) return;
      var _rmin = parseInt(document.querySelector(selector).dataset.rangemin, 10);
      var _rmax = parseInt(document.querySelector(selector).dataset.rangemax, 10);
      var _cmin = parseInt(document.querySelector(selector).dataset.currmin, 10);
      var _cmax = parseInt(document.querySelector(selector).dataset.currmax, 10);
      if ( typeof noUiSlider === 'object' ) {
          $( selector ).each( function () {
              var self = this;

              noUiSlider.create( self, $.extend( true, {
                  start: [ _cmin, _cmax ],
                  connect: true,
                  step: 1,
                  range: {
                      min: _rmin,
                      max: _rmax
                  }
              }, option ) );

              self.noUiSlider.on( 'update', function ( values, handle ) {
                  var values = values.map( function ( value ) {
                      return '$' + parseInt( value );
                  } )
                  $( self ).parent().find( '.filter-price-range' ).text( values.join( ' - ' ) );
              } );
              self.noUiSlider.on( 'end', function ( values, handle ) {
                  var _min = parseInt( values[0] );
                  var _max = parseInt( values[1] );
                  $( self ).parent().find( '.filter-price--min' ).val(_min);
                  $( self ).parent().find( '.filter-price--max' ).val(_max);
              } );
              $( self ).parent().find( '.price-filter-action' ).on( 'click', function(){
                  var _event = new Event('input', {
                      bubbles: true,
                      cancelable: true,
                  });
                  document.querySelector(selector).closest( 'form' ).dispatchEvent(_event);
              });
          } );
      }
    },
    
    _onSortChangeAjax: function() {
      this.queryParams.set('sort_by', this._getSortValue());
      this.queryParams.delete('page');

      var new_url = window.location.origin + window.location.pathname + '?' + decodeURIComponent(
          new URLSearchParams(this.queryParams).toString()
      );
      this._ajaxCall(new_url);
    },
    _onLimitChangeAjax: function() {
        this.queryParams.set('limit', this._getLimitValue());
        this.queryParams.delete('page');

        var new_url = window.location.origin + window.location.pathname + '?' + decodeURIComponent(
            new URLSearchParams(this.queryParams).toString()
        );
        this._ajaxCall(new_url);
    },
    _onTagClearChangeAjax: function(evt){

      var currentTags = this.$container.dataset.currentTags;
      var currentTagsArray = currentTags.split(',');

      var otherTags = $(evt.target).closest('.column').find("input:checked");
      if(otherTags.length > 0) {
        otherTags.each(function() {
          var tagName = $(this).val();
          if(tagName) {
            var tagPos = currentTagsArray.indexOf(tagName);
            if(tagPos >= 0) {
              //remove tag
              currentTagsArray.splice(tagPos, 1);
            }
          }
        });
      }
      var filter_tags = "";
      var newTagsArray =  currentTagsArray.filter((v) => v != '');
      var newCurrentsTags = "";
      if (newTagsArray.length > 0){
        filter_tags = newTagsArray.join('+');
        var newCurrentsTags = ',' + newTagsArray.join(',') + ',';
      }

      // return current new tags
      this.$container.dataset.currentTags = newCurrentsTags;

      var defaultHref = '/collections/' + this.collectionHandle;

      if(filter_tags != "") {
        defaultHref = defaultHref + '/' + filter_tags;
      }
      this.queryParams.delete('page');

      var valid_params = [ "view", "limit", "sort_by", "lo", "token"];
      var toberemoved_params = [];
      for(var pair of this.queryParams.entries()) {
          if(valid_params.indexOf(pair[0]) <= 0) {
              toberemoved_params.push(pair[0]);
          }
      }
      toberemoved_params.forEach(el => this.queryParams.delete(el));
      var queryString = decodeURIComponent(
          new URLSearchParams(this.queryParams).toString()
      );
      var new_url = defaultHref + '?' + queryString;
      this._ajaxCall(new_url);

    },
    _onTagChoiceChangeAjax: function(evt){

    var currentTags = this.$container.dataset.currentTags;
    var tag_element = evt.target.closest(selectors.tagChoice);
    var data_tag = ','+tag_element.value+',';
    var currentTagsArray = currentTags.split(',');

    if(currentTags.indexOf(data_tag) !== -1) {
      
      tag_element.classList.remove('selected');
      var postion_element = currentTagsArray.indexOf(tag_element.value);
      if(postion_element >= 0) {
        currentTagsArray.splice(postion_element, 1);
      }
     
    }else{
      tag_element.classList.add('selected');
      currentTagsArray.push(tag_element.value);
    }
    var filter_tags = "";
    var newTagsArray =  currentTagsArray.filter((v) => v != '');
    var newCurrentsTags = "";
    if (newTagsArray.length > 0){
      filter_tags = newTagsArray.join('+');
      var newCurrentsTags = ',' + newTagsArray.join(',') + ',';
    }
    // return current new tags
    this.$container.dataset.currentTags = newCurrentsTags;

    var defaultHref = '/collections/' + this.collectionHandle;

    if(filter_tags != "") {
      defaultHref = defaultHref + '/' + filter_tags;
    }

    this.queryParams.delete('page');

    var valid_params = [ "view", "limit", "sort_by", "lo", "token"];
    var toberemoved_params = [];
    for(var pair of this.queryParams.entries()) {
        if(valid_params.indexOf(pair[0]) <= 0) {
            toberemoved_params.push(pair[0]);
        }
    }
    toberemoved_params.forEach(el => this.queryParams.delete(el));
     var queryString = decodeURIComponent(
        new URLSearchParams(this.queryParams).toString()
    );
    var new_url = defaultHref + '?' + queryString;
    this._ajaxCall(new_url);
    
    },
    _onFilterFormChangeAjax: function(evt) {

      var currentTags = this.$container.dataset.currentTags;
      var currentTagsArray = currentTags.split(',');
      var newTagsArray =  currentTagsArray.filter((v) => v != '');

      var filter_tags = "";
      if (newTagsArray.length > 0){
        filter_tags = newTagsArray.join('+');
      }

      var defaultHref = '/collections/' + this.collectionHandle;

      if(filter_tags != "") {
        defaultHref = defaultHref + '/' + filter_tags;
      }
    
      var choice_ui = evt.target.closest(selectors.filterChoice);

      this.queryParams.delete('page');

      var valid_params = [ "view", "limit", "sort_by", "lo", "token"];
        var toberemoved_params = [];
        for(var pair of this.queryParams.entries()) {
            if(valid_params.indexOf(pair[0]) <= 0) {
                toberemoved_params.push(pair[0]);
            }
        }
        toberemoved_params.forEach(el => this.queryParams.delete(el));

        var filterFormData = new FormData(evt.target.closest('form'));
        for(var pair of filterFormData.entries()) {
            this.queryParams.append(pair[0], pair[1]);
        }
        var queryString = decodeURIComponent(
            new URLSearchParams(this.queryParams).toString()
        );
        
        if(choice_ui?.parentNode.tagName == 'LI') {
            choice_ui?.parentNode.classList.toggle('active');
        }

        var new_url = defaultHref + '?' + queryString;
        this._ajaxCall(new_url);
    },
    _onLayoutChangeAjax: function(evt) {
      
      var choice = evt.target.closest(selectors.layoutChoice);
      console.log(choice);
      console.log(choice.dataset.value);
      if(choice.classList.contains('active')) return false;

      this.queryParams.set('lo', choice.dataset.value);
      this.queryParams.set('token', Math.floor(Math.random() * Math.floor(1000)));

      var new_url = window.location.origin + window.location.pathname + '?' + decodeURIComponent(
          new URLSearchParams(this.queryParams).toString()
      );
      this._ajaxCall(new_url);
      var _nc = 'flex-view-'+ choice.dataset.value;
      $(document.body).removeClass('flex-view-1 flex-view-2 flex-view-3 flex-view-4 flex-view-6').addClass(_nc);
      $('#mfilter-content-container').removeClass('list grid').addClass(choice.dataset.layout);

      
    },
    _ajaxCall: function(newurl) {	
      var _content = "#mfilter-content-container";
      var _sidebar = ".collection-filter-wrap";
      var _filter_actions = ".filter-actions-result";
      
      var _this = this;
      $.ajax({
        type: "get",
        url: newurl,
        beforeSend: function() {
          roar.destroyCountdown(), $("body")
          .addClass("is_loading")
          .removeClass("open_filter");
        },
        success: function(data) {
          var _title = $(data).filter('title').text();
          $(_content).empty().html($(data).find(_content).html());
          $(_sidebar).empty().html($(data).find(_sidebar).html());
          $(_filter_actions).empty().html($(data).find(_filter_actions).html());
          _this._refresh();
          History.pushState({
            param: Shopify.queryParams
          }, _title, newurl), setTimeout(function() {
            $("html,body").animate({
              scrollTop: $("body #sandbox").offset().top
            }, 500, "swing")
          }, 100);
          $("body").removeClass("is_loading");
          roar.mapPaginationCallback();
          
        },
        error: function() {
          $("body").removeClass("is_loading")
        }
      })
    },


    onUnload: function() {

      if (this.sortSelect) {
        this.$sortSelect.off('change', this._onSortChangeAjax);
      }
      if (this.limitSelect) {
        this.$limitSelect.off('change', this._onLimitChangeAjax);
      }
    }
  });

  return Filters;
})();
/*
window.theme = window.theme || {};

theme.Filters = (function() {
  var constants = {
    SORT_BY: 'sort_by'
  };
  var selectors = {
    sortSelection: '.filters-toolbar__input--sort',
    defaultSort: '.collection-header__default-sort',
    viewSelection: '.filters-toolbar__input--view',
    defaultView: '.collection-header__default-view',
    filter: '.shop-page #secondary',
    fiterTarget: '.offcanvas_aside_left .offcanvas_shop_sidebar .widget-area',
    filterSelection: '.mfilter-content .filter',
    filterClear: '.mfilter-content .clear'
  };
  
  function beforeInit() {
    if (!$(selectors.filter).length) {
      return;
    }

    $(selectors.fiterTarget).html('');
    $(selectors.filter).clone().appendTo(selectors.fiterTarget);
    $(".offcanvas_shop_sidebar").fitVids();
  }

  function Filters(container) {
    var $container = this.$container = $(container);
    
    this.$filterSelect = $(selectors.filter, $container);
    this.$sortSelect = $(selectors.sortSelection, $container);
    this.$viewSelect = $(selectors.defaultView, $container);
    this.$filterClear = $(selectors.filterClear, $container);
    
    beforeInit();
    
    $(document).on('change', selectors.viewSelection, this._onViewChange.bind(this));
    $(document).on('change', selectors.sortSelection, this._onSortChange.bind(this));
    $(document).on('change', selectors.filterSelection, this._onFilterChange.bind(this));
    $(document).on('click', selectors.filterClear, this._onFilterClear.bind(this));
  }

  Filters.prototype = _.assignIn({}, Filters.prototype, {
    
    _filterAjaxClick: function(newurl) {
      delete Shopify.queryParams.page;
      var url = this._filterCreateUrl(newurl);
      this._filterGetContent(url);
    },
    
    _filterCreateUrl: function(newurl) {
      var path = $.param(Shopify.queryParams).replace(/%2B/g, "+");
      return newurl ? "" != path ? newurl + "?" + path : newurl : location.pathname + "?" + path;
    },
    
    _filterGetContent: function(newurl) {	
      var _content = "#mfilter-content-container";
      var _sidebar = ".mfilter-box .mfilter-content";
      var _this = this;
      $.ajax({
        type: "get",
        url: newurl,
        beforeSend: function() {
          roar.destroyCountdown(), $("body")
          .addClass("is_loading")
          .removeClass("open_filter");
        },
        success: function(data) {
          var _title = $(data).filter('title').text();
          $(_content).empty().html($(data).find(_content).html());
          $(_sidebar).empty().html($(data).find(_sidebar).html());
          History.pushState({
            param: Shopify.queryParams
          }, _title, newurl), setTimeout(function() {
            $("html,body").animate({
              scrollTop: $("body #sandbox").offset().top
            }, 500, "swing")
          }, 100);
          $("body").removeClass("is_loading");
          roar.mapPaginationCallback();
        },
        error: function() {
          $("body").removeClass("is_loading")
        }
      })
    },
    _onFilterClear: function(evt) {
      var currentTags = [];
      if(Shopify.queryParams.constraint) {
        currentTags = Shopify.queryParams.constraint.split('+');
      }
      var _this = $(evt.currentTarget);
      var otherTags = _this.closest('.column').find("input:checked");
      
      if(otherTags.length > 0) {
        otherTags.each(function() {
          var tagName = $(this).val();
          if(tagName) {
            var tagPos = currentTags.indexOf(tagName);
            if(tagPos >= 0) {
              //remove tag
              currentTags.splice(tagPos, 1);
            }
          }
        });
      }
      if(currentTags.length) {
        Shopify.queryParams.constraint = currentTags.join('+');
      }
      else {
        delete Shopify.queryParams.constraint;
      }
      this._filterAjaxClick();
    },
    _onViewChange: function(evt) {
      
      var _this = $(evt.currentTarget);
      var _default_view = $(selectors.defaultView, this.$container).val();
      var _view = _this.val() ? _this.val() : _default_view;
      
      Shopify.queryParams.view = _view;
      this._filterAjaxClick();
    },
    _onSortChange: function(evt) {
      
      var _this = $(evt.currentTarget);
      var _default_sort = $(selectors.defaultSort, this.$container).val();
      var _sort = _this.val() ? _this.val() : _default_sort;
      
      Shopify.queryParams.sort_by = _sort;
      this._filterAjaxClick();
    },
    
    _onFilterChange: function(evt) {
      
      var _this = $(evt.currentTarget);
      var multi_choice = _this.closest('.column').attr("data-multi_choice");
      
      var currentTags = [];
      if(Shopify.queryParams.constraint) {
        currentTags = Shopify.queryParams.constraint.split('+');
      }

      //one selection or multi selection
      if(multi_choice == "false" && !_this.closest('.field').hasClass("active")) {
        //remove other selection first
        var otherTags = _this.closest('.column').find("input:checked");
        if(otherTags.length > 0) {
          otherTags.each(function() {
            var tagName = $(this).val();
            if(tagName) {
              var tagPos = currentTags.indexOf(tagName);
              if(tagPos >= 0) {
                //remove tag
                currentTags.splice(tagPos, 1);
              }
            }
          });
        }
      }

      var tagName = _this.val();
      if(tagName) {
        var tagPos = currentTags.indexOf(tagName);
        if(tagPos >= 0) {
          //tag already existed, remove tag
          currentTags.splice(tagPos, 1);
        } else {
          //tag not existed
          currentTags.push(tagName);
        }
      }
      if(currentTags.length) {
        Shopify.queryParams.constraint = currentTags.join('+');
      }
      else {
        delete Shopify.queryParams.constraint;
      }
      this._filterAjaxClick();
    },

    onUnload: function() {
      this.$sortSelect.off('change', this._onSortChange);
      this.$filterSelect.off('change', this._onFilterChange);
      this.$filterClear.off('click', this._onFilterClear);
    }
  });

  return Filters;
})();
*/

theme.MegaMenuSection = (function() {
  function MegaMenuSection(container) {
    var $container = this.$container = $(container);
    var sectionId = $container.attr('data-section-id');
    var sectionType = $container.attr('data-section-type');
    this.MegaMenu = $("#megamenu-"+sectionId);
    this.megaMenuNamspace = "#megamenu-"+sectionId;
    
    this._init();
  }

  MegaMenuSection.prototype = _.assignIn({}, MegaMenuSection.prototype, {
    _init: function() {
      this._handleMegaMenu();
      this._handleVermenuCategory();
    },
    _handleVermenuCategory: function() {
      if ($("#vermenu_cat_gap").length && roar.getWidthBrowser() >= 992 &&  $(".container-megamenu.vertical .megamenu-wrapper").length > 0 ) {
        var a = $(".container-megamenu.vertical .megamenu-wrapper").outerHeight(),
            b = $(".container-megamenu.vertical .megamenu-wrapper").offset().top,
            c = $("#sidebar").offset().top;
        $("#vermenu_cat_gap").css("height", a - (c - b))
      }
    },
    _handleMegaMenu: function() {
      
    },
    onUnload: function(evt) {
      this.$container.off(this.megaMenuNamspace);
    },
    onSelect: function(evt) {
      this._handleMegaMenu();
      this._handleVermenuCategory();
      $(this.megaMenuNamspace+" .product-grid.cb-item").length > 0 && roar.initCountdown(), 
      //  roar.initProductQuickShopItem(this.megaMenuNamspace+" .product-grid.cb-item"), 
        roar.handleQuickshop(this.megaMenuNamspace+" .product-grid.cb-item");
    },
    onBlockSelect: function(evt) {
    },
    onBlockDeselect: function(evt) {
    },
  });
  return MegaMenuSection;
})();

theme.HeaderNotice = (function() {
  function HeaderNotice(container) {
    var $container = this.$container = $(container);
    var sectionId = this.sectionId = $container.attr('data-section-id');
    var sectionType = $container.attr('data-section-type');
    this.sectionWidgetId = $("#shopify-section-"+sectionId) ;
    this.sectionNamspace = "#"+sectionId;
    this.sectionContent = $(this.sectionNamspace);
    this._init();
  }

  HeaderNotice.prototype = _.assignIn({}, HeaderNotice.prototype, {
    _init: function() {
      var _this = this;
      if(_this.sectionContent.data("hn_use") == "1") {
        var _cond = true;
        if(_this.sectionContent.data("hn_once") == "1" && localStorage.getItem('displayNotice') == 'yes') {
          _cond = false;
        }
        if(_cond == true) {
          $(_this.sectionNamspace +' .header-notice').children().show();
          $(_this.sectionNamspace +' .hn--close').on('click', function () {
            if(_this.sectionContent.data("hn_once") == "1" ) localStorage.setItem('displayNotice', 'yes');
            $(_this.sectionNamspace + " .header-notice").addClass('closed');
            return false;
          });
        }
      }
    },
    onUnload: function(evt) {
      this.$container.off(this.sectionNamspace);
    }
  });
  return HeaderNotice;
})();

theme.CreativeBuilder = (function() {
  function CreativeBuilder(container) {
    var $container = this.$container = $(container);
    var sectionId = this.sectionId = $container.attr('data-section-id');
    var sectionType = $container.attr('data-section-type');
    this.sectionNamspace = "#"+sectionId;
    this.sectionContent = $(this.sectionNamspace);
    this._init();
  }

  CreativeBuilder.prototype = _.assignIn({}, CreativeBuilder.prototype, {
    _init: function() {
      this.initSlider();
      this.initVideo();
      document.querySelectorAll('#creative-builder-' + this.sectionId + ' .rt-tabs').forEach(_tabEl => {
        roar.handleTab(_tabEl);
      });
    },
    initSlider: function() {
      let _sliders = this.$container[0].querySelectorAll('.splide');
      _sliders.forEach(_item => {
        let _slider = new Splide( _item, { updateOnMove: true });
        _slider.on('mounted moved', debounce(function() {
          $(_slider.root).find('.splide__slide').removeClass('is-last-visible');
          $(_slider.root).find('.splide__slide[tabindex=0]').last().addClass('is-last-visible');
        }, 2000));
        _slider.mount();
      });
    },
    initVideo: function() {
      let _selector = '#' + this.$container[0].id + ' .cb-item.video';
      if(!$(_selector).length) return;
      let videos = document.querySelectorAll(_selector);
      for(var i = 0 ; i < videos.length ; i++) {
        theme.ProductVideo.init($(videos[i]), this.sectionId);
      }
    },
    onUnload: function(evt) {
      theme.ProductVideo.removeSectionVideos(this.sectionId);
      this.$container.off(this.sectionNamspace);
    },
    onSelect: function(evt) {
      
    }
  });
  return CreativeBuilder;
})();

theme.HeaderSection = (function() {
  function HeaderSection(container) {
    var $container = this.$container = $(container);
    var sectionId = this.sectionId = $container.attr('data-section-id');
    var sectionType = $container.attr('data-section-type');
    this.sectionNamspace = "#"+sectionId;
    this.sectionContent = $(this.sectionNamspace);
    this._init();
  }

  HeaderSection.prototype = _.assignIn({}, HeaderSection.prototype, {
    _init: function() {
      document.querySelectorAll("[data-predictive-search-open-drawer], [data-predictive-search-mobile-open-drawer]").forEach(_drawer => {
        _drawer.onclick = function(_event){
          if(theme.libs.psearch.state == 0) {
            _event.preventDefault();
            let scriptPRSLoaded = loadScriptAsync(theme.libs.psearch);
            scriptPRSLoaded.then(function(){
              _drawer.dispatchEvent(new Event('click'));
            });
          }
        };
      });
    },
    onUnload: function(evt) {

      if(theme.libs.psearch.state == 1) theme.Search.unload();
      this.$container.off(this.sectionNamspace);
    },
    onSelect: function(evt) {
      theme.CurrencyPicker.init();
      theme.LanguagePicker.init();
    }
  });
  return HeaderSection;
})();

theme.Footer = (function() {
  function Footer(container) {
    var $container = this.$container = $(container);
    var sectionId = this.sectionId = $container.attr('data-section-id');
    var sectionType = $container.attr('data-section-type');
    this.sectionNamspace = "#"+sectionId;
    this.sectionContent = $(this.sectionNamspace);
    this._init();
  }

  Footer.prototype = _.assignIn({}, Footer.prototype, {
    _init: function() {
      this.initNewsletterForm();
    },
    initNewsletterForm: function() {
      var _forms = $('#' + this.$container[0].id + ' .cb-item.newsletter-form form');
      if(_forms.length) {
        for(var i = 0 ; i < _forms.length ; i++) {
          let _form = $(_forms[i]);
          let _action = _form.attr("action");
          _form.ajaxChimp({ url: _action, callback: function(e) {} });
        }
      }
    },
    onUnload: function(evt) {
      this.$container.off(this.sectionNamspace);
    },
    onSelect: function(evt) {
      
    }
  });
  return Footer;
})();

theme.mobileNavSection = (function() {
  function mobileNavSection(container) {
    var $container = (this.$container = $(container));
    var sectionId = (this.sectionId = $container.attr("data-section-id"));
    var sectionType = $container.attr("data-section-type");
    this.mobileNavId = $("#shopify-section-" + sectionId);
    this.mobileNav = $("#primary-" + sectionId);
    this.mobilenavNamespace = "#primary-" + sectionId;
    this._init();
  }

  mobileNavSection.prototype = _.assignIn({}, mobileNavSection.prototype, {
    _init: function() {
      this._initMobile();
    },
    _initMobile: function() {
      $("#off-canvas-layer").on("click", function(e) {
        $(document.body).removeClass("open-canvas-panel");
        $(document.body).removeClass("open_filter");
      });
      $(".mobile-nav-icon").on("click", function(e) {
        $(document.body).toggleClass("open-canvas-panel");
      });
      $(".mobile-child-menu").on("click", function() {
        var parent = $(this).closest(".menu-item-has-children");
        parent.toggleClass("mobile-active");
      });
      $(window).on("resize", function() {
        if ($(window).width() > 991) {
          $(document.body).removeClass("open-canvas-panel");
        }
      });
    },

    onUnload: function(evt) {
      this.$container.off(this.mobilenavNamespace);
    }
  });
  return mobileNavSection;
})();
theme.ProductVariantMobile = (function() {
  function ProductVariantMobile(container) {
    var $container = (this.$container = $(container));
    var sectionId = (this.sectionId = $container.attr("data-section-id"));
    var sectionType = $container.attr("data-section-type");
    this.wrapperId = $("#"+ sectionId);
    this.wrapper = $("#" + sectionId);
    this.wrapperNamspace = "#" + sectionId;
    this.addCartId = $("#btn-" + sectionId+".m-allow-cart");
    this.addCartClass = $(".variant-item-" + sectionId+".m-allow-cart");
    this._init();
  }

  ProductVariantMobile.prototype = _.assignIn({}, ProductVariantMobile.prototype, {
    _init: function() {
      var self = this;
      self._initScroll();
      self._initCompact();
      self._initEvents();
      $( window ).resize(function() {
        if($( window ).width() <= 991){
           self._initCompact();
        }
      });
    },
    _initScroll: function(){
      $(window).on("scroll", function() {
        var scrollTop = $('#shopify-section-product-variants-mobile').height();
        if ($(window).scrollTop() > scrollTop) {
          $(document.body).addClass("sticky-product-variants-mobile") ;
        } else {
          $(document.body).removeClass("sticky-product-variants-mobile") ;
          $(".product-variants-mobile").hasClass('active') && $(".product-variants-mobile").height($('.variants-header').data('height'));
        }
      });
    },
    _initCompact: function() {
        if($(".product-variant-mobile-section").length >0){
          var $accordion = $(".product-variant-mobile-section"),
              $items = $(".product-variants-mobile");

          // Set heights on accordion items and titles on page load
          $items.each(function() {
            var $that = $(this),
                $title = $that.find(".variants-header"),
                titleHeight = $title.innerHeight(),
                contentHeight = $that.find(".variants-content").outerHeight(),
                $parent = $title.closest(".product-variants-mobile");

            $title.data("height", titleHeight);
            $that.data("height", titleHeight + contentHeight);
          });
          $items.each(function() {
            var $that = $(this),
                $title = $that.find(".variants-header"),
                titleHeight = $title.innerHeight(),
                contentHeight = $that.find(".variants-content").outerHeight(),
                $parent = $title.closest(".product-variants-mobile");

            $title.data("height", titleHeight);
            $that.data("height", titleHeight + contentHeight);

            if ($parent.hasClass("active")) {
              $parent.height($parent.data("height"));
            }
          });
          // Event for triggering accordion to show
         $accordion.unbind('click') && $accordion.on("click", ".variants-header .title", function() {
            var $that = $(this),$v_header = $that.closest(".variants-header"), $parent = $that.closest(".product-variants-mobile");

            if (!$parent.hasClass("active")) {
              $items
              .closest(".active")
              .removeClass("active")
              .height($that.data("height"));
            }
            $parent.toggleClass("active");
            // Check if the item is active and set to saved height
            // on either title or item
            if ($parent.hasClass("active")) {
              $parent.height($parent.data("height"));
            } else {
              $parent.height($v_header.data("height"));
            }
          });
        }
    },
    _initEvents: function() {
      // buy now
      var main_variant_id= $('#ProductSelect-product-template.variation-select').val();
      this.addCartId.length > 0 && (this.addCartId.unbind('click') , this.addCartId.on('click', function() {
        $('#ProductSelect-product-template.variation-select').val(main_variant_id);
        $('#AddToCart-product-template').trigger('click');
      }));
        // click on each of variants  
      this.addCartClass.length > 0 && (this.addCartClass.unbind('click') , this.addCartClass.on('click', function(){
        var variant_id = $(this).data('id');
        $('#ProductSelect-product-template.variation-select').val(variant_id);
        $('#AddToCart-product-template').trigger('click')
      }))
    },
    onUnload: function(evt) {
      this.$container.off(this.wrapperNamspace);
    }
  });
  return ProductVariantMobile;
})();
theme.CartVariantMobile = (function() {
  function CartVariantMobile(container) {
    var $container = (this.$container = $(container));
    var sectionId = (this.sectionId = $container.attr("data-section-id"));
    var sectionType = $container.attr("data-section-type");
    this.wrapperId = $("#"+ sectionId);
    this.wrapper = $("#" + sectionId);
    this.wrapperNamspace = "#" + sectionId;
    this.addCartId = $("#btn-" + sectionId+".m-allow-cart");
    this.addCartClass = $(".variant-item-" + sectionId+".m-allow-cart");
    this._init();
  }

  CartVariantMobile.prototype = _.assignIn({}, CartVariantMobile.prototype, {
    _init: function() {
      var self = this;
      self._initScroll();
    },
    _initScroll: function(){
      $(window).on("scroll", function() {
        var scrollTop = $('#shopify-section-product-variants-mobile').height();
        if ($(window).scrollTop() > scrollTop) {
          $(document.body).addClass("sticky-product-variants-mobile") ;
        } else {
          $(document.body).removeClass("sticky-product-variants-mobile") ;
          $(".product-variants-mobile").hasClass('active') && $(".product-variants-mobile").height($('.variants-header').data('height'));
        }
      });
    },
    onUnload: function(evt) {
      this.$container.off(this.wrapperNamspace);
    }
  });
  return CartVariantMobile;
})();
theme.ShippingCalculator = (function() {
  function ShippingCalculator(container) {
    var $container = (this.$container = $(container));
    var sectionId = $container.attr('data-section-id');

    this.selectors = {
      shipping_btn: '#cart__shipping-btn-' + sectionId,
      shipping_calculator: '#shipping__calculator-' + sectionId,
      get_rates: '#shipping__calculator-btn-' + sectionId,
      response: '#shipping__calculator-response-' + sectionId,
      template: '<p id ="shipping-rates-feedback-' + sectionId + '" class="shipping-rates-feedback"></p>',
      address_country: 'address_country-' + sectionId,
      address_province: 'address_province-' + sectionId,
      address_zip: 'address_zip-' + sectionId,
      address_province_label: 'address_province_label-' + sectionId,
      address_province_container: 'address_province_container-' + sectionId
    };
    
    this.strings = {
      submitButton: 'Calculate shipping', 
      submitButtonDisabled: 'Calculating...',
      customerIsLoggedIn: false,
      moneyFormat: theme.settings.moneyFormat
    };
    
    this._init();
  }

  ShippingCalculator.prototype = _.assignIn({}, ShippingCalculator.prototype, {

    _disableButtons: function() {
      var selectors = this.selectors;
      var strings = this.strings;

      $(selectors.get_rates).text(strings.submitButtonDisabled).attr('disabled', 'disabled').addClass('disabled');
    },

    _enableButtons: function() {
      var selectors = this.selectors;
      var strings = this.strings;

      $(selectors.get_rates).removeAttr('disabled').removeClass('disabled').text(strings.submitButton);
    },

    _render: function(response) {
      var selectors = this.selectors;
      var strings = this.strings;

      var template = $(selectors.template);
      var wrapper = $(selectors.response);

      if (wrapper.length) {
        if (response.success) {
          template.addClass('success');

          if (response.rates) {
            template.append(response.rates);

            var rates = response.rates;
            if (rates[0]) {
              var rate = rates[0];

              template.append('Rates start at <span class="money">' + rate.price + '</span>.');
            }
          }
          else {
            template.append('We do not ship to this destination.');
          }
        }
        else {
          template.addClass('error');
          template.append(response.errorFeedback);
        }
        template.appendTo(wrapper);
        //theme.CurrencyPicker.convert(selectors.response + ' .money');
       window.builtin_currencies_used && theme.CurrencyPicker.convert(selectors.response + ' .money');
      }
    },

    _formatRate: function(cents) {
      var selectors = this.selectors;
      var strings = this.strings;

      if (typeof theme.Currency.formatMoney === 'function') {
        return theme.Currency.formatMoney(cents, strings.moneyFormat);
      }    
      if (typeof cents == 'string') {
        cents = cents.replace('.','');
      }
      var value = '';
      var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
      var formatString = strings.moneyFormat;

      function defaultOption(opt, def) {
        return (typeof opt == 'undefined' ? def : opt);
      }
      function formatWithDelimiters(number, precision, thousands, decimal) {
        precision = defaultOption(precision, 2);
        thousands = defaultOption(thousands, ',');
        decimal   = defaultOption(decimal, '.');
        if (isNaN(number) || number == null) {
          return 0;
        }
        number = (number/100.0).toFixed(precision);
        var parts   = number.split('.'),
            dollars = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands),
            cents   = parts[1] ? (decimal + parts[1]) : '';
        return dollars + cents;
      }
      switch (formatString.match(placeholderRegex)[1]) {
        case 'amount':
          value = formatWithDelimiters(cents, 2);
          break;
        case 'amount_no_decimals':
          value = formatWithDelimiters(cents, 0);
          break;
        case 'amount_with_comma_separator':
          value = formatWithDelimiters(cents, 2, '.', ',');
          break;
        case 'amount_no_decimals_with_comma_separator':
          value = formatWithDelimiters(cents, 0, '.', ',');
          break;
      }
      return formatString.replace(placeholderRegex, value);
    },

    _onCartShippingRatesUpdate: function(rates, shipping_address ) {
      var self = this;
      var selectors = this.selectors;
      var strings = this.strings;

      // Re-enable calculate shipping buttons.
      self._enableButtons();

      // Formatting shipping address.
      var readable_address = '';
      if (shipping_address.zip) {
        readable_address += shipping_address.zip + ', ';
      }
      if (shipping_address.province) {
        readable_address += shipping_address.province + ', ';
      }
      readable_address += shipping_address.country;

      // Show estimated shipping.
      if (rates.length) {
        for (var i=0; i < rates.length; i++) {
          rates[i].price = self._formatRate(rates[i].price);
        }
      }

      // Show rates and feedback.
      self._render({rates: rates, address: readable_address, success:true});

      // Revealing response.
      $(selectors.response).fadeIn();
    },

    _pollForCartShippingRatesForDestination: function(shippingAddress) {
      var self = this;
      var selectors = this.selectors;
      var strings = this.strings;

      var poller = function() {
        $.ajax('/cart/async_shipping_rates', {
          dataType: 'json',
          success: function(response, textStatus, xhr) {
            if (xhr.status === 200) {
              self._onCartShippingRatesUpdate(response.shipping_rates, shippingAddress)
            } else {
              setTimeout(poller, 500)
            }
          },
          error: function(XMLHttpRequest, textStatus) {
            self._onError(XMLHttpRequest, textStatus, self);
          }
        })
      }
      return poller;
    },

    _fullMessagesFromErrors: function(errors) {
      var selectors = this.selectors;
      var strings = this.strings;

      var fullMessages = [];
      $.each(errors, function(attribute, messages) {
        $.each(messages, function(index, message) {
          fullMessages.push(attribute + ' ' + message);
        });
      });
      return fullMessages;
    },

    _onError: function(XMLHttpRequest, textStatus, self) {
      var selectors = self.selectors;
      var strings = self.strings;

      // Re-enable calculate shipping buttons.
      self._enableButtons();

      // Formatting error message.
      var feedback = '';
      var data = eval('(' + XMLHttpRequest.responseText + ')');
      if (!!data.message) {
        feedback = data.message + '(' + data.status  + '): ' + data.description;
      } 
      else {
        feedback = 'Error : ' + self._fullMessagesFromErrors(data).join('; ') + '.';
      }    
      if (feedback === 'Error : country is not supported.') {
        feedback = 'We do not ship to this destination.'
      }

      // Update calculator.
      self._render({rates: [], errorFeedback: feedback, success: false});
      $(selectors.response).show();
    },

    _getCartShippingRatesForDestination: function(shippingAddress) {
      var self = this;
      var selectors = this.selectors;
      var strings = this.strings;

      $.ajax({
        type: 'POST',
        url: '/cart/prepare_shipping_rates',
        data: $.param({'shipping_address': shippingAddress}),
        success: self._pollForCartShippingRatesForDestination(shippingAddress),
        error: function(XMLHttpRequest, textStatus) {
          self._onError(XMLHttpRequest, textStatus, self);
        }
      });
    },

    _init: function() {
      var self = this;
      var selectors = this.selectors;
      var strings = this.strings;

      if (!$(selectors.shipping_calculator).length) {
        return;
      }

      // Initialize observer on shipping address.
      new Shopify.CountryProvinceSelector(selectors.address_country, selectors.address_province, {hideElement: selectors.address_province_container});

      // Updating province label.
      var countriesSelect = $('#' + selectors.address_country);
      var addressProvinceLabelEl = $('#' + selectors.address_province_label).get(0);
      if (typeof Countries !== 'undefined') {
        Countries.updateProvinceLabel(countriesSelect.val(),addressProvinceLabelEl);
        countriesSelect.change(function() {
          Countries.updateProvinceLabel(countriesSelect.val(),addressProvinceLabelEl);
        });
      }

      // When either of the calculator buttons is clicked, get rates.
      $(selectors.get_rates).on("click", function() {
        // Disabling all buttons.
        self._disableButtons();

        // Hiding response.
        $(selectors.response).empty().hide();

        // Reading shipping address for submission.
        var shippingAddress = {};
        shippingAddress.zip = $('#' + selectors.address_zip).val() || '';
        shippingAddress.country = $('#' + selectors.address_country).val() || '';
        shippingAddress.province = $('#' + selectors.address_province).val() || '';
        self._getCartShippingRatesForDestination(shippingAddress);
      });

      // We don't wait for customer to click if we know his/her address.
      if (strings.customerIsLoggedIn) {
        $(selectors.get_rates + ':eq(0)').trigger('click');
      }

      // Click shipping button
      $(selectors.shipping_btn).on("click", function() {
        $(selectors.shipping_calculator).slideToggle();
      });
    },

    onUnload: function() {
      //
    }
  });

  return ShippingCalculator;
})();
theme.GalleryTemplate = (function() {
  function GalleryTemplate(container) {
    var $container = (this.$container = $(container));
    var sectionId = $container.attr('data-section-id');
    this.selectors = {
      grid_gallery: 'grid-gallery-' + sectionId
    };
    this._init();
  }

  GalleryTemplate.prototype = _.assignIn({}, GalleryTemplate.prototype, {

    _init: function() {
      new CBPGridGallery( document.getElementById( this.selectors.grid_gallery ) );
    },

    onUnload: function() {
      //
    }
  });

  return GalleryTemplate;
})();
theme.FilterWidgetSection = (function() {
  function FilterWidgetSection(container) {
    var $container = this.$container = $(container);
    var sectionId = this.sectionId = $container.attr('data-section-id');
    var sectionType = $container.attr('data-section-type');
    this.filterWidgetId = $("#shopify-section-"+sectionId) ;
    this.filterWidgetNamspace = "#home-filter-"+sectionId;
    this.filterNewSelect = $("#home-filter-"+ sectionId + " .home-filter--dropdown-wrapper");
    this.filterCollectionId =$("#home-filter-"+ sectionId + " .collection__selection select");
    
    this.filterTagSelection = $("#home-filter-"+ sectionId + " .tag__selection");
    
    this.filterButton = $("#home-filter-"+ sectionId + " .button");
    this._init();
    this._initDropdown();
  }

  FilterWidgetSection.prototype = _.assignIn({}, FilterWidgetSection.prototype, {
    _init: function() {
      
    },
    _initDropdown: function(){
      this.filterNewSelect.each(function() {
        var c_select = $(this).find('select'),
            c_selection = $(this).find('a.mimic-selected'),
            b_options = $(this).find('ul.mimic-options'),
            c_option = b_options.find('a');
        c_selection.on("click", function(evt) {
          evt.stopPropagation();
          $('a.mimic-selected').not(this).next('ul.options').hide().removeClass('active');
          var $comments = $(this).next(b_options);
          $comments.stop().slideToggle('fast', function () {
            $(this).toggleClass('active');
          });
        });

        c_option.on("click", function(evt) {
          evt.stopPropagation();
          c_selection.text($(this).text()).removeClass('active');
          c_select.find('option').prop('selected', false);
          c_select.find('option[value="' + $(this).attr('rel') + '"]').prop('selected', 'selected');          
          b_options.hide();
          c_select.change();          
        });

        $(document).on("click", function() {
          c_selection.removeClass('active');
          b_options.hide()
        })
      });
      
      //init filter select collection
      var tagSelection = this.filterTagSelection;
      this.filterCollectionId.on('change', function(){
        var val = $(this).find('option:selected').val();
        $(this).parent().find(".first").removeClass('hidden');
        if (val === '') {
          tagSelection.find(".home-filter--dropdown-backdrop").addClass('disabled');
          tagSelection.find("select").val('').attr('disabled', true);                
        } else {
          $(this).parent().find(".error").hide();
          tagSelection.find(".home-filter--dropdown-backdrop").removeClass('disabled').addClass('enabled');
          tagSelection.find("select").val('').attr('disabled', false); 
        }
      });
      var tagSelect = this.filterTagSelection.find("select");
      tagSelect.on('change', function(){
        var val = $(this).find('option:selected').val();
        $(this).parent().find(".first").removeClass('hidden');
      });
      
      var collection_select = this.filterCollectionId;
      var error_div = this.filterCollectionId.parent().find(".error");
      
      this.filterButton.on("click", function(){
        var filters = [];
        tagSelect.each(function(){ 
          var _val = $(this).val();
          if (_val !== '') {
            filters.push(_val);
          }
        })
        if(collection_select.val() == "")
        {
          error_div.show();
        } else {
          var filter_url = window.location.origin + collection_select.val() +"?constraint="+ filters.join("+");
          window.location = filter_url;
          error_div.hide();
        }
      });
    
    },
    onUnload: function(evt) {
      this.$container.off(this.filterWidgetNamspace);
    }
  });
  return FilterWidgetSection;
})();

function onYouTubeIframeAPIReady() {
  // theme.Video.loadVideos();
  theme.ProductVideo.loadVideos(theme.ProductVideo.hosts.youtube);
}


$(document).ready(function() {
  theme.ThePilot.doPilot();
  var sections = new theme.Sections();
  sections.register("header-notice", theme.HeaderNotice)
  sections.register("product-template", theme.Product);
  sections.register('mega-menu', theme.MegaMenuSection);
  sections.register("mobile-nav-section", theme.mobileNavSection);
  sections.register("product-variant-mobile", theme.ProductVariantMobile);
  sections.register("cart-variant-mobile", theme.CartVariantMobile);
  sections.register('shipping-calculator', theme.ShippingCalculator);
  sections.register('collection-template', theme.Filters);
  sections.register('search-template', theme.Filters);
  sections.register('gallery-template', theme.GalleryTemplate);
  sections.register('home-filter', theme.FilterWidgetSection);
  sections.register('product-recommendations', theme.productRecommendationsSection);
  sections.register('header-elements', theme.HeaderSection);
  sections.register('creative-builder', theme.CreativeBuilder);
  sections.register('footer', theme.Footer);
});
$(document).one('touchstart', function() {
  theme.Helpers.setTouch();
});

(function ($) {
  'use strict';
  window.onresize = function(){
    roar.getWidthBrowser() < 768 &&
      $("#popup-mailchimp.d-none.d-sm-block").find(".mfp-close").trigger("click");
  };

  window.onload = function () {
    document.body.classList.add('loaded');

    roar.init();
    theme.CurrencyPicker.init();
    theme.LanguagePicker.init();

    setTimeout(function(){roar.handleSeasonalFrame();},3000);
  }
})(jQuery);
