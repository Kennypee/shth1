theme.Drawers = (function () {
    function Drawer(id, position, options) {
        var DEFAULT_OPEN_CLASS = 'js-drawer-open';
        var DEFAULT_CLOSE_CLASS = 'js-drawer-close';

        var defaults = {
            selectors: {
                openVariant: '.' + DEFAULT_OPEN_CLASS + '-' + position,
                openVariantMobile: '.' + DEFAULT_OPEN_CLASS + '-mobile-' + position,
                close: '.' + DEFAULT_CLOSE_CLASS
            },
            classes: {
                open: DEFAULT_OPEN_CLASS,
                openVariant: DEFAULT_OPEN_CLASS + '-' + position,
                openVariantMobile: DEFAULT_OPEN_CLASS + '-mobile-' + position
            },
            withPredictiveSearch: false
        };

        this.nodes = {
            parents: [document.documentElement, document.body],
            page: document.getElementById('PageContainer')
        };

        this.eventHandlers = {};

        this.config = Object.assign({}, defaults, options);
        this.position = position;
        this.drawer = document.getElementById(id);

        if (!this.drawer) {
            return false;
        }

        this.drawerIsOpen = false;
        this.init();
    }

    Drawer.prototype.init = function () {
        document
            .querySelector(this.config.selectors.openVariant)
            .addEventListener('click', this.open.bind(this));

        document
            .querySelector(this.config.selectors.openVariantMobile)
            .addEventListener('click', this.open.bind(this));

        this.drawer
            .querySelector(this.config.selectors.close)
            .addEventListener('click', this.close.bind(this));
    };

    Drawer.prototype.open = function (evt) {
        // Keep track if drawer was opened from a click, or called by another function
        var externalCall = false;

        // Prevent following href if link is clicked
        if (evt) {
            evt.preventDefault();
        } else {
            externalCall = true;
        }

        // Without this, the drawer opens, the click event bubbles up to nodes.page
        // which closes the drawer.
        if (evt && evt.stopPropagation) {
            evt.stopPropagation();
            // save the source of the click, we'll focus to this on close
            this.activeSource = evt.currentTarget;
        }

        if (this.drawerIsOpen && !externalCall) {
            return this.close();
        }

        // Add is-transitioning class to moved elements on open so drawer can have
        // transition for close animation
        if (!this.config.withPredictiveSearch) {
            theme.Helpers.prepareTransition(this.drawer);
        }

        this.nodes.parents.forEach(
            function (parent) {
                parent.classList.add(
                    this.config.classes.open,
                    this.config.classes.openVariant,
                    this.config.classes.openVariantMobile
                );
            }.bind(this)
        );

        this.drawerIsOpen = true;

        // Run function when draw opens if set
        if (
            this.config.onDrawerOpen &&
            typeof this.config.onDrawerOpen === 'function'
        ) {
            if (!externalCall) {
                this.config.onDrawerOpen();
            }
        }

        if (this.activeSource && this.activeSource.hasAttribute('aria-expanded')) {
            this.activeSource.setAttribute('aria-expanded', 'true');
        }

        // Set focus on drawer
        /*
      var trapFocusConfig = {
        container: this.drawer
      };
  
      if (this.config.elementToFocusOnOpen) {
        trapFocusConfig.elementToFocus = this.config.elementToFocusOnOpen;
      }
  
      slate.a11y.trapFocus(trapFocusConfig);
      
      */

        this.bindEvents();

        return this;
    };

    Drawer.prototype.close = function () {
        if (!this.drawerIsOpen) {
            // don't close a closed drawer
            return;
        }

        // deselect any focused form elements
        document.activeElement.dispatchEvent(
            new CustomEvent('blur', {
                bubbles: true,
                cancelable: true
            })
        );

        // Ensure closing transition is applied to moved elements, like the nav
        if (!this.config.withPredictiveSearch) {
            theme.Helpers.prepareTransition(this.drawer);
        }

        this.nodes.parents.forEach(
            function (parent) {
                parent.classList.remove(
                    this.config.classes.open,
                    this.config.classes.openVariant,
                    this.config.classes.openVariantMobile
                );
            }.bind(this)
        );

        if (this.activeSource && this.activeSource.hasAttribute('aria-expanded')) {
            this.activeSource.setAttribute('aria-expanded', 'false');
        }

        this.drawerIsOpen = false;

        // Remove focus on drawer
        /*
        slate.a11y.removeTrapFocus({
          container: this.drawer
        });
        */
        this.unbindEvents();

        // Run function when draw closes if set
        if (
            this.config.onDrawerClose &&
            typeof this.config.onDrawerClose === 'function'
        ) {
            this.config.onDrawerClose();
        }
    };

    Drawer.prototype.bindEvents = function () {
        this.eventHandlers.drawerKeyupHandler = function (evt) {
            // close on 'esc' keypress
            if (evt.keyCode === 27) {
                this.close();
                return false;
            } else {
                return true;
            }
        }.bind(this);

        this.eventHandlers.drawerTouchmoveHandler = function () {
            return false;
        };

        this.eventHandlers.drawerClickHandler = function () {
            this.close();
            return false;
        }.bind(this);

        // Add event listener to document body
        document.body.addEventListener(
            'keyup',
            this.eventHandlers.drawerKeyupHandler
        );

        // Lock scrolling on mobile

        this.nodes.page.addEventListener(
            'touchmove',
            this.eventHandlers.drawerTouchmoveHandler
        );

        this.nodes.page.addEventListener(
            'click',
            this.eventHandlers.drawerClickHandler
        );

    };

    Drawer.prototype.unbindEvents = function () {

        this.nodes.page.removeEventListener(
            'touchmove',
            this.eventHandlers.drawerTouchmoveHandler
        );
        this.nodes.page.removeEventListener(
            'click',
            this.eventHandlers.drawerClickHandler
        );

        document.body.removeEventListener(
            'keyup',
            this.eventHandlers.drawerKeyupHandler
        );
    };

    return Drawer;
})();

this.Shopify = this.Shopify || {};
this.Shopify.theme = this.Shopify.theme || {};
this.Shopify.theme.PredictiveSearch = (function () {
    'use strict';

    function validateQuery(query) {
        var error;

        if (query === null || query === undefined) {
            error = new TypeError("'query' is missing");
            error.type = 'argument';
            throw error;
        }

        if (typeof query !== 'string') {
            error = new TypeError("'query' is not a string");
            error.type = 'argument';
            throw error;
        }
    }

    function GenericError() {
        var error = Error.call(this);

        error.name = 'Server error';
        error.message = 'Something went wrong on the server';
        error.status = 500;

        return error;
    }

    function NotFoundError(status) {
        var error = Error.call(this);

        error.name = 'Not found';
        error.message = 'Not found';
        error.status = status;

        return error;
    }

    function ServerError() {
        var error = Error.call(this);

        error.name = 'Server error';
        error.message = 'Something went wrong on the server';
        error.status = 500;

        return error;
    }

    function ContentTypeError(status) {
        var error = Error.call(this);

        error.name = 'Content-Type error';
        error.message = 'Content-Type was not provided or is of wrong type';
        error.status = status;

        return error;
    }

    function JsonParseError(status) {
        var error = Error.call(this);

        error.name = 'JSON parse error';
        error.message = 'JSON syntax error';
        error.status = status;

        return error;
    }

    function ThrottledError(status, name, message, retryAfter) {
        var error = Error.call(this);

        error.name = name;
        error.message = message;
        error.status = status;
        error.retryAfter = retryAfter;

        return error;
    }

    function InvalidParameterError(status, name, message) {
        var error = Error.call(this);

        error.name = name;
        error.message = message;
        error.status = status;

        return error;
    }

    function ExpectationFailedError(status, name, message) {
        var error = Error.call(this);

        error.name = name;
        error.message = message;
        error.status = status;

        return error;
    }

    function request(configParams, query, onSuccess, onError) {
        var xhr = new XMLHttpRequest();

        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE) {
                return;
            }

            var contentType = xhr.getResponseHeader('Content-Type');

            if (xhr.status >= 500) {
                onError(new ServerError());

                return;
            }

            if (xhr.status === 404) {
                onError(new NotFoundError(xhr.status));

                return;
            }

            if (
                typeof contentType !== 'string' ||
                contentType.toLowerCase().match('application/json') === null
            ) {
                onError(new ContentTypeError(xhr.status));

                return;
            }

            if (xhr.status === 417) {
                try {
                    var invalidParameterJson = JSON.parse(xhr.responseText);

                    onError(
                        new InvalidParameterError(
                            xhr.status,
                            invalidParameterJson.message,
                            invalidParameterJson.description
                        )
                    );
                } catch (error) {
                    onError(new JsonParseError(xhr.status));
                }

                return;
            }

            if (xhr.status === 422) {
                try {
                    var expectationFailedJson = JSON.parse(xhr.responseText);

                    onError(
                        new ExpectationFailedError(
                            xhr.status,
                            expectationFailedJson.message,
                            expectationFailedJson.description
                        )
                    );
                } catch (error) {
                    onError(new JsonParseError(xhr.status));
                }

                return;
            }

            if (xhr.status === 429) {
                try {
                    var throttledJson = JSON.parse(xhr.responseText);

                    onError(
                        new ThrottledError(
                            xhr.status,
                            throttledJson.message,
                            throttledJson.description,
                            xhr.getResponseHeader('Retry-After')
                        )
                    );
                } catch (error) {
                    onError(new JsonParseError(xhr.status));
                }

                return;
            }

            if (xhr.status === 200) {
                try {
                    var res = JSON.parse(xhr.responseText);
                    res.query = query;
                    onSuccess(res);
                } catch (error) {
                    onError(new JsonParseError(xhr.status));
                }

                return;
            }

            try {
                var genericErrorJson = JSON.parse(xhr.responseText);
                onError(
                    new GenericError(
                        xhr.status,
                        genericErrorJson.message,
                        genericErrorJson.description
                    )
                );
            } catch (error) {
                onError(new JsonParseError(xhr.status));
            }

            return;
        };

        xhr.open(
            'get',
            '/search/suggest.json?q=' + encodeURIComponent(query) + '&' + configParams
        );

        xhr.setRequestHeader('Content-Type', 'application/json');

        xhr.send();
    }

    function Cache(config) {
        this._store = {};
        this._keys = [];
        if (config && config.bucketSize) {
            this.bucketSize = config.bucketSize;
        } else {
            this.bucketSize = 20;
        }
    }

    Cache.prototype.set = function (key, value) {
        if (this.count() >= this.bucketSize) {
            var deleteKey = this._keys.splice(0, 1);
            this.delete(deleteKey);
        }

        this._keys.push(key);
        this._store[key] = value;

        return this._store;
    };

    Cache.prototype.get = function (key) {
        return this._store[key];
    };

    Cache.prototype.has = function (key) {
        return Boolean(this._store[key]);
    };

    Cache.prototype.count = function () {
        return Object.keys(this._store).length;
    };

    Cache.prototype.delete = function (key) {
        var exists = Boolean(this._store[key]);
        delete this._store[key];
        return exists && !this._store[key];
    };

    function Dispatcher() {
        this.events = {};
    }

    Dispatcher.prototype.on = function (eventName, callback) {
        var event = this.events[eventName];
        if (!event) {
            event = new DispatcherEvent(eventName);
            this.events[eventName] = event;
        }
        event.registerCallback(callback);
    };

    Dispatcher.prototype.off = function (eventName, callback) {
        var event = this.events[eventName];
        if (event && event.callbacks.indexOf(callback) > -1) {
            event.unregisterCallback(callback);
            if (event.callbacks.length === 0) {
                delete this.events[eventName];
            }
        }
    };

    Dispatcher.prototype.dispatch = function (eventName, payload) {
        var event = this.events[eventName];
        if (event) {
            event.fire(payload);
        }
    };

    function DispatcherEvent(eventName) {
        this.eventName = eventName;
        this.callbacks = [];
    }

    DispatcherEvent.prototype.registerCallback = function (callback) {
        this.callbacks.push(callback);
    };

    DispatcherEvent.prototype.unregisterCallback = function (callback) {
        var index = this.callbacks.indexOf(callback);
        if (index > -1) {
            this.callbacks.splice(index, 1);
        }
    };

    DispatcherEvent.prototype.fire = function (payload) {
        var callbacks = this.callbacks.slice(0);
        callbacks.forEach(function (callback) {
            callback(payload);
        });
    };

    function debounce(func, wait) {
        var timeout = null;
        return function () {
            var context = this;
            var args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(function () {
                timeout = null;
                func.apply(context, args);
            }, wait || 0);
        };
    }

    function objectToQueryParams(obj, parentKey) {
        var output = '';
        parentKey = parentKey || null;

        Object.keys(obj).forEach(function (key) {
            var outputKey = key + '=';
            if (parentKey) {
                outputKey = parentKey + '[' + key + ']';
            }

            switch (trueTypeOf(obj[key])) {
                case 'object':
                    output += objectToQueryParams(obj[key], parentKey ? outputKey : key);
                    break;
                case 'array':
                    output += outputKey + '=' + obj[key].join(',') + '&';
                    break;
                default:
                    if (parentKey) {
                        outputKey += '=';
                    }
                    output += outputKey + encodeURIComponent(obj[key]) + '&';
                    break;
            }
        });

        return output;
    }

    function trueTypeOf(obj) {
        return Object.prototype.toString
            .call(obj)
            .slice(8, -1)
            .toLowerCase();
    }

    var DEBOUNCE_RATE = 10;
    var requestDebounced = debounce(request, DEBOUNCE_RATE);

    function PredictiveSearch(config) {
        if (!config) {
            throw new TypeError('No config object was specified');
        }

        this._retryAfter = null;
        this._currentQuery = null;

        this.dispatcher = new Dispatcher();
        this.cache = new Cache({
            bucketSize: 40
        });
        this.configParams = objectToQueryParams(config);
    }

    PredictiveSearch.TYPES = {
        PRODUCT: 'product',
        PAGE: 'page',
        ARTICLE: 'article'
    };

    PredictiveSearch.FIELDS = {
        AUTHOR: 'author',
        BODY: 'body',
        PRODUCT_TYPE: 'product_type',
        TAG: 'tag',
        TITLE: 'title',
        VARIANTS_BARCODE: 'variants.barcode',
        VARIANTS_SKU: 'variants.sku',
        VARIANTS_TITLE: 'variants.title',
        VENDOR: 'vendor'
    };

    PredictiveSearch.UNAVAILABLE_PRODUCTS = {
        SHOW: 'show',
        HIDE: 'hide',
        LAST: 'last'
    };

    PredictiveSearch.prototype.query = function query(query) {
        try {
            validateQuery(query);
        } catch (error) {
            this.dispatcher.dispatch('error', error);
            return;
        }

        if (query === '') {
            return this;
        }

        this._currentQuery = normalizeQuery(query);
        var cacheResult = this.cache.get(this._currentQuery);
        if (cacheResult) {
            this.dispatcher.dispatch('success', cacheResult);
            return this;
        }

        requestDebounced(
            this.configParams,
            query,
            function (result) {
                this.cache.set(normalizeQuery(result.query), result);
                if (normalizeQuery(result.query) === this._currentQuery) {
                    this._retryAfter = null;
                    this.dispatcher.dispatch('success', result);
                }
            }.bind(this),
            function (error) {
                if (error.retryAfter) {
                    this._retryAfter = error.retryAfter;
                }
                this.dispatcher.dispatch('error', error);
            }.bind(this)
        );

        return this;
    };

    PredictiveSearch.prototype.on = function on(eventName, callback) {
        this.dispatcher.on(eventName, callback);

        return this;
    };

    PredictiveSearch.prototype.off = function on(eventName, callback) {
        this.dispatcher.off(eventName, callback);

        return this;
    };

    function normalizeQuery(query) {
        if (typeof query !== 'string') {
            return null;
        }

        return query
            .trim()
            .replace(' ', '-')
            .toLowerCase();
    }

    return PredictiveSearch;
})();

this.Shopify = this.Shopify || {};
this.Shopify.theme = this.Shopify.theme || {};
this.Shopify.theme.PredictiveSearchComponent = (function (PredictiveSearch) {
    'use strict';

    PredictiveSearch =
        PredictiveSearch && PredictiveSearch.hasOwnProperty('default') ?
        PredictiveSearch['default'] :
        PredictiveSearch;

    var DEFAULT_PREDICTIVE_SEARCH_API_CONFIG = {
        resources: {
            type: [PredictiveSearch.TYPES.PRODUCT],
            options: {
                unavailable_products: PredictiveSearch.UNAVAILABLE_PRODUCTS.LAST,
                fields: [
                    PredictiveSearch.FIELDS.TITLE,
                    PredictiveSearch.FIELDS.VENDOR,
                    PredictiveSearch.FIELDS.PRODUCT_TYPE,
                    PredictiveSearch.FIELDS.VARIANTS_TITLE
                ]
            }
        }
    };

    function PredictiveSearchComponent(config) {
        // validate config
        if (
            !config ||
            !config.selectors ||
            !config.selectors.input ||
            !isString(config.selectors.input) ||
            !config.selectors.result ||
            !isString(config.selectors.result) ||
            !config.resultTemplateFct ||
            !isFunction(config.resultTemplateFct) ||
            !config.numberOfResultsTemplateFct ||
            !isFunction(config.numberOfResultsTemplateFct) ||
            !config.loadingResultsMessageTemplateFct ||
            !isFunction(config.loadingResultsMessageTemplateFct)
        ) {
            var error = new TypeError(
                'PredictiveSearchComponent config is not valid'
            );
            error.type = 'argument';
            throw error;
        }

        // Find nodes
        this.nodes = findNodes(config.selectors);

        // Validate nodes
        if (!isValidNodes(this.nodes)) {
            // eslint-disable-next-line no-console
            console.warn('Could not find valid nodes');
            return;
        }

        // Store the keyword that was used for the search
        this._searchKeyword = '';

        // Assign result template
        this.resultTemplateFct = config.resultTemplateFct;

        // Assign number of results template
        this.numberOfResultsTemplateFct = config.numberOfResultsTemplateFct;

        // Assign loading state template function
        this.loadingResultsMessageTemplateFct =
            config.loadingResultsMessageTemplateFct;

        // Assign number of search results
        this.numberOfResults = config.numberOfResults || 4;

        // Set classes
        this.classes = {
            visibleVariant: config.visibleVariant ?
                config.visibleVariant :
                'predictive-search-wrapper--visible',
            itemSelected: config.itemSelectedClass ?
                config.itemSelectedClass :
                'predictive-search-item--selected',
            clearButtonVisible: config.clearButtonVisibleClass ?
                config.clearButtonVisibleClass :
                'predictive-search__clear-button--visible'
        };

        this.selectors = {
            searchResult: config.searchResult ?
                config.searchResult :
                '[data-search-result]'
        };

        // Assign callbacks
        this.callbacks = assignCallbacks(config);

        // Add input attributes
        addInputAttributes(this.nodes.input);

        // Add input event listeners
        this._addInputEventListeners();

        // Add body listener
        this._addBodyEventListener();

        // Add accessibility announcer
        this._addAccessibilityAnnouncer();

        // Display the reset button if the input is not empty
        this._toggleClearButtonVisibility();

        // Instantiate Predictive Search API
        this.predictiveSearch = new PredictiveSearch(
            config.PredictiveSearchAPIConfig ?
            config.PredictiveSearchAPIConfig :
            DEFAULT_PREDICTIVE_SEARCH_API_CONFIG
        );

        // Add predictive search success event listener
        this.predictiveSearch.on(
            'success',
            this._handlePredictiveSearchSuccess.bind(this)
        );

        // Add predictive search error event listener
        this.predictiveSearch.on(
            'error',
            this._handlePredictiveSearchError.bind(this)
        );
    }

    /**
     * Private methods
     */
    function findNodes(selectors) {
        return {
            input: document.querySelector(selectors.input),
            reset: document.querySelector(selectors.reset),
            result: document.querySelector(selectors.result)
        };
    }

    function isValidNodes(nodes) {
        if (
            !nodes ||
            !nodes.input ||
            !nodes.result ||
            nodes.input.tagName !== 'INPUT'
        ) {
            return false;
        }

        return true;
    }

    function assignCallbacks(config) {
        return {
            onBodyMousedown: config.onBodyMousedown,
            onBeforeOpen: config.onBeforeOpen,
            onOpen: config.onOpen,
            onBeforeClose: config.onBeforeClose,
            onClose: config.onClose,
            onInputFocus: config.onInputFocus,
            onInputKeyup: config.onInputKeyup,
            onInputBlur: config.onInputBlur,
            onInputReset: config.onInputReset,
            onBeforeDestroy: config.onBeforeDestroy,
            onDestroy: config.onDestroy
        };
    }

    function addInputAttributes(input) {
        input.setAttribute('autocorrect', 'off');
        input.setAttribute('autocomplete', 'off');
        input.setAttribute('autocapitalize', 'off');
        input.setAttribute('spellcheck', 'false');
    }

    function removeInputAttributes(input) {
        input.removeAttribute('autocorrect', 'off');
        input.removeAttribute('autocomplete', 'off');
        input.removeAttribute('autocapitalize', 'off');
        input.removeAttribute('spellcheck', 'false');
    }

    /**
     * Public variables
     */
    PredictiveSearchComponent.prototype.isResultVisible = false;
    PredictiveSearchComponent.prototype.results = {};

    /**
     * "Private" variables
     */
    PredictiveSearchComponent.prototype._latencyTimer = null;
    PredictiveSearchComponent.prototype._resultNodeClicked = false;

    /**
     * "Private" instance methods
     */
    PredictiveSearchComponent.prototype._addInputEventListeners = function () {
        var input = this.nodes.input;
        var reset = this.nodes.reset;

        if (!input) {
            return;
        }

        this._handleInputFocus = this._handleInputFocus.bind(this);
        this._handleInputBlur = this._handleInputBlur.bind(this);
        this._handleInputKeyup = this._handleInputKeyup.bind(this);
        this._handleInputKeydown = this._handleInputKeydown.bind(this);

        input.addEventListener('focus', this._handleInputFocus);
        input.addEventListener('blur', this._handleInputBlur);
        input.addEventListener('keyup', this._handleInputKeyup);
        input.addEventListener('keydown', this._handleInputKeydown);

        if (reset) {
            this._handleInputReset = this._handleInputReset.bind(this);
            reset.addEventListener('click', this._handleInputReset);
        }
    };

    PredictiveSearchComponent.prototype._removeInputEventListeners = function () {
        var input = this.nodes.input;

        input.removeEventListener('focus', this._handleInputFocus);
        input.removeEventListener('blur', this._handleInputBlur);
        input.removeEventListener('keyup', this._handleInputKeyup);
        input.removeEventListener('keydown', this._handleInputKeydown);
    };

    PredictiveSearchComponent.prototype._addBodyEventListener = function () {
        this._handleBodyMousedown = this._handleBodyMousedown.bind(this);

        document
            .querySelector('body')
            .addEventListener('mousedown', this._handleBodyMousedown);
    };

    PredictiveSearchComponent.prototype._removeBodyEventListener = function () {
        document
            .querySelector('body')
            .removeEventListener('mousedown', this._handleBodyMousedown);
    };

    PredictiveSearchComponent.prototype._removeClearButtonEventListener = function () {
        var reset = this.nodes.reset;

        if (!reset) {
            return;
        }

        reset.removeEventListener('click', this._handleInputReset);
    };

    /**
     * Event handlers
     */
    PredictiveSearchComponent.prototype._handleBodyMousedown = function (evt) {
        if (this.isResultVisible && this.nodes !== null) {
            if (
                evt.target.isEqualNode(this.nodes.input) ||
                this.nodes.input.contains(evt.target) ||
                evt.target.isEqualNode(this.nodes.result) ||
                this.nodes.result.contains(evt.target)
            ) {
                this._resultNodeClicked = true;
            } else {
                if (isFunction(this.callbacks.onBodyMousedown)) {
                    var returnedValue = this.callbacks.onBodyMousedown(this.nodes);
                    if (isBoolean(returnedValue) && returnedValue) {
                        this.close();
                    }
                } else {
                    this.close();
                }
            }
        }
    };

    PredictiveSearchComponent.prototype._handleInputFocus = function (evt) {
        if (isFunction(this.callbacks.onInputFocus)) {
            var returnedValue = this.callbacks.onInputFocus(this.nodes);
            if (isBoolean(returnedValue) && !returnedValue) {
                return false;
            }
        }

        if (evt.target.value.length > 0) {
            this._search();
        }

        return true;
    };

    PredictiveSearchComponent.prototype._handleInputBlur = function () {
        // This has to be done async, to wait for the focus to be on the next
        // element and avoid closing the results.
        // Example: Going from the input to the reset button.
        setTimeout(
            function () {
                if (isFunction(this.callbacks.onInputBlur)) {
                    var returnedValue = this.callbacks.onInputBlur(this.nodes);
                    if (isBoolean(returnedValue) && !returnedValue) {
                        return false;
                    }
                }

                if (document.activeElement.isEqualNode(this.nodes.reset)) {
                    return false;
                }

                if (this._resultNodeClicked) {
                    this._resultNodeClicked = false;
                    return false;
                }

                this.close();
            }.bind(this)
        );

        return true;
    };

    PredictiveSearchComponent.prototype._addAccessibilityAnnouncer = function () {
        this._accessibilityAnnouncerDiv = window.document.createElement('div');

        this._accessibilityAnnouncerDiv.setAttribute(
            'style',
            'position: absolute !important; overflow: hidden; clip: rect(0 0 0 0); height: 1px; width: 1px; margin: -1px; padding: 0; border: 0;'
        );

        this._accessibilityAnnouncerDiv.setAttribute('data-search-announcer', '');
        this._accessibilityAnnouncerDiv.setAttribute('aria-live', 'polite');
        this._accessibilityAnnouncerDiv.setAttribute('aria-atomic', 'true');

        this.nodes.result.parentElement.appendChild(
            this._accessibilityAnnouncerDiv
        );
    };

    PredictiveSearchComponent.prototype._removeAccessibilityAnnouncer = function () {
        this.nodes.result.parentElement.removeChild(
            this._accessibilityAnnouncerDiv
        );
    };

    PredictiveSearchComponent.prototype._updateAccessibilityAttributesAfterSelectingElement = function (
        previousSelectedElement,
        currentSelectedElement
    ) {
        // Update the active descendant on the search input
        this.nodes.input.setAttribute(
            'aria-activedescendant',
            currentSelectedElement.id
        );

        // Unmark the previousSelected elemented as selected
        if (previousSelectedElement) {
            previousSelectedElement.removeAttribute('aria-selected');
        }

        // Mark the element as selected
        currentSelectedElement.setAttribute('aria-selected', true);
    };

    PredictiveSearchComponent.prototype._clearAriaActiveDescendant = function () {
        this.nodes.input.setAttribute('aria-activedescendant', '');
    };

    PredictiveSearchComponent.prototype._announceNumberOfResultsFound = function (
        results
    ) {
        var currentAnnouncedMessage = this._accessibilityAnnouncerDiv.innerHTML;
        var newMessage = this.numberOfResultsTemplateFct(results);

        // If the messages are the same, they won't get announced
        // add white space so it gets announced
        if (currentAnnouncedMessage === newMessage) {
            newMessage = newMessage + '&nbsp;';
        }

        this._accessibilityAnnouncerDiv.innerHTML = newMessage;
    };

    PredictiveSearchComponent.prototype._announceLoadingState = function () {
        this._accessibilityAnnouncerDiv.innerHTML = this.loadingResultsMessageTemplateFct();
    };

    PredictiveSearchComponent.prototype._handleInputKeyup = function (evt) {
        var UP_ARROW_KEY_CODE = 38;
        var DOWN_ARROW_KEY_CODE = 40;
        var RETURN_KEY_CODE = 13;
        var ESCAPE_KEY_CODE = 27;

        if (isFunction(this.callbacks.onInputKeyup)) {
            var returnedValue = this.callbacks.onInputKeyup(this.nodes);
            if (isBoolean(returnedValue) && !returnedValue) {
                return false;
            }
        }

        this._toggleClearButtonVisibility();

        if (this.isResultVisible && this.nodes !== null) {
            if (evt.keyCode === UP_ARROW_KEY_CODE) {
                this._navigateOption(evt, 'UP');
                return true;
            }

            if (evt.keyCode === DOWN_ARROW_KEY_CODE) {
                this._navigateOption(evt, 'DOWN');
                return true;
            }

            if (evt.keyCode === RETURN_KEY_CODE) {
                this._selectOption();
                return true;
            }

            if (evt.keyCode === ESCAPE_KEY_CODE) {
                this.close();
            }
        }

        if (evt.target.value.length <= 0) {
            this.close();
            this._setKeyword('');
        } else if (evt.target.value.length > 0) {
            this._search();
        }

        return true;
    };

    PredictiveSearchComponent.prototype._handleInputKeydown = function (evt) {
        var RETURN_KEY_CODE = 13;
        var UP_ARROW_KEY_CODE = 38;
        var DOWN_ARROW_KEY_CODE = 40;

        // Prevent the form default submission if there is a selected option
        if (evt.keyCode === RETURN_KEY_CODE && this._getSelectedOption() !== null) {
            evt.preventDefault();
        }

        // Prevent the cursor from moving in the input when using the up and down arrow keys
        if (
            evt.keyCode === UP_ARROW_KEY_CODE ||
            evt.keyCode === DOWN_ARROW_KEY_CODE
        ) {
            evt.preventDefault();
        }
    };

    PredictiveSearchComponent.prototype._handleInputReset = function (evt) {
        evt.preventDefault();

        if (isFunction(this.callbacks.onInputReset)) {
            var returnedValue = this.callbacks.onInputReset(this.nodes);
            if (isBoolean(returnedValue) && !returnedValue) {
                return false;
            }
        }

        this.nodes.input.value = '';
        this.nodes.input.focus();
        this._toggleClearButtonVisibility();
        this.close();

        return true;
    };

    PredictiveSearchComponent.prototype._navigateOption = function (
        evt,
        direction
    ) {
        var currentOption = this._getSelectedOption();

        if (!currentOption) {
            var firstOption = this.nodes.result.querySelector(
                this.selectors.searchResult
            );
            firstOption.classList.add(this.classes.itemSelected);
            this._updateAccessibilityAttributesAfterSelectingElement(
                null,
                firstOption
            );
        } else {
            if (direction === 'DOWN') {
                var nextOption = currentOption.nextElementSibling;
                if (nextOption) {
                    currentOption.classList.remove(this.classes.itemSelected);
                    nextOption.classList.add(this.classes.itemSelected);
                    this._updateAccessibilityAttributesAfterSelectingElement(
                        currentOption,
                        nextOption
                    );
                }
            } else {
                var previousOption = currentOption.previousElementSibling;
                if (previousOption) {
                    currentOption.classList.remove(this.classes.itemSelected);
                    previousOption.classList.add(this.classes.itemSelected);
                    this._updateAccessibilityAttributesAfterSelectingElement(
                        currentOption,
                        previousOption
                    );
                }
            }
        }
    };

    PredictiveSearchComponent.prototype._getSelectedOption = function () {
        return this.nodes.result.querySelector('.' + this.classes.itemSelected);
    };

    PredictiveSearchComponent.prototype._selectOption = function () {
        var selectedOption = this._getSelectedOption();

        if (selectedOption) {
            selectedOption.querySelector('a, button').click();
        }
    };

    PredictiveSearchComponent.prototype._search = function () {
        var newSearchKeyword = this.nodes.input.value;

        if (this._searchKeyword === newSearchKeyword) {
            return;
        }

        clearTimeout(this._latencyTimer);
        this._latencyTimer = setTimeout(
            function () {
                this.results.isLoading = true;

                // Annonuce that we're loading the results
                this._announceLoadingState();

                this.nodes.result.classList.add(this.classes.visibleVariant);
                // NOTE: We could benifit in using DOMPurify.
                // https://github.com/cure53/DOMPurify
                this.nodes.result.innerHTML = this.resultTemplateFct(this.results);
            }.bind(this),
            500
        );

        this.predictiveSearch.query(newSearchKeyword);
        this._setKeyword(newSearchKeyword);
    };

    PredictiveSearchComponent.prototype._handlePredictiveSearchSuccess = function (
        json
    ) {
        clearTimeout(this._latencyTimer);
        this.results = json.resources.results;

        this.results.isLoading = false;
        this.results.products = this.results.products.slice(
            0,
            this.numberOfResults
        );
        this.results.canLoadMore =
            this.numberOfResults <= this.results.products.length;
        this.results.searchQuery = this.nodes.input.value;

        if (this.results.products.length > 0 || this.results.searchQuery) {
            this.nodes.result.innerHTML = this.resultTemplateFct(this.results);
            this._announceNumberOfResultsFound(this.results);
            this.open();
        } else {
            this.nodes.result.innerHTML = '';

            this._closeOnNoResults();
        }
    };

    PredictiveSearchComponent.prototype._handlePredictiveSearchError = function () {
        clearTimeout(this._latencyTimer);
        this.nodes.result.innerHTML = '';

        this._closeOnNoResults();
    };

    PredictiveSearchComponent.prototype._closeOnNoResults = function () {
        if (this.nodes) {
            this.nodes.result.classList.remove(this.classes.visibleVariant);
        }

        this.isResultVisible = false;
    };

    PredictiveSearchComponent.prototype._setKeyword = function (keyword) {
        this._searchKeyword = keyword;
    };

    PredictiveSearchComponent.prototype._toggleClearButtonVisibility = function () {
        if (!this.nodes.reset) {
            return;
        }

        if (this.nodes.input.value.length > 0) {
            this.nodes.reset.classList.add(this.classes.clearButtonVisible);
        } else {
            this.nodes.reset.classList.remove(this.classes.clearButtonVisible);
        }
    };

    /**
     * Public methods
     */
    PredictiveSearchComponent.prototype.open = function () {
        if (this.isResultVisible) {
            return;
        }

        if (isFunction(this.callbacks.onBeforeOpen)) {
            var returnedValue = this.callbacks.onBeforeOpen(this.nodes);
            if (isBoolean(returnedValue) && !returnedValue) {
                return false;
            }
        }

        this.nodes.result.classList.add(this.classes.visibleVariant);
        this.nodes.input.setAttribute('aria-expanded', true);
        this.isResultVisible = true;

        if (isFunction(this.callbacks.onOpen)) {
            return this.callbacks.onOpen(this.nodes) || true;
        }

        return true;
    };

    PredictiveSearchComponent.prototype.close = function () {
        if (!this.isResultVisible) {
            return true;
        }

        if (isFunction(this.callbacks.onBeforeClose)) {
            var returnedValue = this.callbacks.onBeforeClose(this.nodes);
            if (isBoolean(returnedValue) && !returnedValue) {
                return false;
            }
        }

        if (this.nodes) {
            this.nodes.result.classList.remove(this.classes.visibleVariant);
        }

        this.nodes.input.setAttribute('aria-expanded', false);
        this._clearAriaActiveDescendant();
        this._setKeyword('');

        if (isFunction(this.callbacks.onClose)) {
            this.callbacks.onClose(this.nodes);
        }

        this.isResultVisible = false;
        this.results = {};

        return true;
    };

    PredictiveSearchComponent.prototype.destroy = function () {
        this.close();

        if (isFunction(this.callbacks.onBeforeDestroy)) {
            var returnedValue = this.callbacks.onBeforeDestroy(this.nodes);
            if (isBoolean(returnedValue) && !returnedValue) {
                return false;
            }
        }

        this.nodes.result.classList.remove(this.classes.visibleVariant);
        removeInputAttributes(this.nodes.input);
        this._removeInputEventListeners();
        this._removeBodyEventListener();
        this._removeAccessibilityAnnouncer();
        this._removeClearButtonEventListener();

        if (isFunction(this.callbacks.onDestroy)) {
            this.callbacks.onDestroy(this.nodes);
        }

        return true;
    };

    PredictiveSearchComponent.prototype.clearAndClose = function () {
        this.nodes.input.value = '';
        this.close();
    };

    /**
     * Utilities
     */
    function getTypeOf(value) {
        return Object.prototype.toString.call(value);
    }

    function isString(value) {
        return getTypeOf(value) === '[object String]';
    }

    function isBoolean(value) {
        return getTypeOf(value) === '[object Boolean]';
    }

    function isFunction(value) {
        return getTypeOf(value) === '[object Function]';
    }

    return PredictiveSearchComponent;
})(Shopify.theme.PredictiveSearch);

// prettier-ignore
window.theme = window.theme || {};

theme.SearchResultsTemplate = (function () {
    function renderResults(products, isLoading, searchQuery) {
        return [
            '<div class="predictive-search">',
            renderHeader(products, isLoading),
            renderProducts(products, searchQuery),
            '</div>'
        ].join('');
    }

    function renderHeader(products, isLoading) {
        if (products.length === 0) {
            return '';
        }

        return [
            '<div class="predictive-search-title">',
            '<h3 id="predictive-search" class="predictive-search-title__content">' +
            theme.strings.products +
            '</h3>',
            '<span class="predictive-search-title__loading-spinner">' +
            (isLoading ?
                '<span class= "icon-predictive-search-spinner" ></span >' :
                '') +
            '</span>',
            '</div>'
        ].join('');
    }

    function loadingState() {
        return [
            '<div class="predictive-search">',
            '<div class="predictive-search-loading">',
            '<span class="d-none">' + theme.strings.loading + '</span>',
            '<span class="predictive-search-loading__icon">',
            '<span class="icon-predictive-search-spinner"></span>',
            '</span>',
            '</div>',
            '</div>'
        ].join('');
    }

    function renderViewAll(searchQuery) {
        return [
            '<button type="submit" class="predictive-search-view-all__button" tabindex="-1">',
            theme.strings.searchFor +
            '<span class="predictive-search-view-all__query"> &ldquo;' +
            _htmlEscape(searchQuery) +
            '&rdquo;</span>',
            '</button>'
        ].join('');
    }

    function renderProducts(products, searchQuery) {
        var resultsCount = products.length;

        return [
            '<ul id="predictive-search-results" class="predictive-search__list" role="listbox" aria-labelledby="predictive-search">',
            products
            .map(function (product, index) {
                return renderProduct(normalizeProduct(product), index, resultsCount);
            })
            .join(''),
            '<li id="search-all" class="predictive-search-view-all" role="option" data-search-result>' +
            renderViewAll(searchQuery) +
            '</li>',
            '</ul>'
        ].join('');
    }

    function renderProduct(product, index, resultsCount) {
        return [
            '<li id="search-result-' +
            index +
            '" class="predictive-search-item" role="option" data-search-result>',
            '<a class="predictive-search-item__link" href="' +
            product.url +
            '" tabindex="-1">',
            '<div class="predictive-search__column predictive-search__column--image" data-image-loading-animation>',
            renderProductImage(product),
            '</div>',
            '<div class="predictive-search__column predictive-search__column--content ' +
            (getDetailsCount() ? '' : 'predictive-search__column--center') +
            '">',
            '<span class="predictive-search-item__title">',
            '<span class="predictive-search-item__title-text">' +
            product.title +
            '</span>',
            '</span>' + (getDetailsCount() ? renderProductDetails(product) : ''),
            '<span class="d-none">, </span>',
            '<span class="d-none">' +
            getNumberOfResultsString(index + 1, resultsCount) +
            '</span>',
            '</div>',
            '</a>',
            '</li>'
        ].join('');
    }

    function renderProductImage(product) {
        if (product.image === null) {
            return '';
        }

        return (
            '<img class="predictive-search-item__image lazyload" src="' +
            product.image.url +
            '" data-src="' +
            product.image.url +
            '" data-image alt="' +
            product.image.alt +
            '" />'
        );
    }

    function renderProductDetails(product) {
        return [
            '<dl class="predictive-search-item__details price' +
            (product.isOnSale ? ' price--on-sale' : '') +
            (!product.available ? ' price--sold-out' : '') +
            (!product.isPriceVaries && product.isCompareVaries ?
                ' price--compare-price-hidden' :
                '') +
            '">',
            '<div class="predictive-search-item__detail">',
            renderVendor(product),
            '</div>',
            '<div class="predictive-search-item__detail predictive-search-item__detail--inline">' +
            renderProductPrice(product),
            '</div>',
            '</dl>'
        ].join('');
    }

    function renderProductPrice(product) {
        if (!theme.settings.predictiveSearchShowPrice) {
            return '';
        }

        var accessibilityAnnounceComma = '<span class="d-none">, </span>';

        var priceMarkup =
            '<div class="price__regular">' + renderPrice(product) + '</div>';

        var salePriceMarkup =
            '<div class="price__sale d-flex align-items-center">' + renderSalePrice(product) + '</div>';

        return (
            accessibilityAnnounceComma +
            '<div class="price__pricing-group">' +
            (product.isOnSale ? salePriceMarkup : priceMarkup) +
            '</div>'
        );
    }

    function renderSalePrice(product) {
        return [
            '<span class="predictive-search-item__price predictive-search-item__price--sale">' +
            (product.isPriceVaries ?
                theme.strings.fromLowestPrice.replace('[price]', product.price) :
                product.price) +
            '</span>',
            '<div class="price__compare">' + renderCompareAtPrice(product) + '</div>'
        ].join('');
    }

    function renderCompareAtPrice(product) {
        return [
            '<span class="predictive-search-item__price predictive-search-item__price--compare  price-old">' +
            product.compareAtPrice +
            '</span>'
        ].join('');
    }

    function renderPrice(product) {
        return [
            '<span class="predictive-search-item__price  price-new">' +
            (product.isPriceVaries ?
                theme.strings.fromLowestPrice.replace('[price]', product.price) :
                product.price) +
            '</span>'
        ].join('');
    }

    function renderVendor(product) {
        if (!theme.settings.predictiveSearchShowVendor || product.vendor === '') {
            return '';
        }

        return [
            '<div class="predictive-search-item__vendor">' + product.vendor + '</div>'
        ].join('');
    }

    function normalizeProduct(product) {
        var productOrVariant =
            product.variants.length > 0 ? product.variants[0] : product;

        return {
            url: productOrVariant.url,
            image: getProductImage(product),
            title: product.title,
            vendor: product.vendor || '',
            price: theme.Currency.formatMoney(product.price_min, theme.moneyFormat),
            compareAtPrice: theme.Currency.formatMoney(
                product.compare_at_price_min,
                theme.moneyFormat
            ),
            available: product.available,
            isOnSale: isOnSale(product),
            isPriceVaries: isPriceVaries(product),
            isCompareVaries: isCompareVaries(product)
        };
    }

    function getProductImage(product) {
        var image;
        var featuredImage;

        if (product.variants.length > 0 && product.variants[0].image !== null) {
            featuredImage = product.variants[0].featured_image;
        } else if (product.image) {
            featuredImage = product.featured_image;
        } else {
            image = null;
        }

        if (image !== null) {
            image = {
                url: theme.Images.getSizedImageUrl(featuredImage.url, '100x'),
                alt: featuredImage.alt
            };
        }

        return image;
    }

    function isOnSale(product) {
        return (
            product.compare_at_price_min !== null &&
            parseInt(product.compare_at_price_min, 10) >
            parseInt(product.price_min, 10)
        );
    }

    function isPriceVaries(product) {
        return product.price_max !== product.price_min;
    }

    function isCompareVaries(product) {
        return product.compare_at_price_max !== product.compare_at_price_min;
    }

    // Returns the number of optional product details to be shown,
    // values of the detailsList need to be boolean.
    function getDetailsCount() {
        var detailsList = [
            theme.settings.predictiveSearchShowPrice,
            theme.settings.predictiveSearchShowVendor
        ];

        var detailsCount = detailsList.reduce(function (acc, detail) {
            return acc + (detail ? 1 : 0);
        }, 0);

        return detailsCount;
    }

    function getNumberOfResultsString(resultNumber, resultsCount) {
        return theme.strings.number_of_results
            .replace('[result_number]', resultNumber)
            .replace('[results_count]', resultsCount);
    }

    function _htmlEscape(input) {
        return input
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    return function (data) {
        var products = data.products || [];
        var isLoading = data.isLoading;
        var searchQuery = data.searchQuery || '';

        if (isLoading && products.length === 0) {
            return loadingState();
        }

        return renderResults(products, isLoading, searchQuery);
    };
})();

window.theme = window.theme || {};

(function () {
    // (a11y) This function will be used by the Predictive Search Component
    // to announce the number of search results
    function numberOfResultsTemplateFct(data) {
        if (data.products.length === 1) {
            return theme.strings.one_result_found;
        } else {
            return theme.strings.number_of_results_found.replace(
                '[results_count]',
                data.products.length
            );
        }
    }

    // (a11y) This function will be used by the Predictive Search Component
    // to announce that it's loading results
    function loadingResultsMessageTemplateFct() {
        return theme.strings.loading;
    }

    function isPredictiveSearchSupported() {
        var shopifyFeatures = JSON.parse(
            document.getElementById('shopify-features').textContent
        );

        return shopifyFeatures.predictiveSearch;
    }

    function isPredictiveSearchEnabled() {
        return window.theme.settings.predictiveSearchEnabled;
    }

    function canInitializePredictiveSearch() {
        return isPredictiveSearchSupported() && isPredictiveSearchEnabled();
    }

    // listen for search submits and validate query
    function validateSearchHandler(searchEl, submitEl) {
        submitEl.addEventListener(
            'click',
            validateSearchInput.bind(this, searchEl)
        );
    }

    // if there is nothing in the search field, prevent submit
    function validateSearchInput(searchEl, evt) {
        var isInputValueEmpty = searchEl.value.trim().length === 0;
        if (!isInputValueEmpty) {
            return;
        }

        if (typeof evt !== 'undefined') {
            evt.preventDefault();
        }

        searchEl.focus();
    }

    window.theme.SearchPage = (function () {
        var selectors = {
            searchReset: '[data-search-page-predictive-search-clear]',
            searchInput: '[data-search-page-predictive-search-input]',
            searchSubmit: '[data-search-page-predictive-search-submit]',
            searchResults: '[data-predictive-search-mount="default"]'
        };

        var componentInstance;
        var searchInput = document.querySelector(selectors.searchInput);
        var searchSubmit = document.querySelector(selectors.searchSubmit);

        function init(config) {
            componentInstance = new window.Shopify.theme.PredictiveSearchComponent({
                selectors: {
                    input: selectors.searchInput,
                    reset: selectors.searchReset,
                    result: selectors.searchResults
                },
                resultTemplateFct: window.theme.SearchResultsTemplate,
                numberOfResultsTemplateFct: numberOfResultsTemplateFct,
                loadingResultsMessageTemplateFct: loadingResultsMessageTemplateFct,
                onOpen: function (nodes) {
                    if (config.isTabletAndUp) {
                        return;
                    }

                    var searchInputBoundingRect = searchInput.getBoundingClientRect();
                    var bodyHeight = document.body.offsetHeight;
                    var offset = 50;
                    var resultsMaxHeight =
                        bodyHeight - searchInputBoundingRect.bottom - offset;

                    nodes.result.style.maxHeight = resultsMaxHeight + 'px';
                },
                onBeforeDestroy: function (nodes) {
                    // If the viewport width changes from mobile to tablet
                    // reset the top position of the results
                    nodes.result.style.maxHeight = '';
                }
            });

            validateSearchHandler(searchInput, searchSubmit);
        }

        function unload() {
            if (!componentInstance) {
                return;
            }
            componentInstance.destroy();
            componentInstance = null;
        }

        return {
            init: init,
            unload: unload
        };
    })();

    window.theme.SearchHeader = (function () {
        var selectors = {
            searchInput: '[data-predictive-search-drawer-input]',
            searchResults: '[data-predictive-search-mount="drawer"]',
            searchFormContainer: '[data-search-form-container]',
            searchSubmit: '[data-search-form-submit]'
        };

        var componentInstance;
        var searchInput = document.querySelector(selectors.searchInput);
        var searchSubmit = document.querySelector(selectors.searchSubmit);

        function init(config) {
            componentInstance = new window.Shopify.theme.PredictiveSearchComponent({
                selectors: {
                    input: selectors.searchInput,
                    result: selectors.searchResults
                },
                resultTemplateFct: window.theme.SearchResultsTemplate,
                numberOfResultsTemplateFct: numberOfResultsTemplateFct,
                numberOfResults: config.numberOfResults,
                loadingResultsMessageTemplateFct: loadingResultsMessageTemplateFct,
                onInputBlur: function () {
                    return false;
                },
                onOpen: function (nodes) {
                    var searchInputBoundingRect = searchInput.getBoundingClientRect();

                    // For tablet screens and up, stop the scroll area from extending past
                    // the bottom of the screen because we're locking the body scroll
                    /*
            var maxHeight =
              window.innerHeight -
              searchInputBoundingRect.bottom -
              (config.isTabletAndUp ? 20 : 0);
  
            nodes.result.style.top = config.isTabletAndUp
              ? ''
              : searchInputBoundingRect.bottom + 'px';
            nodes.result.style.maxHeight = maxHeight + 'px';
            */


                },
                onClose: function (nodes) {
                    nodes.result.style.maxHeight = '';
                },
                onBeforeDestroy: function (nodes) {
                    // If the viewport width changes from mobile to tablet
                    // reset the top position of the results
                    nodes.result.style.top = '';
                }
            });

            validateSearchHandler(searchInput, searchSubmit);
        }

        function unload() {
            if (!componentInstance) {
                return;
            }

            componentInstance.destroy();
            componentInstance = null;
        }

        function clearAndClose() {
            if (!componentInstance) {
                return;
            }

            componentInstance.clearAndClose();
        }

        return {
            init: init,
            unload: unload,
            clearAndClose: clearAndClose
        };
    })();

    window.theme.Search = (function () {
        var classes = {
            searchTemplate: 'template-search'
        };
        var selectors = {
            siteHeader: '#header-parts'
        };
        var mediaQueryList = {
            mobile: window.matchMedia('(max-width: 749px)'),
            tabletAndUp: window.matchMedia('(min-width: 750px)')
        };

        function init() {
            if (!document.querySelector(selectors.siteHeader)) {
                return;
            }

            if (!canInitializePredictiveSearch()) {
                return;
            }

            Object.keys(mediaQueryList).forEach(function (device) {
                mediaQueryList[device].addListener(initSearchAccordingToViewport);
            });

            initSearchAccordingToViewport();
        }

        function initSearchAccordingToViewport() {
            theme.SearchDrawer.close();
            theme.SearchHeader.unload();
            theme.SearchPage.unload();

            if (mediaQueryList.mobile.matches) {
                theme.SearchHeader.init({
                    numberOfResults: 4,
                    isTabletAndUp: false
                });

                if (isSearchPage()) {
                    theme.SearchPage.init({
                        isTabletAndUp: false
                    });
                }
            } else {
                // Tablet and up
                theme.SearchHeader.init({
                    numberOfResults: 4,
                    isTabletAndUp: true
                });

                if (isSearchPage()) {
                    theme.SearchPage.init({
                        isTabletAndUp: true
                    });
                }
            }
        }

        function isSearchPage() {
            return document.body.classList.contains(classes.searchTemplate);
        }

        function unload() {
            theme.SearchHeader.unload();
            theme.SearchPage.unload();
        }

        return {
            init: init,
            unload: unload
        };
    })();
})();

window.theme = window.theme || {};

theme.SearchDrawer = (function () {
    var selectors = {
        headerSection: '[data-header-section]',
        drawer: '[data-predictive-search-drawer]',
        drawerOpenButton: '[data-predictive-search-open-drawer]',
        headerSearchInput: '[data-predictive-search-drawer-input]',
        predictiveSearchWrapper: '[data-predictive-search-mount="drawer"]'
    };

    var drawerInstance;

    function init() {
        setAccessibilityProps();

        drawerInstance = new theme.Drawers('SearchDrawer', 'top', {
            onDrawerOpen: function () {
                setHeight();
                // theme.MobileNav.closeMobileNav();
                lockBodyScroll();
            },
            onDrawerClose: function () {
                theme.SearchHeader.clearAndClose();
                var drawerOpenButton = document.querySelector(
                    selectors.drawerOpenButton
                );

                if (drawerOpenButton) drawerOpenButton.focus();

                unlockBodyScroll();
            },
            withPredictiveSearch: true,
            elementToFocusOnOpen: document.querySelector(selectors.headerSearchInput)
        });
    }

    function setAccessibilityProps() {
        var drawerOpenButton = document.querySelector(selectors.drawerOpenButton);

        if (drawerOpenButton) {
            drawerOpenButton.setAttribute('aria-controls', 'SearchDrawer');
            drawerOpenButton.setAttribute('aria-expanded', 'false');
            drawerOpenButton.setAttribute('aria-controls', 'dialog');
        }
    }

    function setHeight() {
        var searchDrawer = document.querySelector(selectors.drawer);
        var headerHeight = document.querySelector(selectors.headerSection)
            .offsetHeight;

        searchDrawer.style.height = headerHeight + 'px';
    }

    function close() {
        drawerInstance.close();
    }

    function lockBodyScroll() {
        theme.Helpers.enableScrollLock();
    }

    function unlockBodyScroll() {
        theme.Helpers.disableScrollLock();
    }

    return {
        init: init,
        close: close
    };
})();


theme.SearchMobileDrawer = (function () {
    var selectors = {
        headerSection: '[data-header-section]',
        drawer: '[data-predictive-search-mobile-drawer]',
        drawerOpenButton: '[data-predictive-search-mobile-open-drawer]',
        headerSearchInput: '[data-predictive-search-mobile-drawer-input]',
        predictiveSearchWrapper: '[data-predictive-search-mobile-mount="drawer"]'
    };

    var drawerInstance;

    function init() {
        setAccessibilityProps();

        drawerInstance = new theme.Drawers('SearchMobileDrawer', 'top', {
            onDrawerOpen: function () {
                setHeight();
                // theme.MobileNav.closeMobileNav();
                lockBodyScroll();
            },
            onDrawerClose: function () {
                theme.SearchHeader.clearAndClose();
                var drawerOpenButton = document.querySelector(
                    selectors.drawerOpenButton
                );

                if (drawerOpenButton) drawerOpenButton.focus();

                unlockBodyScroll();
            },
            withPredictiveSearch: true,
            elementToFocusOnOpen: document.querySelector(selectors.headerSearchInput)
        });
    }

    function setAccessibilityProps() {
        var drawerOpenButton = document.querySelector(selectors.drawerOpenButton);

        if (drawerOpenButton) {
            drawerOpenButton.setAttribute('aria-controls', 'SearchMobileDrawer');
            drawerOpenButton.setAttribute('aria-expanded', 'false');
            drawerOpenButton.setAttribute('aria-controls', 'dialog');
        }
    }

    function setHeight() {
        var searchDrawer = document.querySelector(selectors.drawer);
        var headerHeight = document.querySelector(selectors.headerSection)
            .offsetHeight;

        searchDrawer.style.height = headerHeight + 'px';
    }

    function close() {
        drawerInstance.close();
    }

    function lockBodyScroll() {
        theme.Helpers.enableScrollLock();
    }

    function unlockBodyScroll() {
        theme.Helpers.disableScrollLock();
    }

    return {
        init: init,
        close: close
    };
})();

theme.SearchDrawer.init();
theme.Search.init();